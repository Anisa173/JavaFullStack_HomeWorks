package ushtrimeScanner.java;

import java.util.Scanner;

class Main1 {
	private static Scanner sc;	
	static String a,b,c , text;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	sc = new Scanner(System.in);		
	System.out.println("Vendosni inputin ne console");
	
	a = sc.nextLine();	
	System.out.println("                               ");
	b = sc.nextLine();	
	System.out.println("                               ");
	c = sc.nextLine();
	System.out.println("                               ");
	text = main();
	System.out.println("Afisho Outputin ne Console");
	System.out.println("                            ");
	System.out.println(text);
	}
	public static String main() {
	String d = a+ '\n'+'\n'+ b +'\n'+'\n' + c ;
	
	return d;
}
}