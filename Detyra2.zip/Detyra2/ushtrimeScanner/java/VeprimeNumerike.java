package ushtrimeScanner.java;
import java.util.Scanner;
import java.lang.Math;
public class VeprimeNumerike {
private static Scanner input;
static int a2 ;
static double a1,sh,dif,produkti ;
public static void main(String[] args){
input = new Scanner(System.in);
System.out.println("Vendosni inputin!");
System.out.println("Kujdes!! Numri i pare eshte jo i plote ndersa i dyti eshte numer i plote...");
a1 = input.nextDouble();
a2 = input.nextInt();
sh = shuma();
dif = diferencNr();
produkti = shumezimiNr();
System.out.println("Le te afishohet outputi ne console!");
System.out.println(a1);
System.out.println(a2);
System.out.println("                                   ");
System.out.println("Shuma e numrave eshte :" + " " + sh  );
System.out.println("Diferenca e numrave eshte:" + " " + dif  );
System.out.println("Produkti i dy numrave eshte:" + " " + produkti );
double c2 = a1 + 0.1;
double c1 = (double)a2;
c1 = c2;
System.out.println("Vlera e numrit te dyte pas shtimit eshte :" + " " + c2 );
System.out.println("Vleren e numrit te pare  pas shkembimit eshte:" + " " + c1 );
}

public static double shuma() {
double x = a1, shm;
double y = (double)a2;
shm = x + y ;
return shm;
}
public static double diferencNr() {
double z = a1,d ,d1;
double b = (double)a2;
d = z - b ;
d1 = Math.abs(d);
return d1;
}
public static double shumezimiNr() {
double m = a1, p;
double n = (double)a2;
p = m*n;
return p;
}

}