package ushtrimeScanner.java;
import java.util.Scanner;
public class Laptop {
private static Scanner c;
static String sistemOperimi;
static String produkti;
String madhesiRam;
static String result, result1;
String tipProcesori;
private static final int nTot = 18976555;
public static  String emerMarke_Produkti = " 'Hp' ";
@SuppressWarnings("unused")
private static final String deviceID = "75C7AD37-2A67-4D02-96FF-FBF69FB05C53";
static boolean gjendje = true;	
static boolean skaGjendje = false;	
	public static void main(String[] args) {
c = new Scanner(System.in);
System.out.println("Mire se erdhet ne shopin tone Produkte On Tech !");
System.out.println("                                   ");
System.out.println("Lloji i produktit qe deshironi:");
produkti = c.nextLine();
System.out.println("Sistemi i operimit:");

result = afishoT();
result1 = afishoF();
	}

public static String afishoT() {
boolean u_gjet; 
String p = produkti; 
sistemOperimi = "Windows 64 ";
if(nTot != 0){ u_gjet = gjendje;    
System.out.println( p + " " + "ne gjendje :" + " " + u_gjet + ";" + "Sistem Operimi :" +" " + sistemOperimi);}		

return sistemOperimi;
}
public static String afishoF() {
boolean ph;String p1 = produkti;
int nTot1 = 0;
boolean b = nTot1 == 0;
sistemOperimi = "Linux" ;
if(b){ ph = skaGjendje; System.out.println( p1 + " " + "ne gjendje :" + " " + ph + ";" + "Sistem Operimi :" +" " + sistemOperimi);}
return sistemOperimi;
}}








