/**
 * 
 */
/**
 * @author ACSystem
 *
 */
package ushtrimeScanner.java;
import java.util.Scanner;
class Main{
private static Scanner sc;	
static String a,b,c;	
	public static void main(String[]args) {
sc = new Scanner(System.in);		
a = sc.nextLine();	
b = sc.nextLine();	
c = sc.nextLine();
System.out.println(a);
System.out.println("                           ");
System.out.println(b);
System.out.println("                            ");
System.out.println(c);
	}
		
}