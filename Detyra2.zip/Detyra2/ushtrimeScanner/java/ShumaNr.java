package ushtrimeScanner.java;
import java.util.Scanner;
public class ShumaNr {
static boolean iplote = true;
static boolean joiPlote = false;

static double no1,no2,sh;
static int x1, x2;
private static Scanner x;
public static void main(String[] args) {

x = new Scanner(System.in);
System.out.println("Vendosni inputin ne console");
no1 = x.nextDouble();

no2 = x.nextDouble();
sh = no1 + no2;
System.out.println("                              ");
System.out.println("Shuma e numrit te pare me vlere :" + " " + no1 + " " + "dhe numrit te dyte me vlere:" + " " + no2 +" "+ "eshte"+ " "+ sh + ".");
System.out.println("                                       ");
x1 = (int)no1;
x2 = (int)no2;
if(no1 > x1) { System.out.println("Numri i pare eshte jo i plote : " + " " + iplote);}
else {System.out.println("Numri i pare eshte i plote :" + " " + iplote);}
if(no2 > x2) {System.out.println("Numri i dyte eshte jo i plote : " + " " + iplote );}
else {System.out.println("Numri i pare eshte i plote : " + " " + iplote);}
if(((no1 > x1)&& (no2 > x2)) == iplote ) {System.out.println("Te dy numrat jane te jo te plote : " + " " + joiPlote);}
else if(((no1 == x1)&&(no2 == x2)) == iplote ){System.out.println("Te dy numrat jane te plote :" + " " + iplote);}
else { System.out.println("Njeri nga numrat eshte jo i plote ");
}
}}