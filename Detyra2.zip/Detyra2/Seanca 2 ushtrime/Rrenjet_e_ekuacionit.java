package al.academy.ikubinfo.java;
import java.util.Scanner;
import java.lang.Math;
public class Rrenjet_e_ekuacionit {
private static Scanner input;
static double a,b,c,zgjidhja;
public static void main(String[] args) {
	input = new Scanner(System.in);
	System.out.println("XII. Vendosni parametrat");
	a=input.nextDouble();
	b=input.nextDouble();
	c=input.nextDouble();	
	zgjidhja = zgjidhjet_e_ekuacionit() ;
System.out.println("Rrenjet e pare e ekuacionit te fuqise se dyte eshte:"); 
System.out.println(zgjidhja);
System.out.println("Rrenjet e dyte e ekuacionit te fuqise se dyte eshte:"); 
System.out.println(-zgjidhja);
}
public static double zgjidhjet_e_ekuacionit() {
double x,d,v,f;
d= Math.pow(b,2);
f= Math.abs(d-(4*a*c));
v = Math.sqrt(f); 
x = (Math.abs(((-b)+ v)/(2*a)));
return x;

}
}
