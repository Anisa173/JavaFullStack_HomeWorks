package al.academy.ikubinfo.java;
import java.util.Scanner;
public class Dating {
static int min;
static int d;
	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner input =new Scanner(System.in);
System.out.println("IX. Vendosni numrin e minutave:");
min = input.nextInt();
d = nrDitesh();
System.out.println("Ju keni jetuar" +" "+ d + " " + "vite !");
	}
public static int nrDitesh() {
int ore, dite,vite;
ore =  min/60;
dite =  ore/24;
vite =  dite/365;
System.out.println("Ju keni llogaritur " +" " + dite + " "+ "dite .");
return vite;
}}
