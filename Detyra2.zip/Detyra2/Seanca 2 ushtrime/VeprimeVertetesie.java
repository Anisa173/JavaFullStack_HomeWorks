package al.academy.ikubinfo.java;
import java.util.*;

public class VeprimeVertetesie {
static double x;
static double y,rezultati;
static int a,b,c,d,e;
static boolean eVertete = true;	
static boolean pabarabarte = false;
static boolean Vertetesia;
static int vitiLindjes;
private static Scanner input;
public static void main(String[] args) {
input = new Scanner(System.in);
System.out.println("III.Njevlershmeria e numrave eshte :" + '\n');
x = input.nextDouble();
y = input.nextDouble();
Vertetesia = vlefshmeri();
System.out.println(Vertetesia);
System.out.println("                                 ");
System.out.print("IV.Vendos numrin :");
x = input.nextDouble();
Vertetesia = me_i_Vogel();
System.out.println("A eshte numri me i vogel apo me i madh se 10?" + '\n' + Vertetesia);
System.out.println("                                             ");
System.out.print("V:Numri eshte :");
y = input.nextDouble();
rezultati = dyFishinr();
System.out.println("Rezultati eshte :" + rezultati);
System.out.println("                              ");
System.out.println("VII. Ju lutem vendosni numrat:");
a = input.nextInt();
b = input.nextInt();
c = input.nextInt();
d = input.nextInt();
e = input.nextInt();
rezultati = mesatarja();
System.out.println("Mesatarja me inpute eshte : " +" " + rezultati );

System.out.println("VIII. Ju lutem vendosni vitin tuaj te lindjes:");
vitiLindjes = input.nextInt();
a = mosha();
System.out.println("Ju jeni"+ " " + a+ " "+ "vjec !");}
public static boolean vlefshmeri(){
	boolean pohimi;
	if(x==y){
 pohimi = eVertete;}
else{
 pohimi = pabarabarte;}
return pohimi;
}
public static boolean me_i_Vogel() {
boolean vlera;
if(x<10) {vlera = eVertete;
} else {vlera = pabarabarte; }
 return vlera;
}
public static double dyFishinr() {
double nr = 2*y;
return nr; }
public static double mesatarja() {
double mes =(a+b+c+d+e)/5;
int e = 6;
int r = 8;
int g = 7;
int k = 6;
int l = 5;
 double mes1 = (e+r+g+k+l)/5;
System.out.println("Mesatarja jone eshte: " + mes1);
 return mes;	
}
public static int mosha() {
int viti = 2023;
int mosha = viti - vitiLindjes;
if(mosha< 20) { System.out.println("Kategoria deri ne 20!");}
if((mosha> 20)&&(mosha < 50)) { System.out.println("Kategoria mbi 20 deri ne 50!");}
if(mosha > 50) {System.out.println("Kategoria eshte mbi 50!");}
return mosha;
}}