package al.academy.ikubinfo.java;
public class Vlershmeri_shprehjeshBooleane {
	static boolean eVertete = true;	
	static boolean pabarabarte = false;
	static int x = 25;
	static int y = 24;
	static int a = 8;
	

public static void main(String[] args) {

vlershmeriBooleane();
}

public static boolean vlershmeriBooleane() {
 int c = a%2 ;boolean z = (x>y) ; boolean m = (c==0); boolean p;
if(x<y){ p = pabarabarte;
System.out.println("Shprehja NJE : Numri" + " " + x+ " "+ "eshte me i vogel se" + " "+"numri" + y + '\n' + p);
}
else { p= eVertete;
System.out.println("Shprehja NJE : Numri" + " " + x+ " "+ "eshte me i madh se" + " "+ y + '\n' + p);
}
if(c == 0){p = eVertete;
System.out.println("Shprehja DY : Numri" + " " +a + " "+ "eshte " + " " + "numer cift" + '\n' + p);
}
else { p = pabarabarte;
System.out.println("Shprehja DY : Numri" + " " +a + " "+ "eshte " + " " + "numer tek" + '\n' + p);
}

if((z && m)== eVertete) { p = eVertete;
System.out.println("Numri" + " " + x+ " "+ "eshte me i madh se" + " "+ y + " "+"DHE" +" " + "Numri" + " " +a + " "+ "eshte " + " " + "numer cift" + ":" + p);}
if(((!z)|| m)== eVertete) { p = eVertete;
System.out.println("Numri" + " " + x+ " "+ "eshte me i vogel se" + " "+ y + " "+"OSE" +" " + "Numri" + " " +a + " "+ "eshte " + " " + "numer cift" + ":" + p);}
if(((!z)&& (!m))== pabarabarte) { p = pabarabarte;
System.out.println("Numri" + " " + x+ " "+ "eshte me i vogel se" + " "+ y+ " "+"DHE" +" " + "Numri" + " " +a + " "+ "eshte " + " " + "numer tek" + ":" + p);}
if((z || m)== eVertete) { p = eVertete;
System.out.println("Numri" + " " + x+ " "+ "eshte me i madh se" + " "+ y+ " "+"OSE" +" " + "Numri" + " " +a + " "+ "eshte " + " " + "numer cift" + ":" + p );}
if((z && (!m))== pabarabarte) { p = pabarabarte;
System.out.println("Numri" + " " + x+ " "+ "eshte me i madh se" + " "+ y+ " "+"DHE" +" " + "Numri" + " " +a + " "+ "eshte " + " " + "numer tek" + ":" + p);}
return p;
}}



	


