package al.academy.ikubinfo.java;
import java.util.Scanner;
import java.lang.Math;
public class Insert_nga_Console{
 static double gjatesia ;
 static double gjeresia;
 static double rreze;
static double perimetri;
static double sipRrethi;
public static double parameter = 3.14;
private static Scanner input;
public static void main(String[] args){
input = new Scanner(System.in);
System.out.println("I.Vendosni parametrat");
gjatesia = input.nextDouble();
gjeresia = input.nextDouble();
perimetri = perimetriD();
System.out.println("Perimetri i drejtkendeshit eshte" + " " + perimetri );
System.out.println("                              ");
System.out.print("II. Vendos rrezen :");
rreze = input.nextDouble();
sipRrethi = sRrethi();    
System.out.println("Siperfaqja e rrethit eshte :" + " " + sipRrethi);
}
public static double perimetriD() {
double p = 2*(gjatesia + gjeresia);
return p;}

public static double sRrethi() {
double sipR = parameter * Math.pow(rreze,2);
return sipR;

}}
