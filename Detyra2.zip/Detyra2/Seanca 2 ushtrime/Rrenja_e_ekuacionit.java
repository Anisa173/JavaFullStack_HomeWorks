package al.academy.ikubinfo.java;
import java.util.Scanner;

public class Rrenja_e_ekuacionit {
private static Scanner input;
	static double a,b,c,Rrenja;
	public static void main(String[] args) {
    input = new Scanner(System.in);
System.out.println("Vendosni parametrat");
a=input.nextDouble();
b=input.nextDouble();
c=input.nextDouble();
Rrenja = zgjidhjeEkuacioni();
System.out.println("X.Zgjidhja e ekuacionit te fuqise se pare me nje ndryshor eshte " + " " + ":" + Rrenja);

}
public static double zgjidhjeEkuacioni(){
double x = (c-b)/a;
return x;
}
}