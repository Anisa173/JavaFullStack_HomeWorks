package paisje.elektronike;

public class ProdukteTech { 
static String sistem_operimi ;
String madhesiaRAM;
String procesorType;
boolean kerkoj_laptop = true;
boolean porosit_laptop = false;
public static  String emerMarke_Produkti = " 'Hp' ";
private static final String deviceID = "75C7AD37-2A67-4D02-96FF-FBF69FB05C53";

public static void main(String[] args) {
ProdukteTech Laptop = new ProdukteTech();

System.out.println("Mirsevini ne e - Tech_Shop! "); 
Laptop.blejLaptop();
Laptop.kerkojLaptop();
Laptop.inicjalizollojProdukti(sistem_operimi,deviceID);

}
public boolean blejLaptop() {
sistem_operimi = "Windows 64 bit" ;
System.out.println("                                                                         ");
System.out.println("Ne gjendje:" +" " + kerkoj_laptop + ";" + "Sistem Operimi:" + sistem_operimi );
return kerkoj_laptop;
}

public boolean kerkojLaptop() {
sistem_operimi = " Linux ";
System.out.println("                                                                         ");
System.out.println("Kategoria: Laptop" + '\n' + "Sistem Operimi:" + " " + sistem_operimi + '\n' + "Numri i porosive :" + " " + porosit_laptop );
return porosit_laptop;
}
public String inicjalizollojProdukti(String sistem_operimi, String deviceID){
sistem_operimi = "Linux ";
System.out.println("                                                                                           ");
System.out.println("Laptopi me sistem operimi : " +" " + sistem_operimi + " , me nr serie " + " " + deviceID +  " " + "i perket kategorise" +" "+ emerMarke_Produkti + " "+ "." );
return sistem_operimi;
}
}


















