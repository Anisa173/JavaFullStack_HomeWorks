package com.spring.demo.posts.jpa.repository;

import java.util.List;

import com.spring.demo.posts.jpa.dto.PostsDto;
import com.spring.demo.posts.jpa.entity.Users;

public interface UsersRepo {

	List<Users> getAllUsers() throws Exception;

	Users getUsersById(Users user, Integer id) throws Exception;

	Users createUsers(Users dtoToEntity) throws Exception;

	List<Users> getUsersPost() throws Exception;

	Users updateUsersByUsername(Integer id, Users users) throws Exception;

	Users updateUsersByEmail(Users users, Integer id) throws Exception;

	Users updateUsersByPassword(Users users, Integer id) throws Exception;

	Users updateUsersByDateModified(Users users, Integer id) throws Exception;

	void deleteUsersById(Users user, Integer id) throws Exception;

	List<Users> getUserPostsById(Users user_post, Integer id);

	void deleteUsersPosts(PostsDto posts, Integer id);

}
