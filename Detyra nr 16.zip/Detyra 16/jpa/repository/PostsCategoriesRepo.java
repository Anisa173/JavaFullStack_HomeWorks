package com.spring.demo.posts.jpa.repository;

import java.util.List;

import com.spring.demo.posts.jpa.entity.Categories;
import com.spring.demo.posts.jpa.entity.Posts;
import com.spring.demo.posts.jpa.entity.PostsCategories;

public interface PostsCategoriesRepo {

	List<Posts> getPostsByCategoryName(Posts posts, String name);

	List<Posts> getPostsCategoryById(Posts posts, Categories categories, Integer id);

	List<Posts> getAllPostsByCategories(Posts posts, Categories categories);

	PostsCategories getPostsByCategoryName(Posts posts, Categories categ, String name);

}
