package com.spring.demo.posts.jpa.repository;

import java.time.LocalDateTime;
import java.util.List;

import com.spring.demo.posts.jpa.dto.PostsDto;
import com.spring.demo.posts.jpa.entity.Posts;
import com.spring.demo.posts.jpa.entity.Users;

public interface PostsRepo {

	Posts createUserPostsDto(Posts posts,Integer id) throws Exception;

	void deletePosts(Posts posts,Integer id) throws Exception;

	Posts getUserPostsById1(Users user_post, Integer id);

    List<Posts> getAllPostsByTitle(Posts p, String title) throws Exception;

	List<Posts> getAllPostsByDate_created(Posts p, LocalDateTime date_created) throws Exception;

	Posts updatePosts(Posts posts,Integer id) throws Exception;

	List<Posts> getAllPosts() throws Exception;

	Posts updateUserPosts(Posts post,Users user_post ,Integer id);

	

	

	

	
	

}
