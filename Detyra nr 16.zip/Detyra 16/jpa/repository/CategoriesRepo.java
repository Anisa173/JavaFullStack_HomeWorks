package com.spring.demo.posts.jpa.repository;

import java.util.Collection;
import java.util.List;

import com.spring.demo.posts.jpa.dto.PostsDto;
import com.spring.demo.posts.jpa.dto.UsersDto;
import com.spring.demo.posts.jpa.entity.Categories;
import com.spring.demo.posts.jpa.entity.Posts;


public interface CategoriesRepo {

	Categories createCategory(Categories dtoToEntity);

	void deleteCategory(Categories c, Integer id);

	Categories findById(Integer id);
	
	Categories updateCategoryByName(Integer id, Categories uptodate);
List<Posts> getPostsByCategoryName(Posts posts, String name);

	Posts getPostsCategoryById(Posts posts, Categories categories, Integer id);

	List<Posts> getAllPostsByCategories(Posts posts, Categories categories);

	

	

	



	



}
