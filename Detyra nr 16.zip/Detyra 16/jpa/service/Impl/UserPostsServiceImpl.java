package com.spring.demo.posts.jpa.service.Impl;

import java.time.LocalDateTime;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.demo.posts.jpa.dto.CategoriesDto;
import com.spring.demo.posts.jpa.dto.PostsDto;
import com.spring.demo.posts.jpa.dto.UsersDto;
import com.spring.demo.posts.jpa.entity.Categories;
import com.spring.demo.posts.jpa.entity.Posts;
import com.spring.demo.posts.jpa.entity.Users;
import com.spring.demo.posts.jpa.mapper.CategoriesMapper;
import com.spring.demo.posts.jpa.mapper.PostsMapper;
import com.spring.demo.posts.jpa.mapper.UserMapper;
import com.spring.demo.posts.jpa.repository.CategoriesRepo;
import com.spring.demo.posts.jpa.repository.PostsCategoriesRepo;
import com.spring.demo.posts.jpa.repository.PostsRepo;
import com.spring.demo.posts.jpa.repository.UsersRepo;
import com.spring.demo.posts.jpa.service.BlogService;
import com.spring.demo.posts.jpa.service.UserService;

@Service
public class UserPostsServiceImpl implements BlogService, UserService {
	@Autowired
	private final CategoriesRepo categoriesRepo;
	private final PostsRepo postsRepo;
	private final UsersRepo usersRepo;
	private final PostsCategoriesRepo postsCategoriesRepo;
	@Autowired
	private final UserMapper userMapper;
	private final PostsMapper postsMapper;
	private final CategoriesMapper categoriesMapper;
	

	public UserPostsServiceImpl(CategoriesRepo categoriesRepo, PostsRepo postsRepo, UsersRepo usersRepo,
			PostsCategoriesRepo postsCategoriesRepo, UserMapper userMapper, PostsMapper postsMapper,
			CategoriesMapper categoriesMapper) {
		this.categoriesRepo = categoriesRepo;
		this.postsCategoriesRepo = postsCategoriesRepo;
		this.postsRepo = postsRepo;
		this.usersRepo = usersRepo;
		this.userMapper = userMapper;
		this.postsMapper = postsMapper;
		this.categoriesMapper = categoriesMapper;
		
	}

	@Override
	public List<UsersDto> getAllUsers() throws Exception {
		return usersRepo.getAllUsers().stream().map(u -> userMapper.entityToDto(u)).collect(Collectors.toList());
	}

	@Override
	public UsersDto getUsersById(Users user, Integer id) throws Exception {
		var entity = usersRepo.getUsersById(user, id);
		return userMapper.entityToDto((Users) entity);
	}

	public UsersDto createUsers(UsersDto user_post) throws Exception {
		var user = usersRepo.createUsers(userMapper.dtoToEntity(user_post));
		return userMapper.entityToDto((Users) user);
	}

	@Override
	public UsersDto updateUsersByUsername(Users user, Integer id) throws Exception {
		var userToUpdate = userMapper.dtoToEntity(getUsersById(user, id));
		userToUpdate.setUsername(user.getUsername());

		return userMapper.entityToDto(usersRepo.updateUsersByUsername(id, userToUpdate));
	}

	@Override
	public UsersDto updateUsersByEmail(Users user, Integer id) throws Exception {
		var userUpdate = userMapper.dtoToEntity(getUsersById(user, id));
		userUpdate.setEmail(user.getEmail());
		return userMapper.entityToDto(usersRepo.updateUsersByEmail(userUpdate, id));
	}

	@Override
	public UsersDto updateUsersByPassword(Users user, Integer id) throws Exception {
		var UpToDate = userMapper.dtoToEntity(getUsersById(user, id));
		UpToDate.setPassword(user.getPassword());
		return userMapper.entityToDto(usersRepo.updateUsersByPassword(UpToDate, id));
	}

	@Override
	public UsersDto updateUsersByDateModified(Users users, Integer id) throws Exception {
		var userUpTodate = userMapper.dtoToEntity(getUsersById(users, id));
		userUpTodate.setDate_modified(users.getDate_modified());
		return userMapper.entityToDto(usersRepo.updateUsersByDateModified(userUpTodate, id));
	}

	@Override
	public void deleteUsersById(Users user, Integer id) throws Exception {
		usersRepo.deleteUsersById(user, id);
	}

	public List<UsersDto> getUsersPosts() throws Exception {

		return usersRepo.getUsersPost().stream().map(h -> userMapper.entityToDto(h)).collect(Collectors.toList());
	}

	@Override
	public UsersDto getUserPostsById(Users user_post, Integer id) throws Exception {

		var User = usersRepo.getUserPostsById(user_post, id);

		return userMapper.entityToDto((Users) User);
	}

	@Override
	public CategoriesDto createCategory(CategoriesDto c, Integer id) throws Exception {
		var cat = categoriesRepo.createCategory(categoriesMapper.dtoToEntity(c));
		return categoriesMapper.entityToDto((Categories) cat);
	}

	@Override
	public void deleteCategory(Categories c, Integer id) throws Exception {

		categoriesRepo.deleteCategory(c, id);
	}

	@Override
	public CategoriesDto findById(CategoriesDto c, Integer id) throws Exception {
		var Categ = categoriesRepo.findById(id);
		return categoriesMapper.entityToDto((Categories) Categ);
	}

	@Override
	public CategoriesDto updateCategoryByName(CategoriesDto c, Integer id) throws Exception {
		var uptodate = categoriesMapper.dtoToEntity(findById(c, id));
		uptodate.setName(c.getName());
		return categoriesMapper.entityToDto(categoriesRepo.updateCategoryByName(id, uptodate));
	}

	@Override
	public void deleteUserPosts(PostsDto posts, Integer id) throws Exception {
		usersRepo.deleteUsersPosts(posts, id);
	}

	public PostsDto getUserPostsById1(Users user_post, Integer id) throws Exception {
    var postdt = postsRepo.getUserPostsById1(user_post, id);
		return postsMapper.entityToDto((Posts) postdt);
	}

	
	public PostsDto updateUserPosts(Posts post,Users user_post ,Integer id) throws Exception {
		var postUpToDate = postsMapper.dtoToEntity(getUserPostsById1(user_post, id));
		postUpToDate.setTitle(user_post.getPosts().getTitle());
	postUpToDate.setPostStatus(user_post.getPosts().getPostStatus());
		return postsMapper.entityToDto(postsRepo.updateUserPosts(postUpToDate, user_post, id));
	}

	@Override
	public List<PostsDto> getAllPosts() throws Exception {

		return postsRepo.getAllPosts().stream().map(p -> postsMapper.entityToDto(p)).collect(Collectors.toList());
	}

	@Override
	public List<PostsDto> getAllPostsByTitle(Posts p, String title) throws Exception {

		return postsRepo.getAllPostsByTitle(p, title).stream().map(k -> postsMapper.entityToDto(k))
				.collect(Collectors.toList());
	}

	@Override
	public List<PostsDto> getAllPostsByDate_created(Posts p, LocalDateTime date_created) throws Exception {

		return postsRepo.getAllPostsByDate_created(p, date_created).stream().map(m -> postsMapper.entityToDto(m))
				.collect(Collectors.toList());
	}

	@Override
	public List<PostsDto> getPostsByCategoryName(Posts p,String name) throws Exception {
 
		return categoriesRepo.getPostsByCategoryName(p,name).stream().map(h -> postsMapper.entityToDto(h)).collect(Collectors.toList());
	}
	
	@Override
	public List<PostsDto> getAllPostsByCategories(Posts posts, Categories categories) throws Exception {
		return categoriesRepo.getAllPostsByCategories(posts,categories).stream().map(n -> postsMapper.entityToDto(n)).collect(Collectors.toList());
				
	}

	@Override
	public PostsDto getPostsCategoryById(Posts posts, Categories categories, Integer id) throws Exception {
var pstd = categoriesRepo.getPostsCategoryById(posts, categories, id);
		return postsMapper.entityToDto(pstd);
				
	}

	

	

	

	
}
