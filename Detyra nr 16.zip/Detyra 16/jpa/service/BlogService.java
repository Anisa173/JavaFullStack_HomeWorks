package com.spring.demo.posts.jpa.service;

import java.time.LocalDateTime;
import java.util.List;

import com.spring.demo.posts.jpa.dto.CategoriesDto;
import com.spring.demo.posts.jpa.dto.PostCategoriesDto;
import com.spring.demo.posts.jpa.dto.PostsDto;
import com.spring.demo.posts.jpa.dto.UsersDto;
import com.spring.demo.posts.jpa.entity.Categories;
import com.spring.demo.posts.jpa.entity.Posts;
import com.spring.demo.posts.jpa.entity.Users;

public interface BlogService {

	CategoriesDto createCategory(CategoriesDto c, Integer id) throws Exception;

	void deleteCategory(Categories c, Integer id) throws Exception;

	CategoriesDto findById(CategoriesDto c, Integer id) throws Exception;

	CategoriesDto updateCategoryByName(CategoriesDto c, Integer id) throws Exception;

	void deleteUserPosts(PostsDto posts, Integer id) throws Exception;


	PostsDto updateUserPosts(Posts posts, Users user_post, Integer id) throws Exception;

	List<PostsDto> getAllPosts() throws Exception;

	List<PostsDto> getAllPostsByTitle(Posts p, String title) throws Exception;

	List<PostsDto> getAllPostsByDate_created(Posts p, LocalDateTime date_created) throws Exception;



	List<PostsDto> getAllPostsByCategories(Posts posts, Categories categories) throws Exception;

	PostsDto getPostsCategoryById(Posts posts, Categories Categories, Integer id) throws Exception;

	List<PostsDto> getPostsByCategoryName(Posts p, String name) throws Exception;

	


	

	

	

	



}
