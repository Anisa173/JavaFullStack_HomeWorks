package com.spring.demo.posts.jpa;

import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.spring.demo.posts.jpa.service.BlogService;
import com.spring.demo.posts.jpa.service.UserService;

import ch.qos.logback.classic.Logger;

@SpringBootApplication
public class Application implements CommandLineRunner {

	private static Logger logger = (Logger) LoggerFactory.getLogger(Application.class);
	private final BlogService blogService;
	private final UserService userService;

	public Application(BlogService blogService, UserService userService) {
		super();
		this.blogService = blogService;
		this.userService = userService;
	}

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}

	@Override
	public void run(String... args) throws Exception {

	}

	public BlogService getBlogService() {
		return blogService;
	}

	public UserService getUserService() {
		return userService;
	}

}
