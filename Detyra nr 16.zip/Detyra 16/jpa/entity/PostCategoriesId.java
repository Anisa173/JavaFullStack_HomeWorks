package com.spring.demo.posts.jpa.entity;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import jakarta.persistence.Id;

@Embeddable
public class PostCategoriesId extends BaseEntity<Integer> implements Serializable{
	
	private static final long serialVersionUID = 1L;
@Id
	@Column(name = "categoryId")
	private Integer categoryId;
@Id
	@Column(name = "postId")
	private Integer postId;

	public PostCategoriesId(Integer categoryId, Integer postId) {
		super();
		this.categoryId = categoryId;
		this.postId = postId;
	}

	public PostCategoriesId() {
		super();
	}
@Override
	public Integer getId() {
		
		return categoryId;
	}
	

	public void setCategoryId(Integer categoryId) {
		this.categoryId = categoryId;
	}

	public Integer getPostId() {
		return postId;
	}

	public void setPostId(Integer postId) {
		this.postId = postId;
	}

	public String ToString() {
		return "PostCategoriesId[categoryId = " + categoryId + ",postId =" + postId + "]";
	}

	

}