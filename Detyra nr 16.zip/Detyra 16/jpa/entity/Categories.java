package com.spring.demo.posts.jpa.entity;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.persistence.Column;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.NamedQueries;
import jakarta.persistence.NamedQuery;

@NamedQueries(value = {
		@NamedQuery(name = "ADD_CATEGORY", query = "Insert Into Categories(name,date_created,date_modified) Values(?1,?2,?3)"),
		@NamedQuery(name = "DELETE_CATEGORY", query = "Delete From Categories c Where c.id <: id"),
		@NamedQuery(name = "UPDATE_CATEGORY_BY_NAME", query = "Update Categories c Set c.name =: ?1 where c.id = ?2"),
		@NamedQuery(name = "FIND_CATEGORY_BY_ID", query = "Select c From Categories c Where c.id = :id") })
public class Categories extends BaseEntity<Integer> {
	@ManyToMany(mappedBy = "PostCategories")
	@JsonIgnoreProperties
	private List<Posts> posts = new ArrayList<Posts>();

	@Id
	@Column
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	@Column(name = "name")
	private String name;
	@Column(name = "date_created")
	private LocalDateTime date_created;
	@Column(name = "date_modified")
	private LocalDateTime date_modified;

	public Categories() {
		super();
	}

	public Categories(String name, LocalDateTime date_created, LocalDateTime date_modified, List<Posts> posts) {
		super();
		this.setName(name);
		this.setDate_created(date_created);
		this.setDate_modified(date_created);
		this.posts = posts;
	}

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public LocalDateTime getDate_created() {
		return date_created;
	}

	public void setDate_created(LocalDateTime date_created) {
		this.date_created = date_created;
	}

	public LocalDateTime getDate_modified() {
		return date_modified;
	}

	public void setDate_modified(LocalDateTime date_modified) {
		this.date_modified = date_modified;
	}

	public void setPosts(List<Posts> posts) {
		this.posts = posts;
	}

	public List<Posts> getPosts() {
		return posts;
	}

	public String toString() {
		return "Categories[id = " + id + ",name = " + name + ",date_created =" + date_created + ",date_modified ="
				+ date_modified + ",posts =" + posts + "]";
	}

}
