package com.spring.demo.posts.jpa.entity;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

import org.hibernate.annotations.NamedQueries;
import org.hibernate.annotations.NamedQuery;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@NamedQueries(value = { @NamedQuery(name = "GET_ALL_POSTS", query = "Select p From Posts p"),
		@NamedQuery(name = "GET_ALL_POSTS_BY_TITLE", query = "Select p From Posts  p Where p.title =: tittle"),
		@NamedQuery(name = "GET_ALL_POSTS_BY_DATE_CREATED", query = "Select p from Posts  p where p.date_created =: date_created "),
		@NamedQuery(name = "DELETE_USER_POST", query = "Delete From user_post.Posts p  INNER JOIN user_post u ON u.id = u.p.user_id Where u.id =: id )"),
		@NamedQuery(name = "UPDATE_USERS_POST", query = "Update user_post.posts Set user_post.posts.title = ?1 , user_post.posts.postStatus = ?2  Where EXISTS(Select user_post From user_post INNER JOIN posts ON user_post.id = user_post.posts.user_id Where user_post.id =: id) "),
		@NamedQuery(name = "GET_USER_POSTS_BY_ID", query = "Select user_post.Posts , user_post From user_post u INNER JOIN user_post.Posts up ON u.id = u.up.user_id Where user_post.id =: id"),
		@NamedQuery(name = "GET_POSTS_BY_CATEGORY_NAME", query = "Select cp , categories.name categoryName From PostCategories pc, categories.Posts cp Where categoryName =: categories.name "),
		@NamedQuery(name = "GET_POST_CATEGORIES", query = "Select c,cp From PostCategories pc, categories c , categories.Posts cp"),
		@NamedQuery(name = "GET_POST_CATEGORIES_BY_ID", query = "Select c,cp From PostCategories pc, categories c , categories.Posts cp Where c.id =: id") })
@Entity
@Table(name = "Posts")
public class Posts extends BaseEntity<Integer> {
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "user_id", referencedColumnName = "id")
	@JsonBackReference
	private Users user_post ;
	

	@ManyToMany
	@JoinTable(name = "PostCategories", joinColumns = @JoinColumn(name = "postId"), inverseJoinColumns = @JoinColumn(name = "categoryId"))
	@JsonIgnoreProperties
	private List<Categories> categories = new ArrayList<Categories>();
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	@Column(name = "title")
	private String title;
	@Column(name = "postStatus")
	private String postStatus;
	@Column(name = "date_created")
	private LocalDateTime date_created;
	@Column(name = "date_modified")
	private LocalDateTime date_modified;

	public Posts() {
		super();
	}

	public Posts(String title, String postStatus, LocalDateTime date_created, LocalDateTime date_modified,
			Users user_post, List<Categories> categories) {
		super();

		this.setTitle(title);
		this.setPostStatus(postStatus);
		this.setDate_created(date_created);
		this.setDate_modified(date_modified);
		this.user_post = user_post;
		this.categories = categories;
	}

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getPostStatus() {
		return postStatus;
	}

	public void setPostStatus(String postStatus) {
		this.postStatus = postStatus;
	}

	public LocalDateTime getDate_created() {
		return date_created;
	}

	public void setDate_created(LocalDateTime date_created) {
		this.date_created = date_created;
	}

	public LocalDateTime getDate_modified() {
		return date_modified;
	}

	public void setDate_modified(LocalDateTime date_modified) {
		this.date_modified = date_modified;
	}

	public void setUser_post(Users user_post) {
		this.user_post = user_post;
	}

	public Users getUser_post() {
		return user_post;
	}

	public void setCategories(List<Categories> categories) {
		this.categories = categories;
	}

	public List<Categories> getCategories() {
		return categories;
	}

	public String toString() {
		return "Posts[id = " + id + ",title = " + title + ",postStatus = " + postStatus + ",date_created = "
				+ date_created + ",date_modified =" + date_modified + ",user_post =" + user_post + ",categories = "
				+ categories + "]";
	}

	

}
