package com.spring.demo.posts.jpa.dto;

import java.time.LocalDateTime;

import com.spring.demo.posts.jpa.entity.Posts;

public class UsersDto {
	private Integer id;

	private String username;

	private String email;

	private String password;

	private LocalDateTime date_created;

	private LocalDateTime date_modified;
	private Posts posts;

	public UsersDto() {
		super();
	}

	public UsersDto(String username, String email, String password, LocalDateTime date_created,
			LocalDateTime date_modified, Posts posts) {
		super();

		this.username = username;
		this.email = email;
		this.password = password;
		this.date_created = date_created;
		this.date_modified = date_modified;
		this.posts = posts;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public LocalDateTime getDate_created() {
		return date_created;
	}

	public void setDate_created(LocalDateTime date_created) {
		this.date_created = date_created;
	}

	public LocalDateTime getDate_modified() {
		return date_modified;
	}

	public void setDate_modified(LocalDateTime date_modified) {
		this.date_modified = date_modified;
	}

	public void setPosts(Posts posts) {
		this.posts = posts;
	}

	public Posts getPosts() {
		return posts;
	}

	@Override
	public String toString() {
		return "UsersDto[id =" + id + ",username = " + username + ",email = " + email + ",password = " + password
				+ ", date_created = " + date_created + ", date_modified = " + date_modified + ",posts =" + posts + "]";
	}

	public Integer getId() {

		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

}
