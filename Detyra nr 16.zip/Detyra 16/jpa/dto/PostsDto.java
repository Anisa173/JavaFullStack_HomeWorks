package com.spring.demo.posts.jpa.dto;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.spring.demo.posts.jpa.entity.Categories;
import com.spring.demo.posts.jpa.entity.Users;

public class PostsDto {

	private Integer id;

	private String title;

	private String postStatus;

	private LocalDateTime date_created;

	private LocalDateTime date_modified;
	private Users user_post;
	private List<Categories> categories = new ArrayList<Categories>();

	public PostsDto() {
		super();
	}

	public PostsDto(String title, String postStatus, LocalDateTime date_created, LocalDateTime date_modified,
			Users user_post, List<Categories> categories) {
		super();

		this.setTitle(title);
		this.setPostStatus(postStatus);
		this.setDate_created(date_created);
		this.setDate_modified(date_modified);
		this.user_post = user_post;
		this.categories = categories;

	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getPostStatus() {
		return postStatus;
	}

	public void setPostStatus(String postStatus) {
		this.postStatus = postStatus;
	}

	public LocalDateTime getDate_created() {
		return date_created;
	}

	public void setDate_created(LocalDateTime date_created) {
		this.date_created = date_created;
	}

	public LocalDateTime getDate_modified() {
		return date_modified;
	}

	public void setDate_modified(LocalDateTime date_modified) {
		this.date_modified = date_modified;
	}

	public void setUser_post(Users user_post) {
		this.user_post = user_post;
	}

	public Users getUser_post() {
		return user_post;
	}

	public void setCategories(List<Categories> categories) {
		this.categories = categories;
	}

	public List<Categories> getCategories() {
		return categories;
	}

	public String toString() {
		return "PostsDto[id = " + id + ",title = " + title + ",postStatus = " + postStatus + ",date_created = "
				+ date_created + ",date_modified =" + date_modified + ",user_post =" + user_post + ", categories ="
				+ categories + "]";
	}

}
