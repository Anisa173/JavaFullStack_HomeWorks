package com.spring.demo.posts.jpa.dto;

public class PostCategoriesIdDto {
	private Integer categoryId;
	private Integer postId;

	public PostCategoriesIdDto() {
		super();
	}

	public PostCategoriesIdDto(Integer categoryId, Integer postId) {
		super();
		this.categoryId = categoryId;
		this.postId = postId;
	}

	public Integer getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(Integer categoryId) {
		this.categoryId = categoryId;
	}

	public Integer getPostId() {
		return postId;
	}

	public void setPostId(Integer postId) {
		this.postId = postId;
	}
	public String ToString() {
		return "PostCategoriesIdDto[categoryId = " + categoryId + ",postId =" + postId + "]";
	}
}
