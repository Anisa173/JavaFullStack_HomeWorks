package com.spring.demo.posts.jpa.mapper;

import com.spring.demo.posts.jpa.dto.CategoriesDto;
import com.spring.demo.posts.jpa.dto.PostsDto;
import com.spring.demo.posts.jpa.entity.Categories;
import com.spring.demo.posts.jpa.entity.Posts;

public class CategoriesMapper extends BaseMapper<Categories, CategoriesDto> {

	@Override
	public Categories dtoToEntity(CategoriesDto dto) {
		Categories categories = new Categories();
		categories.setId(dto.getId());
		categories.setName(dto.getName());
		categories.setDate_created(dto.getDate_created());
		categories.setDate_modified(dto.getDate_modified());
		categories.setPosts(dto.getPosts());
		return categories;
	}

	@Override
	public CategoriesDto entityToDto(Categories categories) {
		CategoriesDto c_dto = new CategoriesDto();
		c_dto.setId(categories.getId());
		c_dto.setName(categories.getName());
		c_dto.setDate_created(categories.getDate_created());
		c_dto.setDate_modified(categories.getDate_modified());
		c_dto.setPosts(categories.getPosts());
		return c_dto;
	}

	
	

}
