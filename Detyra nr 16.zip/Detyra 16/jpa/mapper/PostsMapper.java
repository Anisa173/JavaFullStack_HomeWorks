package com.spring.demo.posts.jpa.mapper;

import java.util.List;

import com.spring.demo.posts.jpa.dto.PostsDto;
import com.spring.demo.posts.jpa.entity.Posts;

public class PostsMapper extends BaseMapper<Posts, PostsDto> {

	@Override
	public PostsDto entityToDto(Posts entity) {
		PostsDto dto = new PostsDto();
		dto.setId(entity.getId());
		dto.setTitle(entity.getTitle());
		dto.setPostStatus(entity.getPostStatus());
		dto.setDate_created(entity.getDate_created());
		dto.setDate_modified(entity.getDate_modified());
		return dto;
	}

	@Override
	public Posts dtoToEntity(PostsDto dto) {
		Posts p = new Posts();
		p.setId(dto.getId());
		p.setTitle(dto.getTitle());
		p.setPostStatus(dto.getPostStatus());
		p.setDate_created(dto.getDate_created());
		p.setDate_modified(dto.getDate_modified());
		return p;
	}


	



	

	

	

}
