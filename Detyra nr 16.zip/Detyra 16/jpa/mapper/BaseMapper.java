package com.spring.demo.posts.jpa.mapper;

import com.spring.demo.posts.jpa.entity.BaseEntity;

public abstract class BaseMapper<K extends BaseEntity<Integer>, D> {

	public abstract K dtoToEntity(D dto);

	public abstract D entityToDto(K entity);

	
	

}
