package com.spring.demo.posts.jpa.mapper;

import com.spring.demo.posts.jpa.dto.UsersDto;
import com.spring.demo.posts.jpa.entity.Users;

public class UserMapper extends BaseMapper<Users, UsersDto> {

	@Override
	public Users dtoToEntity(UsersDto dto) {
		Users entity = new Users();
		entity.setId(dto.getId());
		entity.setUsername(dto.getUsername());
		entity.setEmail(dto.getEmail());
		entity.setPassword(dto.getPassword());
		entity.setDate_created(dto.getDate_created());
		entity.setDate_modified(dto.getDate_modified());
		entity.setPosts(dto.getPosts());
		return entity;
	}

	@Override
	public UsersDto entityToDto(Users entity) {
		UsersDto dto = new UsersDto();
		dto.setId(entity.getId());
		dto.setUsername(entity.getUsername());
		dto.setEmail(entity.getEmail());
		dto.setPassword(entity.getPassword());
		dto.setDate_created(entity.getDate_created());
		dto.setDate_modified(entity.getDate_modified());
		dto.setPosts(entity.getPosts());
		return dto;
	}

	

	
	
	

}
