Create database userPost;
use userPost;
