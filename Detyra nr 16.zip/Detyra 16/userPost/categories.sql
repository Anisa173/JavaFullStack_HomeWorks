CREATE TABLE categories (
    id INTEGER AUTO_INCREMENT NOT NULL,
    name VARCHAR(255) NOT NULL,
    date_created DATETIME DEFAULT CURRENT_TIMESTAMP,
    date_modified DATETIME ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
);
Insert into userpost.categories(name)
Values('Category 1'),
('Category 2'),
('Category 3'),
('Category 4'),
('Category 5');