CREATE TABLE users (
    id INTEGER AUTO_INCREMENT NOT NULL,
    username VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    date_created DATETIME DEFAULT CURRENT_TIMESTAMP,
    date_modified DATETIME ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
);
insert into users(username , email , password)
values('user1','user1@gmail.com','passwordi1'),
('user2','user2@gmail.com','passwordi2'),
('user3','user3@gmail.com','password3'),
('user4','user4@gmail.com','password4');