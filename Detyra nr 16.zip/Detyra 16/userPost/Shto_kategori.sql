Insert into userpost.categories(name)
Values('Category 1'),
('Category 2'),
('Category 3'),
('Category 4'),
('Category 5');