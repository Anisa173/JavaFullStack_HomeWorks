insert into userpost.posts(title , postStatus , user_id)
Values('Post1','Body of Post 1',4);
insert into userpost.posts(title , postStatus , user_id)
Values('Post2','Body of Post 2',1);
insert into userpost.posts(title , postStatus , user_id)
Values('Post3','Body of Post 3',3);
insert into userpost.posts(title , postStatus , user_id)
Values('Post4','Body of Post 4',5);
insert into userpost.posts(title , postStatus , user_id)
Values('Post5','Body of Post 5',2);

