CREATE TABLE postCategories (
    
    categoriesId INTEGER NOT NULL,
    postId INTEGER NOT NULL,
    PRIMARY KEY (categoriesId,postId),
    FOREIGN KEY (categoriesId)
        REFERENCES categories (id),
    FOREIGN KEY (postId)
        REFERENCES posts (id)
       
);
 
 
   
   
   