insert into userpost.users(username , email , password)
values('user1','user1@gmail.com','passwordi1'),
('user2','user2@gmail.com','passwordi2'),
('user3','user3@gmail.com','password3'),
('user4','user4@gmail.com','password4'),
('user5','user5@gmail.com','password5');
