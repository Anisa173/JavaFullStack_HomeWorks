 Insert into userpost.postcategories(postId,categoriesId)
   Values(1,2),
   (2,4),
   (3,5),
   (4,1),
   (5,3);