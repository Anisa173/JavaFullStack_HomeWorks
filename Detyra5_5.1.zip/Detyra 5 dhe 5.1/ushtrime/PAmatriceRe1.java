package seanca5.ushtrime;

/*
			 * 5. Shkruaj një program që ndryshon kolonat me rreshtat e një matrice.Pra në
			 * vendin e rreshtave vendos kolonat dhe në vendin e kolonave vendos rreshtat.
			 * Përdorni nëse është e nevojshme një matricë tjetër.
			 **/
import java.util.Scanner;

public class PAmatriceRe1 {
	private static Scanner input = new Scanner(System.in);
	static int i, j, k, rr, temp;
	static int[][] array2 = new int[rr][k];
	static int[][] array1 = new int[rr][k];

	public static void main(String[] args) {
		array2 = afishoMatrice(rr, k);
		array1 = afishoMRE(array2);
	}

	public static int[][] afishoMatrice(int rr, int k) {
		int[][] matrica = new int[rr][k];
		System.out.println("Numri i rreshtave te matrices eshte:");
		rr = input.nextInt();
		System.out.println("Numri i kolonave te matrices eshte:");
		k = input.nextInt();
		System.out.println("Afisho matricen me elemente!");
		for (i = 0; i < rr; i++) {
			for (j = 0; j < k; k++) {
				matrica[i][j] = input.nextInt();
			}
			System.out.println();
		}
		for (i = 0; i < rr; i++) {
			for (j = 0; j < k; k++) {
				System.out.print(matrica[i][j]);
			}
			System.out.println();
		}
		return matrica;
	}

	public static int[][] afishoMRE(int[][] array) {
		// Nqs numri i rreshtave me i madh se ai i kolonave
		if (rr > k) {
			temp = rr;
			rr = k;
			k = temp;
		}
		// Nqs numri i kolonave eshte me i madh se numri i rreshtave
		else if (rr < k) {
			temp = k;
			k = rr;
			rr = temp;
		}
		System.out.println("Afisho matricen e RE me elemente:");
		for (i = 0; i < rr; i++) {
			for (j = 0; j < k; j++) {
				array[i][j] = input.nextInt();
			}
			System.out.println();
		}
		for (i = 0; i < rr; i++) {
			for (j = 0; j < k; j++) {
				System.out.print(array[i][j]);
			}
			System.out.println();
		}
		return array;

	}

}
