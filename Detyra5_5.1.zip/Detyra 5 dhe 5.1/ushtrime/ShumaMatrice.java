package seanca5.ushtrime;

import java.util.Scanner;

public class ShumaMatrice {
	/*
	 * 6. Shkruaj nje program që printon shumën e të gjithë kolonave të një matrice
	 * (array 2d)
	 **/
	private static Scanner c = new Scanner(System.in);
	static int i, j, n, m, r = 10, result;
	static int[][] matrica = new int[n][m];

	public static void main(String[] args) {
		matrica = afishoM(n, m);
		result = shumeT(matrica);
	}

	public static int[][] afishoM(int n, int m) {
		int[][] matrica1 = new int[n][m];
		System.out.println("Percakto numrin e rreshtave dhe te kolonave te matrices" + " " + '\n');
		System.out.println("Nr i kolonave eshte:");
		m = c.nextInt();
		System.out.println("Nr i rreshtave eshte:");
		n = c.nextInt();
		System.out.println("Afisho matricen me elemente:");
		for (i = 0; i < matrica1.length; i++) {
			for (j = 0; j < matrica1[i].length; j++) {
				matrica1[i][j] = c.nextInt();
			}
			System.out.println();
		}
		for (i = 0; i < matrica1.length; i++) {
			for (j = 0; j < matrica1[i].length; j++) {
				System.out.println(matrica1[i][j]);
			}
			System.out.println();
		}

		return matrica1;
	}

	public static int shumeT(int[][] array2D) {
		int[] kolona = new int[m];
		int shuma = 0;
		int shumeKolone = 0;
		for (j = 0; j < array2D.length; j++) {
			for (i = 0; i < array2D[j].length; i++) {
				shumeKolone = shumeKolone + array2D[i][j];
				kolona[j] = shumeKolone;
			}
			System.out.println("Shuma e elementeve te kolones" + " " + j + " " + "eshte:");
			System.out.print(kolona[j]);
			shuma = shuma + kolona[j];
		}
		System.out.println("Shuma Totale e te gjitha kolonave te matrices eshte :");
		System.out.print(shuma);
		return shuma;
	}
}