package seanca5.ushtrime;

import java.util.Scanner;

public class Ushtrimi0 {
	/*
	 * 0) Shkruani nje program ne JAVA qe merr nga perdoruesi 2 matrica , njeren 1D
	 * dhe tjetren 2D. Pas marrjes se te dy matricave, te printohen te dyja ne
	 * console.
	 **/
	private static Scanner in = new Scanner(System.in);
	static int i, j, n, m;
	static int[] array1D = new int[n];
	static int[][] array2D = new int[n][m];

	public static void main(String[] args) {
		array1D = afishoVektor(n);

	}

	public static int[] afishoVektor(int n) {
		int[] a = new int[n];
		System.out.println("Vendos gjatesine e vektorit");
		n = in.nextInt();
		System.out.println("Popullo vektorin me elemente");
		for (i = 0; i < n; i++) {
			a[i] = in.nextInt();
		}
		System.out.println("Afisho vektor");
		for (i = 0; i < n; i++) {
			System.out.print('\t' + a[i] + '\t');
		}
		return a;
	}

	public static int[][] afishoMatrice(int n, int m) {
		int[][] arr = new int[n][m];
		System.out.println("Vendos nr e rreshtave");
		n = in.nextInt();
		System.out.println("Vendos nr e kolonave");
		m = in.nextInt();
		System.out.println("Popullo matricen me elemente");
		for (i = 0; i < n; i++) {
			for (j = 0; j < m; j++) {
				arr[i][j] = in.nextInt();
			}
			System.out.println();
		}
		System.out.println("Afisho matrice");
		for (i = 0; i < n; i++) {
			for (j = 0; j < m; j++) {
				System.out.print(arr[i][j]);
			}
			System.out.println();
		}
		return arr;
	}
}