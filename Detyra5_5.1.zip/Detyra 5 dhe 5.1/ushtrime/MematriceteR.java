package seanca5.ushtrime;
/*Me matrice ndihmese ose te Re
			 * 5. Shkruaj një program që ndryshon kolonat me rreshtat e një matrice.Pra në
			 * vendin e rreshtave vendos kolonat dhe në vendin e kolonave vendos rreshtat.
			 * Përdorni nëse është e nevojshme një matricë tjetër.
			 **/
import java.util.Scanner;
public class MematriceteR {
			private static Scanner input = new Scanner(System.in);
			static int i, j, k, rr;
			static int[][] array2 = new int[rr][k];
			static int[][] array1 = new int[k][rr];
			static int d;

			public static void main(String[] args) {
				// TODO Auto-generated method stub
				array2 = afishoMatrice(rr, k);
				array1 = afishoMRE(array2);
			}

			public static int[][] afishoMatrice(int rr, int k) {
				int[][] matrica = new int[rr][k];
				System.out.println("Numri i rreshtave te matrices eshte:");
				rr = input.nextInt();
				System.out.println("Numri i kolonave te matrices eshte:");
				k = input.nextInt();
				System.out.println("Popullo matricen me elemente!");
				for (i = 0; i < rr; i++) {
					for (j = 0; j < k; k++) {
						matrica[i][j] = input.nextInt();
					}
					System.out.println();
				}
				System.out.println("Afisho matricen me elemente!");
				for (i = 0; i < rr; i++) {
					for (j = 0; j < k; k++) {
					System.out.print(matrica[i][j]);
					}
					System.out.println();
				}
				return matrica;
			}

			public static int[][] afishoMRE(int[][] array) {
		int[][] mt1 = new int[k][rr];

	System.out.println("Popullo matricen e RE me elemente:");
				for (i = 0; i <k; i++) {
					for (j = 0; j <rr; j++) {
						mt1[i][j]= array[j][i];
					}
					System.out.println();
				}
				for (i = 0; i < k; i++) {
					for (j = 0; j < rr; j++) {
						System.out.print(mt1[i][j]);
					}
					System.out.println();
				}
				return array;
	}

}
