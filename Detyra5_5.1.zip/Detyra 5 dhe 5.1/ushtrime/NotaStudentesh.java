package seanca5.ushtrime;

import java.util.Scanner;

public class NotaStudentesh {
	/**
	 * 8. Një matricë ruan notat që jane dhënë për 10 studentë nga 5 pedagogë.
	 * a) Printo notat per secilin student. b) Ruaj në një array 1D mesataren për cdo
	 * student. c) Printo mesataren më të lartë mes 10 studentëve.
	 */

	private static Scanner sc = new Scanner(System.in);
	static int nrSt = 10, i, j;
	static int nrProvime = 5, result, temp;
	static int[][] provime = new int[nrSt][nrProvime];
	static int[] averageGrades = new int[nrSt];
	static int hightAverage;

	public static void main(String[] args) {
		provime = printoNotat(nrSt, nrProvime);
		averageGrades = mesatareStudenti(provime);
		result = afishoMax(averageGrades);
	}

	public static int[][] printoNotat(int nrSt, int nrProvime) {
		int[][] notat = new int[nrSt][nrProvime];
		System.out.println("Afishoni notat e 10 studenteve te mbetur!" + '\n');
		for (j = 0; j < nrProvime; j++) {
			for (i = 0; i < nrSt; i++) {
				notat[i][j] = sc.nextInt();
			}
			System.out.println();
		}
		for (j = 0; j < nrProvime; j++) {
			for (i = 0; i < nrSt; i++) {
				System.out.print(notat[i][j]);
			}
			System.out.println();
		}
		return notat;
	}

	public static int[] mesatareStudenti(int[][] array2) {
		int[] mesatarjaSemestrale = new int[nrSt];
		int shuma = 0;
		int m = 0;
		for(i = 0;i < nrSt;i++) {
			System.out.println("Studenti me kod" + " " + (i) + " " + "per kete semester zoteron mesataren" + " :");
			for(j = 0; j < nrProvime; j++) {
				shuma = shuma + array2[i][j];
				m = (shuma / nrProvime);
				mesatarjaSemestrale[i] = m;
			}
			System.out.print(mesatarjaSemestrale[i]);
		}
		return mesatarjaSemestrale;
	}

	public static int afishoMax(int[] arr) {
		System.out.println("Mesatarja me e larte e ka vleren:");
		for(int k = 0; k < nrSt-1; k++) {
			for(i = k + 1; i < nrSt; j++) {
				if (arr[k] < arr[i]) {
					temp = arr[i];
					arr[i] = arr[k];
					arr[k] = temp;
					System.out.println(arr[k]);
					System.out.println(arr[i]);
				} else {
					System.out.println(arr[k]);
					System.out.println(arr[i]);
				}
			}
			hightAverage = arr[0];
			System.out.println(hightAverage);
		}
		return hightAverage;
	}
}
