package seanca5.ushtrime;

/*4. Gjej elementin më të vogël në një array një dimensional dhe përcakto indexin se ku gjendet ai; Po në një array dy dimensional?**/
import java.util.Scanner;

public class ElemmëiVogël {
	static int i, j, k, n, m, t, result;
	static int[][] array = new int[m][n];
	static int[] array1 = new int[m];
	private static Scanner in = new Scanner(System.in);

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		array = afishoM(m, n);
		array1 = gjejMin(array);
        result = elementiMin(array1);
	}

	public static int[][] afishoM(int m, int n) {
		int[][] a = new int[m][n];
		System.out.println("Percaktoni numrin e rreshtave te matrices:");
		m = in.nextInt();
		System.out.println("Percaktoni numrin e kolonave te matrices:");
		n = in.nextInt();
		System.out.println("Populloni matricen me elemente");
		for (i = 0; i < a.length; i++) {
			for (j = 0; j < a[i].length; j++) {
				a[i][j] = in.nextInt();
			}
			System.out.println();
		}
		System.out.println("Afishoni matricen me elemente");
		for (i = 0; i < a.length; i++) {
			for (j = 0; j < a[i].length; j++) {
				System.out.print(a[i][j]);
			}
			System.out.println();
		}

		return a;
	}

	public static int[] gjejMin(int[][] arr) {

		int[] kolona = new int[m];
		System.out.println("Afisho elementet minimum te çdo rreshti");

		for (i = 0; i < arr.length; i++) {
			for (j = 0; j < arr[i].length; j++) {
				for (int k = j + 1; k < arr[i].length; k++) {
					if (arr[i][j] > arr[i][k]) {
						t = arr[i][k];
						arr[i][k] = arr[i][j];
						arr[i][j] = t;
						System.out.println(arr[i][j]);
						System.out.println(arr[i][k]);
					} else {
						System.out.println(arr[i][j]);
						System.out.println(arr[i][k]);
					}
				}
			}
			kolona[i] = arr[i][0];
			System.out.println(kolona[i]);
		}
		return kolona;
	}

	public static int elementiMin(int[] kol) {
		int minimum = 0;
		System.out.println("Afisho elementin me te vogel te matrices");
		for (i = 0; i < kol.length; i++) {
			for (k = i + 1; k < kol.length; k++) {
				if (kol[i] > kol[k]) {
					t = kol[k];
					kol[k] = kol[i];
					kol[i] = t;
					System.out.println(kol[i]);
					System.out.println(kol[k]);
				} else {
					System.out.println(kol[i]);
					System.out.println(kol[k]);
				}
			}
			minimum = kol[0];
			System.out.println(minimum);
		}
		return minimum;
	}
}