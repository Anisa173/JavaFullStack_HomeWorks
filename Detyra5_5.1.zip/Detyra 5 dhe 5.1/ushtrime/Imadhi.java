package seanca5.ushtrime;
/**	1.	Gjej maximumin mes dy numrave që jepen si parametër në një metodë*/
import java.lang.Math;
public class Imadhi {
static int x,y,result,rangu = 100;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
result = afishoMax(x,y);
	}
public static int afishoMax(int x,int y) {
int vleraMadhe;
	x=(int)(Math.random()*rangu);
y=(int)(Math.random()*rangu);
System.out.println("Afisho numrin e pare:");
System.out.println(x);
System.out.println("Afisho numrin e dyte:");
System.out.println(y);
if(x>y) {vleraMadhe = x;System.out.println("Maximumi eshte:"+ vleraMadhe);}
else if(y>x) { vleraMadhe = y;System.out.println("Vlera maximum eshte:" + vleraMadhe);}
else {x=y; vleraMadhe = x;System.out.println("Vlerat e dy numrave jane te barabarte!");}
return vleraMadhe;
}}