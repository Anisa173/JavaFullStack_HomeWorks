package seanca5.ushtrime;

import java.util.Scanner;

public class VleresimFilmi {
	/*
	 * Nje matrice ruan "review" qe jane per pese filma qe supoyohen te jene bere
	 * nga 10 profesioniste. 1.Printoni "review" qe ka marre cdo film nga
	 * profesionistet. 2.Te printohet indeksi i filmit qe ka marre me shume
	 * "review".
	 **/
	static int i, j, k, t, winner, noFilm = 5;
	static int noRegjizor = 10;
	static int[][] review = new int[noFilm][noRegjizor];
	static int[] revFilm = new int[noFilm];

	private static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {
		review = vlerProfesionist(noFilm, noRegjizor);
		revFilm = vlerFilmi(review);
		winner = filmiFiton(revFilm);
	}

	public static int[][] vlerProfesionist(int noFilm, int noRegjizor) {
		int[][] film = new int[noFilm][noRegjizor];
		System.out.println("Afishoni 'review' te bere nga profesionistet tane per cdo film!");
		for (i = 0; i < film.length; i++) {
			for (j = 0; j < film[i].length; j++) {
				film[i][j] = sc.nextInt();
			}
			System.out.println();
		}
		for (i = 0; i < film.length; i++) {
			for (j = 0; j < film[i].length; j++) {
				System.out.println(film[i][j]);
			}
			System.out.println();
		}
		return film;
	}

	public static int[] vlerFilmi(int[][] array2D) {
		int sh = 0;
		int[] vlera = new int[noFilm];
		System.out.println("Afishoni piket totale qe ka arritur te marre cdo film nga juria e vleresimit!");
		for (i = 0; i < array2D.length; i++) {
			System.out.println("Filmi" + " " + (i + 1) + " " + "ka arritur : ");
			for (j = 0; j < array2D[i].length; j++) {
				sh = sh + array2D[i][j];
				vlera[i] = sh;
			}
			System.out.print(vlera[i]);
		}
		return vlera;
	}

	public static int filmiFiton(int[] piket) {
		int maximum = 0;
		System.out.println("Filmi qe fiton kompeticionin eshte :");
		i = 0;
		for (k = i + 1; k < piket.length; k++) {
			if (piket[i] < piket[k]) {
				t = piket[i];
				piket[i] = piket[k];
				piket[k] = t;
				maximum = k;
				System.out.println(maximum);
			} else {
				maximum = i;
				System.out.println(maximum);
			}
		}
		return maximum;
	}

}
