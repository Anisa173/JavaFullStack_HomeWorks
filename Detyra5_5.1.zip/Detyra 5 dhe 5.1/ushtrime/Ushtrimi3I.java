package seanca5.ushtrime;

import java.util.Scanner;
import java.lang.Math;

public class Ushtrimi3I {
	/*
	 * 3) Shkruaj nje program ne Java qe gjen numrin me te madh tek dhe numrin me te
	 * madh cift ne nje array dhe i printon ato ne console.
	 */
	private static Scanner cn = new Scanner(System.in);
	static int i, j, t, temp, n, m, r = 100;
	static int maxT, maxC;
	static int[][] mt = new int[n][m];
	static int[] nrT = new int[n];
	static int[] nrC = new int[n];

	public static void main(String[] args) {
		mt = afishoMatr(n, m);
		nrT = afishoTek(mt);
		maxT = afishoMaxt(nrT);
	    nrC = afishoCift(mt);
	   maxC = afishoMaxc(nrC);
	}

	public static int[][] afishoMatr(int n, int m) {
		int[][] mtr = new int[n][m];
		System.out.println("Numri i rreshtave eshte:");
		n = cn.nextInt();
		System.out.println("Numri i kolonave eshte:");
		m = cn.nextInt();
		System.out.println("Popullo matricen me elemente");
		for (i = 0; i < mtr.length; i++) {
			for (j = 0; j < mtr[i].length; j++) {
				mtr[i][j] = (int) (Math.random() * r);
			}
			System.out.println();
		}
		System.out.println("Afisho matricen me elemente");
		for (i = 0; i < mtr.length; i++) {
			for (j = 0; j < mtr[i].length; j++) {
				System.out.println(mtr[i][j]);
			}
			System.out.println();
		}
		return mtr;
	}

	public static int[] afishoTek(int[][] arr) {
		int maximumT = 0;
		int[] tek = new int[n];

		System.out.println("Afisho numrat tek me te medhenj te cdo rreshti");
		for (i = 0; i < arr.length; i++) {
			for (j = 0; j < arr[i].length; j++) {
				for (int k = j + 1; j < arr[i].length; j++) {
					if (arr[i][j] < arr[i][k]) {
						t = arr[i][j];
						arr[i][j] = arr[i][k];
						arr[i][k] = t;
						System.out.println(arr[i][j]);
						System.out.println(arr[i][k]);
					} else {
						System.out.println(arr[i][j]);
						System.out.println(arr[i][k]);
					}
				}
//Renditem elementet e cdo rreshti sipas rendit zbrites,me poshte vlerat maximale tek te cdo rreshti i kalojme ne nje array 1D			
				if ((arr[i][j] % 2) != 0) {
					maximumT = arr[i][j];
					tek[i] = maximumT;
					System.out.println(tek[i]);
					break;
				} else {
					tek[i] = 0;
					System.out.println(tek[i]);
				}
			}
		}
		return tek;
	}

	public static int afishoMaxt(int[] t) {
		System.out.println("Afisho numrin tek me te madh te te gjithe rreshtave te matrices!");
		int vleraMT = 0;
		int i = 0;
		for (int k = i + 1; k < t.length; k++) {
			if (t[i] < t[k]) {
				temp = t[i];
				t[i] = t[k];
				t[k] = temp;
				System.out.println(t[i]);
			} else {
				System.out.println(t[i]);
			}
			vleraMT = t[i];
			System.out.println(vleraMT);
		}
		return vleraMT;
	}
	
	public static int[] afishoCift(int[][] arr1) {
		int maximumC = 0;
		int[] cift = new int[n];

		System.out.println("Afisho numrat cift me te medhenj te cdo rreshti");
		for (i = 0; i < arr1.length; i++) {
			for (j = 0; j < arr1[i].length; j++) {
				for (int k = j + 1; j < arr1[i].length; j++) {
					if (arr1[i][j] < arr1[i][k]) {
						t = arr1[i][j];
						arr1[i][j] = arr1[i][k];
						arr1[i][k] = t;
						System.out.println(arr1[i][j]);
						System.out.println(arr1[i][k]);
					} else {
						System.out.println(arr1[i][j]);
						System.out.println(arr1[i][k]);
					}
				}
//Renditem elementet e cdo rreshti sipas rendit zbrites			
				if ((arr1[i][j] % 2) == 0) {
					maximumC = arr1[i][j];
					cift[i] = maximumC;
					System.out.println(cift[i]);
					break;
				} else {
					cift[i] = 0;
					System.out.println(cift[i]);
				}
			}
		}
		return cift;
	}

	public static int afishoMaxc(int[] c) {
		System.out.println("Afisho numrin cift me te madh te te gjithe rreshtave te matrices!");
		int vleraMC = 0;
		int i = 0;
		for (int k = i + 1; k < c.length; k++) {
			if (c[i] < c[k]) {
				temp = c[i];
				c[i] = c[k];
				c[k] = temp;
				System.out.println(c[i]);
			} else {
				System.out.println(c[i]);
			}
			vleraMC = c[i];
			System.out.println(vleraMC);
		}
		return vleraMC;
	}

}
