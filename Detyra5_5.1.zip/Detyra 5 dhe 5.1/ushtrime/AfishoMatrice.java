package seanca5.ushtrime;

import java.util.Scanner;

public class AfishoMatrice {
static int i, j;
			static int n = 3;
			static int m = 5;
			static int[][] nje = new int[n][m];
private static Scanner input = new Scanner(System.in);
			public static void main(String[] args) {
				nje = afisho(n, m);

			}

			public static int[][] afisho(int n, int m) {
				int[][] array = new int[n][m];
				System.out.println('\n' + "Popullo" + '\n');
				for (i = 0; i < n; i++) {
					for (j = 0; j < m; j++) {
						array[i][j] = input.nextInt();
					}
					System.out.println();
				}
				System.out.println("Afisho matricen");
				for (i = 0; i < n; i++) {
					for (j = 0; j < m; j++) {
						System.out.print(array[i][j]);
					}
					System.out.println();
				}
				return array;
	}

}
