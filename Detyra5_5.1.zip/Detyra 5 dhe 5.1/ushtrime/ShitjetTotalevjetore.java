package seanca5.ushtrime;

import java.util.Scanner;
public class ShitjetTotalevjetore {
private static Scanner x = new Scanner(System.in);
	/**
	 * 9. Llogarit sa është shuma totale që ka hyrë në llogarinë bankare të
	 * kompanisë “Glina” për shitjet që ajo ka kryer në 5 pika të ndryshme të
	 * qytetit brenda 1 viti, kur për çdo muaj kemi statistika të nxjerra mbi
	 * shitjet totale të produkteve të saja.
	 */
	static int n=12 ; 
	static int m=5 ;
	static int xhiroVjetore;
	static int[][] totaliShitjeveV = new int[n][m];

	public static void main(String[] args) {
		totaliShitjeveV = afishoVleftat(n, m);
        xhiroVjetore = vleraTvjetore(totaliShitjeveV);
	}

	public static int[][] afishoVleftat(int n,int m) {
	int[][] shMujore = new int[n][m];
	System.out.println("Beni gati raportin vjetor!"+'\n');
	System.out.println("Numri i muajve normalisht eshte 12.");	
	System.out.println("Behet fjale per shitjet vjetore ne 5 pikat tona te furnizimit."+'\n');	
		for(int i = 0; i < n; i++) {
			for(int j = 0; j < shMujore[i].length;j++) {
				shMujore[i][j] = x.nextInt(); 
			}
		System.out.println();
		}
		for(int i = 0;i < n; i++) {
			for (int j = 0;j < m; j++) {
				System.out.print('\t' + shMujore[i][j] + '\t');
			}
			System.out.println();
		}
		return shMujore;
	}

	public static int vleraTvjetore(int[][] shT) {
		int[] pikaShitjesT = new int[m];
		int shuma_i = 0;
		int totalVjetor = 0;
		for (int j = 0;j < m;j++) {
			System.out.println('\n'+"Vlefta totale vjetore qe kompania 'Glina' ka siguruar nga klienti" + " " + (j + 1) + " "
					+ "eshte:"+'\n');
			for(int i = 0; i < shT[j].length;i++) {
				shuma_i = shuma_i + shT[i][j];
				pikaShitjesT[j] = shuma_i;}
				System.out.println(pikaShitjesT[j]);
			totalVjetor = totalVjetor + pikaShitjesT[j];}
			System.out.println('\n'+"Vlefta totale qe kompania 'Glina' ka siguruar nga klientet ne fund te vitit eshte:"+'\n');
			System.out.print(totalVjetor);
		
		return totalVjetor;
	}
}