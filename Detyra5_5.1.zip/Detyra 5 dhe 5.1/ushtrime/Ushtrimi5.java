package seanca5.ushtrime;

import java.util.Scanner;

public class Ushtrimi5 {
	/*
	 * 5) Per nje matrice 2 dimensionale te dhene gjeni elementet me te medhenj te
	 * cdo rreshti dhe elementet me te medhenj te cdo kolone.
	 **/
	private static Scanner input = new Scanner(System.in);
	static int n, m, k, temp, i, j;
	static int[][] array = new int[n][m];
	static int[] rreshta = new int[n];
	static int[] kolona = new int[m];

	public static void main(String[] args) {
		array = afishoMatrice(n, m);
        kolona = afishoKolona(array);
	    rreshta =afishoRreshta(array);
	}

	public static int[][] afishoMatrice(int n, int m) {
		int[][] matrica = new int[n][m];
		System.out.println("Numri i kolonave:");
		m = input.nextInt();
		System.out.println("Numri i rreshtave:");
		n = input.nextInt();
		System.out.println("Popullo matricen me te dhena:");
		for (i = 0; i < n; i++) {
			for (j = 0; j < m; j++) {
				matrica[i][j] = input.nextInt();
			}
			System.out.println();
		}
		System.out.println("Afisho matricen me elemente :");
		for (i = 0; i < n; i++) {
			for (j = 0; j < m; j++) {
				System.out.print(matrica[i][j]);
			}
			System.out.println();
		}
		return matrica;

	}

	public static int[] afishoKolona(int[][] c) {
		int[] kol = new int[m];
		System.out.println("Afishoni elementin me te madh per cdo kolone");
		for (j = 0; j < m; j++) {
			for (i = 0; i < c[j].length - 1; i++) {
				for (k = i + 1; i < c[j].length; i++) {
					if (c[i][j] < c[k][j]) {
						temp = c[i][j];
						c[i][j] = c[k][j];
						c[k][j] = temp;
						System.out.println(c[i][j]);
						System.out.println(c[k][j]);
					} else {
						System.out.println(c[i][j]);
						System.out.println(c[k][j]);
					}
				}
				kol[j] = c[0][j];
			}
			System.out.println(kol[j]);
		}
		return kol;
	}
	public static int[] afishoRreshta(int[][] b) {
		int[] rresht = new int[n];
		System.out.println("Afishoni elementin me te madh per cdo rresht");
		for (i = 0; i < n; i++) {
			for (j = 0; j < b[i].length - 1; j++) {
				for (k = j + 1; k < b[i].length; k++) {
					if (b[i][j] < b[i][k]) {
						temp = b[i][j];
						b[i][j] = b[i][k];
						b[i][k] = temp;
						System.out.println(b[i][j]);
						System.out.println(b[i][k]);
					} else {
						System.out.println(b[i][j]);
						System.out.println(b[i][k]);
					}
				}
				rresht[i] = b[i][0];
			}
			System.out.println(rresht[i]);
		}
		return rresht;
	}
	
}
