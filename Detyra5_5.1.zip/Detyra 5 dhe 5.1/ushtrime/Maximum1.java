package seanca5.ushtrime;

import java.util.Scanner;

public class Maximum1 {
	static int gjatesia = 4;
	static int temp, maximum;
	static int[] array = new int[gjatesia];
	static int[] array1 = new int[gjatesia];
	private static Scanner input = new Scanner(System.in);

	/**
	 * 2. Gjej maximumin mes tre numrave (4 numrave) (hint: ripërdor metodën e
	 * krijuar në pikën e parë)
	 **/
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		array = afisho();
		array1 = afishoMaximum(array);
	}

	public static int[] afisho() {

		System.out.println("Percakto gjatesine e vektorit:");
		gjatesia = input.nextInt();
		int[] numri = new int[gjatesia];
		System.out.println("Ploteso vektorin me te dhena:");
		for (int i = 0; i < gjatesia; i++) {
			numri[i] = input.nextInt();
		}
		System.out.println("Printo vektorin:");
		for (int i = 0; i < gjatesia; i++) {
			System.out.println(numri[i]);
		}
		return numri;
	}

	public static int[] afishoMaximum(int[] arr1) {
		
		System.out.println("Maximumi i pare i elmenteve eshte:");
		int j = 0; 
			for (int i = j + 1; i < gjatesia; i++) {
				if (arr1[j] > arr1[i]) {
					temp = arr1[j];
					arr1[j] = arr1[i];
					arr1[i] = temp;

					System.out.print(arr1[j]);
					System.out.print(arr1[i]);
					break;

				} else {
					System.out.print(arr1[j]);
					System.out.print(arr1[i]);

				}
				maximum = arr1[gjatesia - 1];
				System.out.println(maximum);
			}
		
		return arr1;
	}
}
