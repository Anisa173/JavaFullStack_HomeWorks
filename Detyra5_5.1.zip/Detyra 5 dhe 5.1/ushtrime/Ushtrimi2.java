package seanca5.ushtrime;

import java.util.Scanner;

public class Ushtrimi2 {
	/*
	 * 2) Shkruaj nje metode Java qe rendit nje array dhe merr si parameter arrayn
	 * 1D te pa-renditur dhe nje flag boolean qe tregon nqs renditja duhet te jete
	 * ascending apo descending. Metoda te riktheje vektorin e renditur sipas
	 * menyres se kerkuar nga boolean flag.
	 **/
	private static Scanner in = new Scanner(System.in);
	static int i, j, n, m;
	static int[] array1D = new int[n];
	static boolean asc = true;
	static boolean result;
	static int[] renditja = new int[n];

	public static void main(String[] args) {
		array1D = afishoVektor(n);
		renditja = renditVektorin(array1D, result);
	}

	public static int[] afishoVektor(int n) {
		int[] a = new int[n];
		System.out.println("Vendos gjatesine e vektorit");
		n = in.nextInt();
		System.out.println("Popullo vektorin me elemente");
		for (i = 0; i < n; i++) {
			a[i] = in.nextInt();
		}
		System.out.println("Afisho vektor");
		for (i = 0; i < n; i++) {
			System.out.print('\t' + a[i] + '\t');
		}
		return a;
	}

	public static int[] renditVektorin(int[] arr, boolean flag) {

		// Renditim elementet ne rendin rrites
		System.out.println("Rendit elementet e vektorit");
		for (j = n - 1; j > 0; j--) {
			for (i = 0; i <= j; i++) {
				if (arr[i] > arr[i + 1]) {
					m = arr[i];
					arr[i] = arr[i + 1];
					arr[i + 1] = m;
					System.out.println(arr[i]);
					System.out.println(arr[i + 1]);
				} else {
					System.out.println(arr[i]);
				}
			}
			flag = asc;
			System.out.println(flag + " - " + "Renditja eshte kryer ne rendin rrites.");
		}
		return arr;
	}

}