package seanca5.ushtrime;
import java.util.Scanner;

/*
	 * 5. Shkruaj një program që ndryshon kolonat me rreshtat e një matrice.Pra në
	 * vendin e rreshtave vendos kolonat dhe në vendin e kolonave vendos rreshtat.
	 * Përdorni nëse është e nevojshme një matricë tjetër.
	 **/
public class Pamatricendihmese {
	private static Scanner input = new Scanner(System.in);
	static int i, j, k, rr;
	static int[][] array2 = new int[rr][k];
	static int[][] array1 = new int[rr][k];
	static int d;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		array2 = afishoMatrice(rr, k);
		array1 = afishoMRE(array2);
	}

	public static int[][] afishoMatrice(int rr, int k) {
		int[][] matrica = new int[rr][k];
		System.out.println("Numri i rreshtave te matrices eshte:");
		rr = input.nextInt();
		System.out.println("Numri i kolonave te matrices eshte:");
		k = input.nextInt();
		System.out.println("Afisho matricen me elemente!");
		for (i = 0; i < rr; i++) {
			for (j = 0; j < k; k++) {
				matrica[i][j] = input.nextInt();
			}
			System.out.println();
		}
		for (i = 0; i < rr; i++) {
			for (j = 0; j < k; k++) {
		System.out.print(matrica[i][j]);
			}
			System.out.println();
		}
		return matrica;
	}

	public static int[][] afishoMRE(int[][] array) {
//Nqs numri i rreshtave me i madh se ai i kolonave, fshijme 'd'-rreshta dhe shtojme d-kolona,pa ndertuar matrice te re;
		if (rr > k) {
			d = rr - k;
			rr = rr - d;
			k = k + d;
		}
//Nqs numri i kolonave eshte me i madh se numri i rreshtave , fshijme d-kolona dhe shtojme d-rreshta , pa krijuar matrice te re;
		else if (rr < k) {
			d = k - rr;
			rr = rr + d;
			k = k - d;
		}

		System.out.println("Afisho matricen e RE me elemente:");
		for (i = 0; i < rr; i++) {
			for (j = 0; j < k; j++) {
				array[i][j] = input.nextInt();
			}
			System.out.println();
		}
		for (i = 0; i < rr; i++) {
			for (j = 0; j < k; j++) {
				System.out.print(array[i][j]);
			}
			System.out.println();
		}
		return array;

	}

}