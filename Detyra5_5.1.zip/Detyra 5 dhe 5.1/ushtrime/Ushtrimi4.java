package seanca5.ushtrime;

import java.util.Scanner;
import java.lang.Math;

public class Ushtrimi4 {
	/*
	 * 4) Shkruaj nje program ne Java qe per nje vektor/array te dhene gjen sa here
	 * perseritet secili element i tij brenda vektorit dhe rezultatin e rikthen ne
	 * formen e nje matrice 2 dimensionale, ku si kolone e pare eshte elementi i
	 * matrices se pare 1D dhe ne kolonen e dyte gjendet sa here perseritet secili.
	 */
	private static Scanner in = new Scanner(System.in);
	static int r = 100;
	static int i, j, n, m = 2;
	static int[] a = new int[n];
	static int[][] array2D = new int[n][m];

	public static void main(String[] args) {
		a = afishoVektor(n);
		array2D = frequency(a);
	}

	public static int[] afishoVektor(int n) {
		int[] array1D = new int[n];
		System.out.println("Vendosni numrin e elementeve te vektorit");
		n = in.nextInt();
		System.out.println("Ploteso vektorin me elemente");
		for (i = 0; i < array1D.length; i++) {
			array1D[i] = (int)(Math.random() * r);
		}
		System.out.println("Afisho vektorin me elemente");
		for (i = 0; i < array1D.length; i++) {
			System.out.println(array1D[i]);
		}
		return array1D;
	}

	public static int[][] frequency(int[] vektor) {
		int[][] mt = new int[n][m];
		int f[] = new int[n];
		int apaD[] = new int[n];
		for (i = 0; i <= n - 1; i++) {
			System.out.println('\n' + "Per elementin ne pozicionin" + " " + i + " :" + '\n');
			f[i] = 0;
			for (j = (i + 1); j < n; j++) {
				if (vektor[i] == vektor[j]) {
					f[i] += 1;
					System.out.println("Per elementin ne poz e" + " " + i + " " + "dublikata u gjet ne pozicionin e"
							+ " " + j + " .");
					System.out.println("Vektori me elementet e padublikuar eshte:");
					n = n - f[i];
					int k = j;
					while (k < n) {
						apaD[k] = vektor[k + 1];
						System.out.println(apaD[k]);
					}
					k++;
				}

				else {
					f[i] = 0;
					System.out.println("Vektori me elementet e padublikuar eshte:");
					for (int k = i; k <= j; k++) {
						apaD[k] = vektor[k];
						System.out.println(apaD[k]);
					}
				}
			}
			System.out.println("Frekuenca eshte:");
			System.out.print(f[i]);
		}

		for (j = 0; j < 2; j++) {
			for (i = 0; i < mt[j].length; i++) {
				mt[i][0] = apaD[i];
				mt[i][1] = f[i];
				System.out.print(mt[i][j]);
			}
			System.out.println();
		}
		return mt;
	}

}