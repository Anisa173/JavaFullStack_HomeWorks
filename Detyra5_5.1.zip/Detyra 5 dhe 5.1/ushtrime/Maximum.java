package seanca5.ushtrime;

/**2.	Gjej maximumin mes tre numrave  (4 numrave) (hint: ripërdor metodën e krijuar në pikën  e parë)**/
import java.util.Scanner;

public class Maximum {
	static int gjatesia;
	static int temp, vlMadhe;
	static int[] array = new int[gjatesia];

	private static Scanner input = new Scanner(System.in);

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		array = afisho(gjatesia);
		vlMadhe = afishoMaximum(array);
	}

	public static int[] afisho(int gjatesia) {

		System.out.println("Percakto gjatesine e vektorit:");
		gjatesia = input.nextInt();
		int[] numri = new int[gjatesia];
		System.out.println("Ploteso vektorin me te dhena:");
		for (int i = 0; i < gjatesia; i++) {
			numri[i] = input.nextInt();
		}
		System.out.println("Printo vektorin:");
		for (int i = 0; i < gjatesia; i++) {
			System.out.println(numri[i]);
		}
		return numri;
	}

	public static int afishoMaximum(int[] arr1) {
		int maximum = 0;
//Afisho ne rendin zbrites
		System.out.println("Afisho vektorin te rendituar!");
		for (int j = gjatesia - 1; j > 0; j--) {
			for (int i = 0; i <= j; i++) {
				if (arr1[i] < arr1[i + 1]) {
					temp = arr1[i + 1];
					arr1[i + 1] = arr1[i];
					arr1[i] = temp;
					System.out.print(arr1[i]);
					System.out.print(arr1[i + 1]);
				} else {
					System.out.print(arr1[i]);
				}
				maximum = arr1[0];
				System.out.println(maximum);
			}
		}
		return maximum;
	}
}