package seanca5.ushtrime;

import java.util.Scanner;
import java.lang.Math;

public class ShumaDiagonale {
	/*
	 * 7. Shkruaj një metodë që kthen true nëse shuma e elementeve të diagonaleve të
	 * një matrice katrore është e barabartë dhe false në të kundërt
	 **/
	static boolean baraz = true;
	static boolean Nbaraz = false;
	static boolean result ;
	private static Scanner input = new Scanner(System.in);
	static int n, i, j, r = 10;
	static int[][] array = new int[n][n];

	public static void main(String[] args) {
		array = afishoMkatrore(n);
       result = gjejDiagonale(array);
	}

	public static int[][] afishoMkatrore(int n) {
		System.out.println("Vendosni permasat e matrices");
		n = input.nextInt();
		System.out.println("Popullo me te dhena matricen katrore:");
		int[][] mkatrore = new int[n][n];
		for (i = 0; i < n; i++) {
			for (j = 0; j <mkatrore[i].length; j++) {
				mkatrore[i][j] = (int) (Math.random() * r);
			}
			System.out.println();
		}
		System.out.println("Afisho matricen katrore:");
		for (i = 0; i < mkatrore.length; i++) {
			for (j = 0; j < mkatrore[i].length; j++) {
				System.out.print(mkatrore[i][j]);
			}
			System.out.println();
		}
		return mkatrore;
	}

	public static boolean gjejDiagonale(int[][] mkatr) {
		boolean pohimi = false;
		int sh1 = 0;
		int sh2 = 0;
		System.out.println("Shuma e elementeve te diagonales se pare eshte :");
		for (i = 0; i < mkatr.length; i++) {
			for (j = 0; j <mkatr[i].length; j++) {
				if (i == j) {
					sh1 = sh1 + mkatr[i][j];
					System.out.println(sh1);
				}else { sh1 = 0;}
			}
		}
		System.out.println("Shuma e elementeve te diagonales se dyte eshte :");
		for (i = n - 1; i >= 0; i--) {
			j=n-i-1;
				sh2 = sh2 + mkatr[i][j];
				System.out.println(sh2);
				
			}
		System.out.println("Afisho nese shuma e elementeve te diagonaleve ne nje matrice katrore eshte e barabarte :");
		if (sh1 == sh2) {
			pohimi = baraz;
			System.out.println(
					pohimi + " - " + "Shuma e elementeve te diagonaleve ne nje matrice katrore eshte e barabarte !");
		} else {
			pohimi = Nbaraz;
			System.out.println(
					pohimi + " - " + "Shuma e elementeve te diagonaleve ne nje matrice katrore eshte e barabarte !");
		}
		return pohimi;
	}

}