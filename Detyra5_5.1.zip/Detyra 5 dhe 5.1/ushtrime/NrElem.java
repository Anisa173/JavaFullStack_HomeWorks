package seanca5.ushtrime;

import java.util.Scanner;

public class NrElem {
	/*
	 * 3. Llogarit numrin e elementeve që janë më të mëdhenj se nje numër që jepet
	 * nga përdoruesi si input
	 **/
	static int i, j, m, n, elementi, temp;
	static int[][] array = new int[n][m];
	private static Scanner in = new Scanner(System.in);
	static boolean ugjet = true;
	static boolean Nugjet = false;

	public static void main(String[] args) {
		array = afishoMatrice(n, m);
        temp = gjejElem(array);
	}
	public static int[][] afishoMatrice(int n, int m) {
		int[][] arr = new int[n][m];
		System.out.println("Jepni numrin e kolonave te matrices:");
		m = in.nextInt();
		System.out.println("Jepni numrin e rreshtave te matrices:");
		n = in.nextInt();
		System.out.println("Populloni matricen me te dhena:");
		for (i = 0; i < n; i++) {
			for (j = 0; j < arr[i].length; j++) {
				arr[i][j] = in.nextInt();
			}
			System.out.println();
		}
		System.out.println("Afisho matricen me te dhena:");
		for (i = 0; i < arr.length; i++) {
			for (j = 0; j < arr[i].length; j++) {
				System.out.print(arr[i][j]);
			}
			System.out.println();
		}
		return arr;
	}

	public static int gjejElem(int[][] mt) {
		boolean gjej = false;
		int freq = 0;
		System.out.println("Vendosni elementin ");
		elementi = in.nextInt();
		System.out.println("Kontrolloni nese ka elemente me te medhenj!");
		for (i = 0; i < n; i++) {
			for (j = 0; j < m; j++) {
				if (elementi < mt[i][j]) {
					gjej = ugjet;
					freq = freq + 1;
					System.out.println(gjej + " -- " + "Gjenden elemente me te medhenj dhe numri i tyre eshte:");
					System.out.println(freq);
				} else {
					gjej = Nugjet;
					freq = 0;
					System.out.println(gjej + " -- " + "Gjenden elemente me te medhenj dhe numri i tyre eshte:");
					System.out.println(freq);
				}
			}
		}
		return freq;
	}
}
