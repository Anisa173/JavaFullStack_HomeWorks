package seanca5.ushtrime;

import java.util.Scanner;
import java.lang.Math;

public class Ushtrimi1 {
	/*
	 * 1) Shkruaj një program që gjen nëse një element ndodhet apo jo në array dhe
	 * në cilet pozicione ndodhet ai element në array. Metoda te riktheje nje
	 * matrice 1 Dimensionale ku si elemente te saj te jene indekset ku gjendet ky
	 * element. (Hint: Vektoreve nuk u ndryshon gjatesia, si mund ta gjejme sa do
	 * jete gjatesia fillestare e vektorit qe do rikthehet ? Sa mund te jete
	 * gjatesia e tij maksimale ? )
	 **/
	private static Scanner in = new Scanner(System.in);
	static boolean ugjet = true;
	static boolean Nugjet = false;
	static boolean searching;
	static int freq, i, j, n, elem, rangu = 10;
	static int[] array1 = new int[n];
	static int[] Indeks = new int[n];

	public static void main(String[] args) {
		array1 = afishoVektor(n);
		searching = frekuencIndex(array1, elem);
	}

	public static int[] afishoVektor(int n) {
		int[] a = new int[n];
		System.out.println("Vendos gjatesine e vektorit");
		n = in.nextInt();
		System.out.println("Popullo vektorin me elemente");
		for (i = 0; i < n; i++) {
			a[i] = (int) (Math.random() * rangu);
		}
		System.out.println("Afisho vektor");
		for (i = 0; i < n; i++) {
			System.out.print('\t' + a[i] + '\t');
		}
		return a;
	}

	public static boolean frekuencIndex(int[] arr, int elementi) {

		boolean kerkim = false;
		freq = 0;
		System.out.println("Elementi qe kerkojme");
		elementi = in.nextInt();
		System.out.println("Kontrolloni nese elementi gjendet apo jo ne vektor");
		for (i = 0; i < n; i++) {
			if (elementi == arr[i]) {
				kerkim = ugjet;
				System.out.println(kerkim + " - " + "Elementi gjendet ne pozicionin" + " " + i);
				freq += 1;
				int[] fIndeks = new int[freq];
				System.out.println("Elementi " + " " + (i) + " "
						+ "ne vektorin e 'gjendshmerise' eshte sa indeksi ku u gjend sipas rastit");
				fIndeks[i] = i;
				System.out.print(fIndeks[i]);
			} else {
				kerkim = Nugjet;
				System.out.println(kerkim + " - " + "Elementi gjendet ne pozicionin" + " " + i);
				freq = 0;
			}
		}
		return kerkim;

	}
}
