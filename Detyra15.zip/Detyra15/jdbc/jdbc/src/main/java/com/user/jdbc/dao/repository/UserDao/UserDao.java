package com.user.jdbc.dao.repository.UserDao;

import com.user.jdbc.dao.entity.Users;
import com.user.jdbc.dao.repository.BaseDao;

public interface UserDao extends BaseDao<Users, Integer> {

}
