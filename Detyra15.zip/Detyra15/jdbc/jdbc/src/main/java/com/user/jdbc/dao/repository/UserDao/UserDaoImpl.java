package com.user.jdbc.dao.repository.UserDao;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.user.jdbc.dao.entity.Users;
import com.user.jdbc.dao.repository.BaseDaoImpl;
@Repository
public class UserDaoImpl extends BaseDaoImpl<Users,Integer> implements UserDao{
private final JdbcTemplate jdbcTemplate;
	public UserDaoImpl(Class<Users> types,JdbcTemplate jdbcTemplate) {
		super(types);
		this.jdbcTemplate = jdbcTemplate;
	}

	@Override
	protected JdbcTemplate getJdbcTemplate() {

		return this.jdbcTemplate;
	}

}
	
