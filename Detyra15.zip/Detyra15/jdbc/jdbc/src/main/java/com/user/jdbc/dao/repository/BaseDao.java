package com.user.jdbc.dao.repository;

import java.io.Serializable;
import java.util.List;

import com.user.jdbc.dao.entity.BaseEntity;
import com.user.jdbc.dao.entity.Posts;

public interface BaseDao<T extends BaseEntity<?>, I extends Serializable> {

	T getUserByUsername(String query, Object... params) throws Exception;

	T getPostsByPostStatus(String query, Object... params) throws Exception;

	T getPostsByCategory(String query, Object... params) throws Exception;

	T getUsersByUsernameAndEmail(String query, Object... params) throws Exception;

	Integer update(String query, Object... params) throws Exception;

	I create(String query, Object... params) throws Exception;

	T getPostsByTitle(String query, Object... params) throws Exception;

	void delete(String query, Object... params) throws Exception;

	List<T> getAllPostCategories(String query) throws Exception;



}
