package com.user.jdbc.dao.repository.PostCategoryDao;

import com.user.jdbc.dao.entity.PostCategories;
import com.user.jdbc.dao.repository.BaseDao;

public interface PostCategoryDao extends BaseDao<PostCategories,Integer> {



}
