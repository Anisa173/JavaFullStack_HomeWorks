package com.user.jdbc.dao.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Users extends BaseEntity<Integer> {
	@Id
	@Column
	private Integer id;
	@Column
	private String username;
	@Column
	private String email;
	@Column
	private String password;
	@Column
	private LocalDateTime date_created;
	@Column
	private LocalDateTime date_modified;

	public Users() {

	}

	public Users(Integer id, String username, String email, String password, LocalDateTime date_created,
			LocalDateTime date_modified) {
		super();
		this.id = id;
		this.username = username;
		this.email = email;
		this.password = password;
		this.date_created = date_created;
		this.date_modified = date_modified;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public LocalDateTime getDate_created() {
		return date_created;
	}

	public void setDate_modified(LocalDateTime date_modified) {
		this.date_modified = date_modified;
	}

	public String toString() {
		return "Users[id =" + id + ",username = " + username + ",email = " + email + ",password = " + password
				+ ",date_created = " + date_created + ",date_modified = " + date_modified + "]";
	}

	@Override
	public Integer getId() {

		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}
}