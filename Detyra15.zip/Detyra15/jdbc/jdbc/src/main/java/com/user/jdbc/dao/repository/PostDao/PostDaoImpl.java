package com.user.jdbc.dao.repository.PostDao;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.user.jdbc.dao.entity.Posts;
import com.user.jdbc.dao.repository.BaseDaoImpl;
@Repository
public class PostDaoImpl extends BaseDaoImpl<Posts, Integer> implements PostDao {
	private final JdbcTemplate jdbcTemplate;

	public PostDaoImpl(Class<Posts> types, JdbcTemplate jdbcTemplate) {
		super(types);
		this.jdbcTemplate = jdbcTemplate;
	}

	@Override
	protected JdbcTemplate getJdbcTemplate() {

		return jdbcTemplate;
	}

}