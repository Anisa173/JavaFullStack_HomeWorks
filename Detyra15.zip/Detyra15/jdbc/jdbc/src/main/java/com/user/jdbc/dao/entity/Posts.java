package com.user.jdbc.dao.entity;

import java.time.LocalDateTime;

public class Posts extends BaseEntity<Integer> {
	private Integer id;
	private String title;
	private String postStatus;
	private LocalDateTime date_created;
	private LocalDateTime date_modified;

	public Posts() {

	}

	public Posts(Integer id, String title, String postStatus, LocalDateTime date_created, LocalDateTime date_modified) {
	//	super();
		this.id = id;
		this.setTitle(title);
		this.setPostStatus(postStatus);
		this.setDate_created(date_created);
		this.setDate_modified(date_modified);

	}

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getPostStatus() {
		return postStatus;
	}

	public void setPostStatus(String postStatus) {
		this.postStatus = postStatus;
	}

	public LocalDateTime getDate_created() {
		return date_created;
	}

	public void setDate_created(LocalDateTime date_created) {
		this.date_created = date_created;
	}

	public LocalDateTime getDate_modified() {
		return date_modified;
	}

	public void setDate_modified(LocalDateTime date_modified) {
		this.date_modified = date_modified;
	}

	public String toString() {
		return "Posts[id = " + id + ",title = " + title + ",postStatus = " + postStatus + ",date_created = "
				+ date_created + ",date_modified =" + date_modified + "]";
	}

}
