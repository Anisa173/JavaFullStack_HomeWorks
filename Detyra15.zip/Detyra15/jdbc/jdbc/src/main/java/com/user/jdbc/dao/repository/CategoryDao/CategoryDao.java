package com.user.jdbc.dao.repository.CategoryDao;

import com.user.jdbc.dao.entity.Categories;
import com.user.jdbc.dao.repository.BaseDao;

public interface CategoryDao<T> extends BaseDao<Categories,Integer>{



}