package com.user.jdbc.dao.repository;

import java.io.Serializable;
import java.util.List;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

import com.user.jdbc.dao.entity.BaseEntity;

public abstract class BaseDaoImpl<T extends BaseEntity<?>, I extends Serializable> {
	private final Class<T> types;

	protected abstract JdbcTemplate getJdbcTemplate();

	public BaseDaoImpl(Class<T> types) {
		this.types = types;
	}

	public T getUserByUsername(String query, Object... params) throws Exception {
		return (T)(Object)getJdbcTemplate().queryForObject(query, BeanPropertyRowMapper.newInstance(types));

	}

	public T getPostsByPostStatus(String query, Object... params) throws Exception {
		return (T)(Object)getJdbcTemplate().queryForObject(query, BeanPropertyRowMapper.newInstance(types));
	}

	public T getPostsByCategory(String query, Object... params) throws Exception {
		return (T)(Object)getJdbcTemplate().queryForObject(query, BeanPropertyRowMapper.newInstance(types));
	}

	@SuppressWarnings("unchecked")
	public T getUsersByUsernameAndEmail(String query, Object... params) throws Exception {
		T i = (T) (Object) getJdbcTemplate().queryForObject(query, BeanPropertyRowMapper.newInstance(types));
		return i;

	}

	public I update(String query, Object... params) throws Exception {
		return (I)(Object)getJdbcTemplate().update(query, params);
	}

	@SuppressWarnings("unchecked")
	public I create(String query, Object... params) throws Exception {
		I i = (I) (Object) getJdbcTemplate().update(query, params);
		return i;
	}

	@SuppressWarnings("unchecked")
	public T getPostsByTitle(String query ,Object...param) throws Exception {
		return (T)(Object)getJdbcTemplate().queryForObject(query,BeanPropertyRowMapper.newInstance(types));
		
	}

	@SuppressWarnings("unchecked")
	public void delete(String query, Object... params) throws Exception {
		getJdbcTemplate().update(query, params);
	}

	@SuppressWarnings("unchecked")
	public List<T> getAllPostCategories(String query) throws Exception {

		List<T> t = (List<T>) (Object) getJdbcTemplate().query(query, BeanPropertyRowMapper.newInstance(types));
		return t;
	}
}