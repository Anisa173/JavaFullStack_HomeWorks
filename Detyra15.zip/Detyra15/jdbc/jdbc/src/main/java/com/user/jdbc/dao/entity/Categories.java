package com.user.jdbc.dao.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Categories extends BaseEntity<Integer> {
	@Id
	@Column
	private Integer id;
	@Column
	private String name;
	@Column
	private LocalDateTime date_created;
	@Column
	private LocalDateTime date_modified;

	public Categories() {

	}

	public Categories(Integer id, String name, LocalDateTime date_created, LocalDateTime date_modified) {
		this.setId(id);
		this.setName(name);
		this.setDate_created(date_created);
		this.setDate_modified(date_created);

	}

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public LocalDateTime getDate_created() {
		return date_created;
	}

	public void setDate_created(LocalDateTime date_created) {
		this.date_created = date_created;
	}

	public LocalDateTime getDate_modified() {
		return date_modified;
	}

	public void setDate_modified(LocalDateTime date_modified) {
		this.date_modified = date_modified;
	}

	public String toString() {
		return "Categories[id = " + id + ",name = " + name + ",date_created =" + date_created + ",date_modified ="
				+ date_modified + "]";
	}
}