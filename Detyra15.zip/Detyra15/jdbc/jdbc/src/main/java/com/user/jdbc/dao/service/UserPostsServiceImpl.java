package com.user.jdbc.dao.service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.stereotype.Service;

import com.user.jdbc.dao.entity.Categories;
import com.user.jdbc.dao.entity.PostCategories;
import com.user.jdbc.dao.entity.Posts;
import com.user.jdbc.dao.entity.Users;
import com.user.jdbc.dao.repository.CategoryDao.CategoryDao;
import com.user.jdbc.dao.repository.PostCategoryDao.PostCategoryDao;
import com.user.jdbc.dao.repository.PostDao.PostDao;
import com.user.jdbc.dao.repository.UserDao.UserDao;
@Service
public class UserPostsServiceImpl implements UserPostsService {
	private static final String FIND_USER_BY_USERNAME = "Select u.id as userId,u.date_created as userDataCreated,p.title as postTitle From users AS u INNER JOIN posts AS p ON p.user_id = u.id where u.username = ?";
	private static final String GET_POSTS_BY_POSTSTATUS = "Select pc.id AS postCategoryId,u.username,p.title as postTitle,p.postStatus as content From posts AS p INNER JOIN users AS u ON p.userId = u.id INNER JOIN postCategories AS pc ON p.id = pc.post_id where p.postStatus = ? ";
	private static final String GET_POSTS_BY_CATEGORY = "Select p.title, c.name as post_category,p.date_created as postDataCreated,p.postStatus AS content FROM postCategories as pc INNER JOIN posts as p ON p.id = pc.postId INNER JOIN Categories AS c ON c.id = pc.categoriesId where c.name = ? ";
	private static final String FIND_USER_BY_USERNAME_EMAIL = "Select u.id,u.username,u.email From users as u where u.username = ? and u.email = ?";
	private static final String UPDATE_POSTS_BY_userId = "UPDATE posts as p SET p.title = ?,p.postStatus = ? WHERE p.userId IN (Select * from users as u INNER JOIN p ON p.userId = u.id where u.id =?)  ";
	private static final String ADD_USERS = "Insert into users(username,email,password,date_created) Values(?,?,?,?)";
	private static final String FIND_POSTS_BY_TITLE = "Select * From Posts as p where p.title = ? ";
	private static final String DELETE_CATEGORY = "Delete from Categories as c where  c.date_created =? and c.name = ?";
	private static final String FIND_ALL_POSTCATEGORY = "Select * From PostCategories ";

	private final UserDao userDao;
	private final PostDao postDao;
	private final CategoryDao<?> categoryDao;
	private final PostCategoryDao postCategoryDao;

	public UserPostsServiceImpl(UserDao userDao, PostDao postDao, CategoryDao<?> categoryDao,
			PostCategoryDao postCategoryDao) {

		this.userDao = userDao;
		this.postDao = postDao;
		this.categoryDao = categoryDao;
		this.postCategoryDao = postCategoryDao;
	}

	@Override
	public Users getUserByUsername(String username) throws Exception {

		return userDao.getUserByUsername(FIND_USER_BY_USERNAME, username);

	}

	@Override
	public Posts getPostsByPostStatus(String postStatus) throws Exception {

		return postDao.getPostsByPostStatus(GET_POSTS_BY_POSTSTATUS, postStatus);

	}

	@Override
	public PostCategories getPostsByCategory(String category) throws Exception {
		return postCategoryDao.getPostsByCategory(GET_POSTS_BY_CATEGORY, category);
	}

	@Override
	public Users getUsersByUsernameAndEmail(String username, String password) throws Exception {
		return userDao.getUsersByUsernameAndEmail(FIND_USER_BY_USERNAME_EMAIL, username, password);
	}

	@Override
	public Integer update(Posts p, Integer id) throws Exception {
		return postDao.update(UPDATE_POSTS_BY_userId , p.getTitle(), p.getPostStatus(), id);

	}

	@Override
	public Integer create(Users users) throws Exception {
		return userDao.create(ADD_USERS, users.getUsername(), users.getPassword(), users.getEmail(),
				users.getDate_created());
	}

	@Override
	public Posts getPostsByTitle(Posts p, Integer id) throws Exception {
		return postDao.getPostsByTitle(FIND_POSTS_BY_TITLE, p.getTitle(), id);
	}

	@Override
	public void delete(Categories c, String name, LocalDateTime date_created) throws Exception {
		categoryDao.delete(DELETE_CATEGORY, c.getName(), c.getDate_created());
	}

	@Override
	public List<PostCategories> getAllPostCategories() throws Exception {
		return postCategoryDao.getAllPostCategories(FIND_ALL_POSTCATEGORY);
	}

}