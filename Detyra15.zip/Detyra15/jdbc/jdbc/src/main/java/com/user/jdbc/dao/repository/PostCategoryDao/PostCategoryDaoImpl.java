package com.user.jdbc.dao.repository.PostCategoryDao;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.user.jdbc.dao.entity.PostCategories;
import com.user.jdbc.dao.repository.BaseDaoImpl;
@Repository
public class PostCategoryDaoImpl extends BaseDaoImpl<PostCategories, Integer> implements PostCategoryDao {
	private final JdbcTemplate jdbcTemplate;

	public PostCategoryDaoImpl(JdbcTemplate jdbcTemplate) {
		super(PostCategories.class);
		this.jdbcTemplate = jdbcTemplate;
	}

	@Override
	protected JdbcTemplate getJdbcTemplate() {

		return this.jdbcTemplate;
	}

}
