package com.user.jdbc.dao.service;

import java.time.LocalDateTime;
import java.util.List;

import com.user.jdbc.dao.entity.Categories;
import com.user.jdbc.dao.entity.PostCategories;
import com.user.jdbc.dao.entity.Posts;
import com.user.jdbc.dao.entity.Users;

public interface UserPostsService {
	Users getUserByUsername(String username) throws Exception;

	Posts getPostsByPostStatus(String postStatus) throws Exception;

	PostCategories getPostsByCategory(String category) throws Exception;

	Users getUsersByUsernameAndEmail(String username, String password) throws Exception;

	Integer update(Posts p, Integer id) throws Exception;

	Integer create(Users users) throws Exception;

	Posts getPostsByTitle(Posts p, Integer id) throws Exception;

    void delete(Categories c, String name, LocalDateTime date_created) throws Exception;


	List<PostCategories> getAllPostCategories() throws Exception;

	
	
}
