package com.user.jdbc.dao;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;

import com.user.jdbc.dao.entity.Posts;
import com.user.jdbc.dao.entity.Users;
import com.user.jdbc.dao.service.UserPostsService;

public class UserPost_Daodemo implements CommandLineRunner {
	private Logger log = LoggerFactory.getLogger(UserPost_Daodemo.class);
	private final UserPostsService userPostsService;

	public UserPost_Daodemo(UserPostsService userPostsService) {
		super();
		this.userPostsService = userPostsService;
	}

	@Override
	public void run(String... args) throws Exception {
		log.info("Useri me username -'user3':{}", userPostsService.getUserByUsername("user3"));
		log.info("Post with postStatus- 'Body of Post 4':{}", userPostsService.getPostsByPostStatus("Body of Post 4"));
		log.info("Categories with categoryName -- 'Category 2':{} ", userPostsService.getPostsByCategory("Category 2"));
		log.info("Users with 'username' - user2 and 'password' - password4: {}",
				userPostsService.getUsersByUsernameAndEmail("user2", "password4"));
		Posts post = userPostsService.getPostsByUserId(3);
		post.setTitle("post15");
		post.setPostStatus("content1");
		post.userPostsService(post, 3);
		log.info("{}", userPostsService.getAllPosts());
		Users users = new User("user14", "pass2", "user14@yahoo.com", LocalDateTimeNow());
		userPostsService.create(users);
		log.info("{}", userPostsService.getAllUsers());
		log.info("Useri me username -'user3':{}", userPostsService.getPostsByTitle("title1",1));
	
	////////
	
	
	}

	public Logger getLog() {
		return log;
	}

	public void setLog(Logger log) {
		this.log = log;
	}

}
