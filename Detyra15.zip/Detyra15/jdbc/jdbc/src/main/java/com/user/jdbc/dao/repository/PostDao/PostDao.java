package com.user.jdbc.dao.repository.PostDao;

import com.user.jdbc.dao.entity.Posts;
import com.user.jdbc.dao.repository.BaseDao;

public interface PostDao extends BaseDao<Posts,Integer>{

	

}
