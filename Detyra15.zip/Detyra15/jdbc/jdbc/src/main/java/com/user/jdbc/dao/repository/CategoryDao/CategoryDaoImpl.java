package com.user.jdbc.dao.repository.CategoryDao;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;


import com.user.jdbc.dao.entity.Categories;
import com.user.jdbc.dao.repository.BaseDaoImpl;

@Repository
public class CategoryDaoImpl extends BaseDaoImpl<Categories,Integer> implements CategoryDao<Categories> {

	private final JdbcTemplate jdbcTemplate;

	public CategoryDaoImpl(Class<Categories> types,JdbcTemplate jdbcTemplate) {
		super(types);
		this.jdbcTemplate = jdbcTemplate;  
	}

	@Override
	public JdbcTemplate getJdbcTemplate() {
		return this.jdbcTemplate;
	}

	

	
}