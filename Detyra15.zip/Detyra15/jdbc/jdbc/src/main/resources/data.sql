insert into userpost.users(username , email , password)
values('user1','user1@gmail.com','passwordi1'),
('user2','user2@gmail.com','passwordi2'),
('user3','user3@gmail.com','password3'),
('user4','user4@gmail.com','password4'),
('user5','user5@gmail.com','password5');

insert into userpost.posts(title , postStatus , user_id)
Values('Post1','Body of Post 1',4);
insert into userpost.posts(title , postStatus , user_id)
Values('Post2','Body of Post 2',1);
insert into userpost.posts(title , postStatus , user_id)
Values('Post3','Body of Post 3',3);
insert into userpost.posts(title , postStatus , user_id)
Values('Post4','Body of Post 4',5);
insert into userpost.posts(title , postStatus , user_id)
Values('Post5','Body of Post 5',2);

Insert into userpost.postcategories(postId,categoriesId)
   Values(1,2),
   (2,4),
   (3,5),
   (4,1),
   (5,3);
   
Insert into userpost.categories(name)
Values('Category 1'),
('Category 2'),
('Category 3'),
('Category 4'),
('Category 5');
   