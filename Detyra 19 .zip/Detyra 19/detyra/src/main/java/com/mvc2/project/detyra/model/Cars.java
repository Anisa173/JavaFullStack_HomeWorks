package com.mvc2.project.detyra.model;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public class Cars {
	private Integer id;
	@NotNull(message = "* required *")
	@Size(min = 3, max = 6, message = "This field should be at min with 3 characters and at max with 6 characters")	
	private String name;
	@NotNull(message = "* required *")
	@Size(min = 3, max = 4, message = "This field should be at min with 3 characters and at max with 6 characters")	
	private String from_year;
	@NotNull(message = "* required *")
	@Size(min = 3, max = 4, message = "This field should be at min with 3 characters and at max with 6 characters")
	private String to_year;
	@NotNull(message = "* required *")
	@Size(min = 3, max = 5, message = "This field should be at min with 3 characters and at max with 6 characters")
	private String type;

		public Cars() {
			super();
		}

		public Cars(String name, String from_year, String to_year, String type) {
			super();
			this.setName(name);
			this.setFrom_year(from_year);
			this.setTo_year(to_year);
			this.setType(type);
		}

		
		public Integer getId() {

			return id;
		}

		public void setId(Integer id) {
			this.id = id;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getFrom_year() {
			return from_year;
		}

		public void setFrom_year(String from_year) {
			this.from_year = from_year;
		}

		public String getTo_year() {
			return to_year;
		}

		public void setTo_year(String to_year) {
			this.to_year = to_year;
		}

		public String getType() {
			return type;
		}

		public void setType(String type) {
			this.type = type;
		}

		public String toString() {
			return "Cars[id = " + id + ",name = " + name + ",from_year = " + from_year + ",to_year = " + to_year
					+ ",type = " + type + "]";
		}

}
