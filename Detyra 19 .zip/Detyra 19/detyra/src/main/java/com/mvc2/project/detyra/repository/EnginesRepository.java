package com.mvc2.project.detyra.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mvc2.project.detyra.entity.Engines;
@Repository
public interface EnginesRepository extends JpaRepository<Engines, Integer> {

}
