package com.mvc2.project.detyra.model;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public class Wheel {
	private Integer id;
	@NotNull(message = "* required *")
	@Size(min = 3, max = 5, message = "This field should be at min with 3 characters and at max with 6 characters")
	private String size;
	@NotNull(message = "* required *")
	@Size(min = 3, max = 6, message = "This field should be at min with 3 characters and at max with 6 characters")
	private String type;
	private Cars cars;

	public Wheel() {

	}

	public Wheel(Integer id, String size, String type, Cars cars) {
		this.id = id;
		this.size = size;
		this.type = type;
		this.cars = cars;
	}

	public Integer getId() {

		return id;
	}

	public void setId(Integer id) {
		this.id = id;

	}

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String toString() {
		return "Wheel[id = " + id + ",size = " + size + ",type = " + type + "] ";
	}

	public Cars getCars() {
		return cars;
	}

	public void setCars(Cars cars) {
		this.cars = cars;
	}
}
