package com.mvc2.project.detyra.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.mvc2.project.detyra.entity.Engines;
import com.mvc2.project.detyra.service.UserService;

import jakarta.validation.Valid;

@Controller
@RequestMapping("engines")
public class EngineControllerV2 {
	@Autowired
	UserService userService;

	@GetMapping
	public String getEnginesList(Model model) throws Exception {
		model.addAttribute("engines", userService.getAllEngines());

		return "tailwindcss/engines-list";
	}

	@GetMapping("engines/registration-form")
	public String getEnginesForm(Model model, @RequestParam(value = "enginesId", required = false) Integer id) throws Exception{
		if (id == null)  {
			model.addAttribute("enginesForm", new Engines());
			model.addAttribute("viewTittle", "Engines Registration");
		} else {
			model.addAttribute("enginesForm", userService.getEnginesById(id));
			model.addAttribute("viewTitle", "Engines Update");
		}
		return "tailwindcss/engines-form";
	}

	@PostMapping("engines")
	public String register(Model model, @Valid @ModelAttribute("enginesForm") Engines engines, BindingResult result)
			throws Exception {
		if (result.hasErrors()) {
			return "registration-form";
		}
		if (engines.getId() == null) {
			try {
				userService.createEngines(engines);
			} catch (Exception e) {
				System.out.println("An error occured" + "==>" + e.getMessage());
			}
		} else {
			userService.updateById(engines.getId(), engines);
		}
		return "redirect/engines";
	}

	@DeleteMapping
	public String deleteEngines(@RequestParam(value = "enginesId", required = true) Integer id) throws Exception {
		userService.deleteById(id);
		return "redirect/engines";
	}

}
