package com.mvc2.project.detyra.entity;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
public class Cars extends BasicEntity<Integer> {
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "wheel_id", referencedColumnName = "id")
	private Wheel wheel;

	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "engine_id", referencedColumnName = "id")
	private Engines engines;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	@Column(name = "name")
	private String name;
	@Column(name = "from_year")
	private String from_year;
	@Column(name = "to_year")
	private String to_year;
	@Column(name = "type")
	private String type;

	public Cars() {
		super();
	}

	public Cars(String name, String from_year, String to_year, String type, Wheel wheel, Engines engines) {
		super();
		this.setName(name);
		this.setFrom_year(from_year);
		this.setTo_year(to_year);
		this.setType(type);
		this.wheel = wheel;
		this.engines = engines;

	}

	@Override
	public Integer getId() {

		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getFrom_year() {
		return from_year;
	}

	public void setFrom_year(String from_year) {
		this.from_year = from_year;
	}

	public String getTo_year() {
		return to_year;
	}

	public void setTo_year(String to_year) {
		this.to_year = to_year;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Wheel getWheel() {
		return wheel;
	}

	public void setWheel(Wheel wheel) {
		this.wheel = wheel;
	}

	public Engines getEngines() {
		return engines;
	}

	public void setEngines(Engines engines) {
		this.engines = engines;
	}

	public String toString() {
		return "Cars[id = " + id + ",name = " + name + ",from_year = " + from_year + ",to_year = " + to_year
				+ ",type = " + type + ", engines = " +engines+ ", wheel = " +wheel+ "]";
	}
}
