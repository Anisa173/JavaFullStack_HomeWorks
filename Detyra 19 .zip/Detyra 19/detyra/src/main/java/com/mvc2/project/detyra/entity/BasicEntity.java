package com.mvc2.project.detyra.entity;

import java.io.Serializable;

public abstract class BasicEntity<K extends Serializable> {

	public abstract K getId();
}
