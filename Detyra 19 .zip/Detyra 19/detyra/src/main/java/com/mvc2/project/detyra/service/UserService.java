package com.mvc2.project.detyra.service;

import java.util.List;

import com.mvc2.project.detyra.entity.Cars;
import com.mvc2.project.detyra.entity.Engines;
import com.mvc2.project.detyra.entity.Wheel;

import jakarta.validation.Valid;

public interface UserService {

	List<Cars> getCarsByWheelAndEngines(Wheel wheel, Engines engines) throws Exception;

	Cars createCars(Cars cars, Engines engine, Wheel wheel) throws Exception;

	void deleteCars(Integer id) throws Exception;

	Cars getCarsbyId(Integer id) throws Exception;

	Cars updateById(Integer id, @Valid Cars cars);

	void deleteById(Integer id) throws Exception;

	List<Engines> getAllEngines() throws Exception;

	Engines createEngines(Engines engines) throws Exception;

	void deleteEngines(Integer id) throws Exception;

	Engines getEnginesById(Integer id) throws Exception;
	
	Engines updateById(Integer id, @Valid Engines engines) throws Exception;
	
	void deleteById1(Integer id) throws Exception;
	
	List<Wheel> getAllWheels() throws Exception;

	Wheel createWheel(Wheel wheels) throws Exception;

	void deleteWheel(Integer id) throws Exception;

	Wheel getWheelById(Integer id) throws Exception;
	
	void deleteById2(Integer id) throws Exception;
	
	Wheel updateById(Integer id, @Valid Wheel wheels) throws Exception;

	
	

	

	

	

	



}
