package com.mvc2.project.detyra.entity;

import java.util.ArrayList;
import java.util.List;


import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;

@Entity
public class Wheel extends BasicEntity<Integer> {
	@OneToMany(mappedBy = "wheel", cascade = CascadeType.ALL)
	private List<Cars> cars = new ArrayList<Cars>();

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	@Column(name = "size")
	private String size;
	@Column(name = "type")
	private String type;

	public Wheel() {
		super();
	}

	public Wheel(String size, String type, List<Cars> cars) {
		super();
		this.size = size;
		this.type = type;
		this.cars = cars;
	}

	@Override
	public Integer getId() {

		return id;
	}

	public void setId(Integer id) {
		this.id = id;

	}

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public void setCars(List<Cars> cars) {
		this.cars = cars;
	}

	public List<Cars> getCars() {
		return cars;
	}

	public String toString() {
		return "Wheel[id = " + id + ",size = " + size + ",type = " + type + ",cars = " + cars + "] ";
	}
}
