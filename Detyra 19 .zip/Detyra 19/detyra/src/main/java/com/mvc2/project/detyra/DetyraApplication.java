package com.mvc2.project.detyra;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DetyraApplication {

	public static void main(String[] args) {
		SpringApplication.run(DetyraApplication.class, args);
	}

}
