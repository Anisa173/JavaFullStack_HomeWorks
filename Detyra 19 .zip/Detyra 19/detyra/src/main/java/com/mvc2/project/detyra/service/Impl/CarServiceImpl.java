package com.mvc2.project.detyra.service.Impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.mvc2.project.detyra.entity.Cars;
import com.mvc2.project.detyra.entity.Engines;
import com.mvc2.project.detyra.entity.Wheel;
import com.mvc2.project.detyra.repository.CarsRepository;
import com.mvc2.project.detyra.repository.EnginesRepository;
import com.mvc2.project.detyra.repository.WheelRepository;
import com.mvc2.project.detyra.service.UserService;

import jakarta.validation.Valid;

@Service
public class CarServiceImpl implements UserService {

	private final CarsRepository carsRepository;
	private final EnginesRepository enginesRepository;
	private final WheelRepository wheelRepository;

	public CarServiceImpl(CarsRepository carsRepository, EnginesRepository enginesRepository,
			WheelRepository wheelRepository) {
		this.carsRepository = carsRepository;
		this.enginesRepository = enginesRepository;
		this.wheelRepository = wheelRepository;
	}

	@Override
	public List<Wheel> getAllWheels() throws Exception {

		return wheelRepository.findAll();
	}

	@Override
	public Wheel createWheel(Wheel wheel) throws Exception {

		return wheelRepository.save(wheel);
	}

	@Override
	public List<Engines> getAllEngines() throws Exception {

		return enginesRepository.findAll();
	}

	@Override
	public Engines createEngines(Engines engines) throws Exception {

		return enginesRepository.save(engines);
	}

	@Override
	public List<Cars> getCarsByWheelAndEngines(Wheel wheel, Engines engines) throws Exception {

		return carsRepository.findAllByWheelAndEngines(wheel, engines);
	}

	@Override
	public Cars createCars(Cars cars, Engines engine, Wheel wheel) throws Exception {

		return carsRepository.save(cars, engine, wheel);
	}

	@Override
	public void deleteCars(Integer id) throws Exception {
		carsRepository.deleteById(id);
	}

	@Override
	public void deleteEngines(Integer id) throws Exception {
		enginesRepository.deleteById(id);

	}

	@Override
	public void deleteWheel(Integer id) throws Exception {
		wheelRepository.deleteById(id);

	}

	@Override
	public Cars getCarsbyId(Integer id) {

		return carsRepository.findById(id).orElse(null);
	}

	@Override
	public Cars updateById(Integer id, @Valid Cars cars) {
		Cars cars2 = getCarsbyId(id);
		cars2.setFrom_year(cars.getFrom_year());
		cars2.setTo_year(cars.getTo_year());
		return carsRepository.save(cars);
	}

	@Override
	public void deleteById(Integer id) {
		carsRepository.deleteById(id);

	}

	@Override
	public Engines getEnginesById(Integer id) throws Exception {

		return enginesRepository.findById(id).orElse(null);
	}

	@Override
	public Engines updateById(Integer id, @Valid Engines engines) throws Exception {
		Engines engines2 = getEnginesById(id);
		engines2.setType(engines.getType());
		engines2.setPower(engines.getPower());
		return enginesRepository.save(engines);
	}

	@Override
	public void deleteById1(Integer id) {
		enginesRepository.deleteById(id);

	}

	@Override
	public Wheel getWheelById(Integer id) throws Exception {
		return wheelRepository.findById(id).orElse(null);
	}

	@Override
	public void deleteById2(Integer id) throws Exception {

		wheelRepository.deleteById(id);

	}

	@Override
	public Wheel updateById(Integer id, @Valid Wheel wheels) throws Exception {
		Wheel wheel = getWheelById(id);
		wheel.setType(wheels.getType());
		wheel.setSize(wheels.getSize());
		return wheel;
	}

}
