package com.mvc2.project.detyra.model;

import java.util.List;

import com.mvc2.project.detyra.entity.Cars;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public class Engines {

	private Integer id;
	@NotNull(message = "* required *")
	@Size(min = 3, max = 6, message = "This field should be at min with 3 characters and at max with 6 characters")
	private String power;
	@NotNull(message = "* required *")
	@Size(min = 3, max = 8, message = "This field should be at min with 3 characters and at max with 6 characters")
	private String type;
	private List<Cars> cars;

	public Engines() {
	}

	public Engines(Integer id, String power, String type, List<Cars> cars) {
		this.id = id;
		this.power = power;
		this.type = type;
		this.cars = cars;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getPower() {
		return power;
	}

	public void setPower(String power) {
		this.power = power;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String toString() {
		return "Engines[id = " + id + ",power = " + power + ",type = " + type + "]";
	}

	public List<Cars> getCars() {
		return cars;
	}

	public void setCars(List<Cars> cars) {
		this.cars = cars;
	}

}
