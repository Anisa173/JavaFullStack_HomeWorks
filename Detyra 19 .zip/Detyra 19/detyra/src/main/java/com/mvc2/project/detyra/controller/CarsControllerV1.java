package com.mvc2.project.detyra.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.mvc2.project.detyra.entity.Cars;
import com.mvc2.project.detyra.entity.Engines;
import com.mvc2.project.detyra.entity.Wheel;
import com.mvc2.project.detyra.service.UserService;

import jakarta.validation.Valid;

@Controller
@RequestMapping("Cars")
public class CarsControllerV1 {

	@Autowired
	UserService userService;

	@GetMapping
	public String getCarReviewList(Model model, Engines engines, Wheel wheel) throws Exception {
		model.addAttribute("Cars", userService.getCarsByWheelAndEngines(wheel, engines));
		return "tailwindcss/cars-list";
	}

	@GetMapping("/cars/register-view")
	public String getCarRegistrationView(Model model, @RequestParam(value = "carsId", required = false) Integer id)
			throws Exception {
		model.addAttribute("engineList", userService.getAllEngines());
		model.addAttribute("wheelList", userService.getAllWheels());
		if (id == null) {
			model.addAttribute("carsForm", new Cars());
			model.addAttribute("viewTittle", "Car Registration");
		} else {
			model.addAttribute("carsForm", userService.getCarsbyId(id));
			model.addAttribute("viewTittle", " Cars Update");
		}
		return "tailwindcss/car-registration";
	}

	@PostMapping("cars/register")
	public String saveCarRegistrationForm(Model model, @Valid @ModelAttribute("registration-form") Cars cars,
			Engines engine, Wheel wheel, BindingResult result) {
		if (result.hasErrors()) {
			return "registration-form";
		}
		if (cars.getId() == null) {
			try {
				userService.createCars(cars, engine, wheel);
			} catch (Exception e) {
				System.out.println("An error occured" + "==>" + e.getMessage());
			}
		} else {
			userService.updateById(cars.getId(), cars);
		}

		return "redirect/cars";
	}

	@GetMapping("/delete")
	public String deleteCars(@RequestParam(value = "carsId", required = true) Integer id) throws Exception {
		userService.deleteById(id);
		return "redirect/cars";
	}
}