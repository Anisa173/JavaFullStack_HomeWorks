package com.mvc2.project.detyra.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.mvc2.project.detyra.entity.Cars;
import com.mvc2.project.detyra.entity.Wheel;
import com.mvc2.project.detyra.service.UserService;

import jakarta.validation.Valid;

@Controller
@RequestMapping("wheel")
public class WheelControllerV3 {
	@Autowired
	UserService userService;

	@GetMapping
	public String getWheelList(Model model) throws Exception {
		model.addAttribute("wheelList", userService.getAllWheels());
		return "tailwindcss/wheel-list ";
	}

	@GetMapping("wheel/register-view")
	public String getWheelRegistrationForm(Model model, @RequestParam(value = "wheelId", required = false) Integer id) throws Exception {
		if (id == null) {
			model.addAttribute("wheelRegistration", new Wheel());
			model.addAttribute("viewTitle", "Wheels Registration");
		} else {
			model.addAttribute("WheelForm", userService.getWheelById(id));
			model.addAttribute("viewTitle", "Wheel Update");
		}

		return "tailwindcss/registration-form";
	}

	@PostMapping("wheel/register")
	public String saveWheelRegistrationForm(@Valid @ModelAttribute("wheelForm") Wheel wheels,
			BindingResult result) throws Exception {
		if (result.hasErrors()) {
			return "registration-form";
		}
		if (wheels.getId() == null) {
			try {
				userService.createWheel(wheels);
			} catch (Exception e) {
				System.out.println("An error occurred" + "==>" + e.getMessage());
			}
		} else {
			userService.updateById(wheels.getId(), wheels);

		}

		return "redirect/wheel";
	}

	@DeleteMapping
	public String deleteWheel(@RequestParam(value = "wheelId", required = true) Integer id) throws Exception {
		userService.deleteById(id);
		return "redirect/Wheel";
	}

}