package com.mvc2.project.detyra.entity;

import java.util.ArrayList;
import java.util.List;


import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
public class Engines extends BasicEntity<Integer> {
	@OneToMany(mappedBy = "engines", cascade = CascadeType.ALL)
	private List<Cars> cars = new ArrayList<Cars>();

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	@Column(name = "power")
	private String power;
	@Column(name = "type")
	private String type;

	public Engines() {
		super();
	}

	public Engines(String power, String type, List<Cars> cars) {
		super();
		this.power = power;
		this.type = type;
		this.cars = cars;
	}

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getPower() {
		return power;
	}

	public void setPower(String power) {
		this.power = power;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public List<Cars> getCars() {
		return cars;
	}

	public void setCars(List<Cars> cars) {
		this.cars = cars;
	}

	public String toString() {
		return "Engines[id = " + id + ",power = " + power + ",type = " + type + ", cars = " + cars + "]";
	}
}
