CREATE TABLE wheels (
    id INTEGER AUTO_INCREMENT NOT NULL,
    size VARCHAR(255) NOT NULL,
    type VARCHAR(255) NOT NULL,
    PRIMARY KEY (id)
);

insert into wheels(id,size,type)
values(1,'R15','STEEL'),
(1,'R16','STEEL'),
(1,'R16','ALLOV');