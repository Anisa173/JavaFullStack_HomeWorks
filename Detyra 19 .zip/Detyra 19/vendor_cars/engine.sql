CREATE TABLE engine (
    id INTEGER AUTO_INCREMENT NOT NULL,
    power VARCHAR(255) NOT NULL,
    type VARCHAR(255) NOT NULL,
    PRIMARY KEY (id)
);

insert into engine(id,power,type)
values(1,'1400','GAS'),
(2,'2200','DIESEL'),
(3,'1800','GASOLINE');