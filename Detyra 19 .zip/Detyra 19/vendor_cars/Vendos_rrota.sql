insert into wheels(id,size,type)
values(1,'R15','STEEL'),
(2,'R16','STEEL'),
(3,'R16','ALLOV');