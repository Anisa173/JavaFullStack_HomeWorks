insert into car(id,name,from_year,to_year,type,engine_id,wheels_id)
values(1,'Aspire','1994','1997','subCompact',1,1);