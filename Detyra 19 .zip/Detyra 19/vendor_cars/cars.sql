CREATE TABLE car (
    id INTEGER AUTO_INCREMENT NOT NULL,
    name VARCHAR(255) NOT NULL,
    from_year VARCHAR(255) NOT NULL,
    to_year VARCHAR(255) NOT NULL,
    type VARCHAR(255) NOT NULL,
    PRIMARY KEY (id),
    engine_id INTEGER,
    wheels_id INTEGER,
    FOREIGN KEY (engine_id)
        REFERENCES engine (id),
    FOREIGN KEY (wheels_id)
        REFERENCES wheels(id)

);