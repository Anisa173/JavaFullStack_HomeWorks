package cilinder.rreth.oop;

import java.util.Scanner;
import java.lang.Math;

public class Cilindri extends Rrethi {
	static Scanner sc = new Scanner(System.in);
	private double lartesi;
	

	public Cilindri() {
		this.lartesi = 1.0;
		this.setRreze(1.0);
		this.setNgjyrë("blu");
	}

	public Cilindri(double lartesi, double rreze, String ngjyrë) {
		super(rreze, ngjyrë);
		this.lartesi = lartesi;
	}

	private static double vellimiC(double lartesi, double rreze) {
		System.out.println("Lartesia e cilindrit eshte:");
		lartesi = sc.nextDouble();
		System.out.println("Rrezja e cilindrit eshte :");
		rreze = sc.nextDouble();

		System.out.println("Vellimi i Cilindrit eshte:");
		double vellimi = Math.PI * Math.pow(rreze, 2) * lartesi;
		System.out.println(vellimi);
		return vellimi;
	}

	public double getLartesi() {
		vellimiC(lartesi, getRreze());
		return lartesi;
	}

}