package cilinder.rreth.oop;

/**
 * Ushtrim 2
 * 
 * Krijoni superklasën Rreth, me fusha private rreze dhe ngjyrë . Klasa ka: •një
 * konstruktor pa argumenta që inicializon rrezen me 1.0 dhe ngjyrën me “blu”, •
 * një konstruktor me argumenta rrezen dhe ngjyrën • metodat get dhe set për çdo
 * fushë. • një metodë që kthen sipërfaqen e rrethit. Krijoni nënklasën
 * Cilinder, me fushë private lartesi . Klasa ka: • një konstruktor pa argumenta
 * që vendos lartesinë 1.0 , rrezen 1.0 dhe ngjyren “blu” • një konstruktor me
 * argumenta rrezen, ngjyrën dhe lartësinë • metodat get dhe set për këtë fushë
 * • një metodë që kthen vëllimin e cilindrit Krijoni klasën Test, për të
 * testuar të gjitha metodat e klasave të krijuara.
 **/

public class Test {
	static Rrethi r = new Rrethi();
    static Cilindri cil = new Cilindri();
	public static void main(String[] args) {
//Rrethi
		System.out.println("Rrethi me ngjyre"+" "+r.getNgjyrë()+" "+ "eshte me rreze:"+" "+ r.getRreze()+" .");
		r.setNgjyrë("gri");
		System.out.println("Rrethi ka ngjyre:" + " " + r.getNgjyrë());
		System.out.println("Siperfaqja e rrethit eshte:" + " " + r.getRreze());
//Cilindri
        System.out.println("Vellimi i cilindrit eshte:"+" "+ cil.getLartesi());
	
	}

}
