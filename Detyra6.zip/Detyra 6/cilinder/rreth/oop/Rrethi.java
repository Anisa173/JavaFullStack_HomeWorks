package cilinder.rreth.oop;

import java.util.Scanner;

public class Rrethi {
	static Scanner sc = new Scanner(System.in);
	private double rreze;
	private String ngjyrë;
	

	public Rrethi() {
		this.setRreze(1.0);
		this.setNgjyrë("blu");
	}

	public Rrethi(double rreze, String ngjyrë) {
		this.rreze = rreze ;
		this.ngjyrë = ngjyrë;
	}

	public void setNgjyrë(String ngjyrë) {
		this.ngjyrë = ngjyrë;
	}

	public String getNgjyrë() {
		return ngjyrë;
	}

	private double siperfaqjaRr(double rreze) {

		System.out.println("Rrezja eshte:");
		rreze = sc.nextDouble();
		double sipRr = 3.14 * (rreze * rreze);
		System.out.println("Siperfaqja e rrethit eshte:" + " " + sipRr);
		return sipRr;
	}

	public double getRreze() {
		siperfaqjaRr(rreze);
		return rreze;
	}

	/**
	 * @param rreze the rreze to set
	 */
	public void setRreze(double rreze) {
		this.rreze = rreze;
	}
}