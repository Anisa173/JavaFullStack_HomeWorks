package format.gjeometrike;

import java.util.Scanner;

public class TrekkendeDrejteDybrinjenjeshem extends TrekendeDrejte {
	private static Scanner c = new Scanner(System.in);

	public TrekkendeDrejteDybrinjenjeshem() {
	}

	public TrekkendeDrejteDybrinjenjeshem(double permasa1, double permasa2, double permasa3) {
		super(permasa1, permasa2, permasa3);
		this.permasa1 = permasa1;
		this.permasa2 = permasa2;
		this.permasa3 = permasa3;
	}

	public TrekkendeDrejteDybrinjenjeshem(double permasa1, double permasa2, double permasa3, double sip, double p) {
		super(permasa1, permasa2, permasa3, sip, p);
		this.permasa1 = permasa1;
		this.permasa2 = permasa2;
		this.permasa3 = permasa3;
		this.sip = sip;
		this.p = p;
	}

	private static double afishoPermasa() {
		System.out.println("Vendos brinjen e pare:");
		double permasa = sc.nextDouble();
		System.out.println("Brinja eshte:" + " " + permasa);
		return permasa;
	}

	public double getPermasa1() {
		afishoPermasa();
		return permasa1;
	}

	public double getPermasa2() {
		afishoPermasa();
		return permasa1;
	}

	public double getPermasa3() {
		afishoPermasa();
		return permasa3;
	}

	private double afishoSiperfaqe(double permasa1, double permasa2, double permasa3) {
		double sp = 0;

		if ((permasa1 == permasa2)) {
			double a = 2 * permasa1;
			if ((a > permasa3) && (2 * (Math.pow(permasa1, 2)) == Math.pow(permasa3, 2))) {
				System.out.println("Siperfaqja e trekendeshit kendedrejte eshte:");
				sp = (2 * permasa1) / 2;
				System.out.println(sp);
			}
		} else if ((permasa2 == permasa3)) {
			double b = 2 * permasa2;
			if ((b > permasa1) && (2 * (Math.pow(permasa2, 2)) == Math.pow(permasa1, 2))) {
				System.out.println("Siperfaqja e trekendeshit kendedrejte eshte:");
				sp = (2 * permasa2) / 2;
				System.out.println(sp);
			}
		} else if ((permasa3 == permasa1)) {
			double c = 2 * permasa3;
			if ((c > permasa2) && (2 * (Math.pow(permasa3, 2)) == Math.pow(permasa2, 2))) {
				System.out.println("Siperfaqja e trekendeshit kendedrejte eshte:");
				sp = (2 * permasa3) / 2;
				System.out.println(sp);
			}
		} else {
			System.out.println("Permasat e vendosura nuk jane brinje te nje trekendeshi kendedrejte!");
		}

		return sp;
	}

	public double getSip() {
		afishoSiperfaqe(permasa1, permasa2, permasa3);
		return sip;
	}
	private double afishoPerimeter(double permasa1, double permasa2, double permasa3) {
		double p = 0;
		double a = permasa1 + permasa2;
		double b = permasa1 + permasa3;
		double c = permasa2 + permasa3;
		if ((a > permasa3) && (b > permasa2) && (c > permasa1)) {
			p = (permasa1 + permasa2 + permasa3);
			System.out.println("Perimetri eshte:" + " " + p + " .");
		}
		return p;
	}

	public double getP() {
		afishoPerimeter(permasa1, permasa2, permasa3);
		return p;

	}
}