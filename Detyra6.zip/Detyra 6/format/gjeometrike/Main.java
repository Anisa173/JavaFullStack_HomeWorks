package format.gjeometrike;

/**
 * Te ndertohet ne Java duke perdorur edhe trashegimine nje program, qe merr
 * inputin specifik per format gjeometrike: Katror , Drejtkendesh , Trekendesh ,
 * Rreth ( psh per katrorin merret brinja , per drejtkendeshin gjatesi dhe
 * gjeresi e keshtu me rradhe) dhe printon ne console keto te dhena se bashku me
 * perimetrin dhe siperfaqen e seciles figure, te cilat duhen llogaritur per te
 * gjithe fushat.
 **/
public class Main {
	static TrekendeDrejte t = new TrekendeDrejte();
	static TrekkendeDrejteDybrinjenjeshem trekdy = new TrekkendeDrejteDybrinjenjeshem();
	static Rreth r = new Rreth();
	static Katror k = new Katror();
	static Drejtekendesh dr = new Drejtekendesh();
	static FormatGjeometrike f = new FormatGjeometrike();
	public static void main(String[] args) {
//TrekendeDrejte
	t.getPermasa1();
    t.getPermasa2();
	t.getPermasa3();
	t.getSip();
	t.getP();
//TrekkendeDrejteDybrinjenjeshem	
	trekdy.getPermasa1();
	trekdy.getPermasa2();
	trekdy.getPermasa3();
	trekdy.getSip();
	trekdy.getSip();
//Rreth
	r.getRreze();
	r.getSip();
	r.getPerimeter();
//Katror	
	k.getB();
	k.getSip();
	k.getPerimeter();
//Drejtkendesh	
	dr.getB();
	dr.getC();
	dr.getSip();
	dr.getPerimeter();
//Format Gjeometrike	
	f.getShapes();
    f.getT();
	f.getTrekdy();
	f.getR();
	f.getK();
	f.getDr();
	
	
	}

}
