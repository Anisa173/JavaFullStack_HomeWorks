package format.gjeometrike;

import java.util.Scanner;

public class FormatGjeometrike {
	private static Scanner c = new Scanner(System.in);
	private String shapes;
	TrekendeDrejte[] t;
	TrekkendeDrejteDybrinjenjeshem[] trekdy;
	Rreth[] r;
	Katror[] k;
	Drejtekendesh[] dr;

	public FormatGjeometrike() {

	}

	public FormatGjeometrike(String shapes) {
		this.shapes = shapes;
	}

	private String[] afishoFormatgjeometrike() {
		System.out.println("Numri i formave gjeometrike eshte:");
		int nrFGJ = c.nextInt();
		String[] forma = new String[nrFGJ];
		System.out.println("Afisho emrat e formave gjeometrike");
		for (int i = 0; i < nrFGJ; i++) {
			forma[i] = c.nextLine();
		}
		for (int i = 0; i < nrFGJ; i++) {
			System.out.println(forma[i]);
		}
		return forma;
	}

	public String getShapes() {
		afishoFormatgjeometrike();
		return shapes;
	}

	private TrekendeDrejte[] afishoTrekKendeDrejte() {
		int nrtk = 5;
		TrekendeDrejte[] tk = new TrekendeDrejte[nrtk];
		for (int i = 0; i < tk.length; i++) {
			System.out.println("Parametrat per trek kendedrejte te" + " " + (i + 1) + " " + "jane :");
			tk[i].getPermasa1();
			tk[i].getPermasa2();
			tk[i].getPermasa3();
			tk[i].getSip();
			tk[i].getP();
		}
		return tk;
	}

	public TrekendeDrejte[] getT() {
		afishoTrekKendeDrejte();
		return t;

	}

	private TrekkendeDrejteDybrinjenjeshem[] afishoTrekKendeDrejtedy() {
		int nrtk = 5;
		TrekkendeDrejteDybrinjenjeshem[] tk = new TrekkendeDrejteDybrinjenjeshem[nrtk];
		for (int i = 0; i < tk.length; i++) {
			System.out.println("Parametrat per trek kendedrejte dybrinjenjeshem  te" + " " + (i + 1) + " " + "jane :");
			tk[i].getPermasa1();
			tk[i].getPermasa2();
			tk[i].getPermasa3();
			tk[i].getSip();
			tk[i].getP();
		}
		return tk;
	}

	public TrekendeDrejte[] getTrekdy() {
		afishoTrekKendeDrejte();
		return trekdy;

	}

	private Rreth[] afishoRreth() {
		int nrR = 5;
		Rreth[] rr = new Rreth[nrR];
		for (int i = 0; i < nrR; i++) {
			System.out.println("Parametrat per rrethin  e" + " " + (i + 1) + " " + "jane :");
			rr[i].getRreze();
			rr[i].getSip();
			rr[i].getPerimeter();

		}
		return rr;
	}

	public Rreth[] getR() {
		afishoRreth();
		return r;

	}
	private Katror [] afishoKatror() {
		int nrk = 5;
		Katror[] kt = new Katror[nrk];
		for (int i = 0; i < nrk; i++) {
			System.out.println("Parametrat per rrethin  e" + " " + (i + 1) + " " + "jane :");
			kt[i].getB();
			kt[i].getSip();
			kt[i].getPerimeter();

		}
		return kt;
	}

	public Katror[] getK() {
		afishoKatror();
		return k;

	}
	private Drejtekendesh [] afishoDrejtkendesh() {
		int nrd = 5;
		 Drejtekendesh	[] d = new  Drejtekendesh[nrd];
		for (int i = 0; i < d.length; i++) {
			System.out.println("Parametrat per rrethin  e" + " " + (i + 1) + " " + "jane :");
			d[i].getB();
			d[i].getC();
			d[i].getSip();
			d[i].getPerimeter();

		}
		return d;
	}

	public  Drejtekendesh[] getDr() {
		afishoDrejtkendesh();
		return dr;
	}




















}
