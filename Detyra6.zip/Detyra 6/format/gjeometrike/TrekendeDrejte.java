package format.gjeometrike;

import java.util.Scanner;
import java.lang.Math;

public class TrekendeDrejte {
	protected static Scanner sc = new Scanner(System.in);
	protected double permasa1;
	protected double permasa2;
	protected double permasa3;
	protected double sip;
	protected double p;

	public TrekendeDrejte() {
		permasa1 =3;
		permasa2 = 4;
		permasa3 = 5;
		sip = 6;
		p = 12;
	}

	public TrekendeDrejte(double permasa1, double permasa2, double permasa3) {
		this.permasa1 =permasa1;
		this.permasa2 = permasa2;
		this.permasa3 = permasa3;
	}

	public TrekendeDrejte(double permasa1, double permasa2, double permasa3, double sip, double p) {
		this.permasa1 = permasa1;
		this.permasa2 = permasa2;
		this.permasa3 = permasa3;
		this.sip = sip;
		this.p = p;
	}

	private static double afishoPermasa() {
		System.out.println("Vendos brinjen:");
		double permasa = sc.nextDouble();
		System.out.println("Brinja eshte:" + " " + permasa);
		return permasa;
	}

	public double getPermasa1() {
		afishoPermasa();
		return permasa1;
	}

	public double getPermasa2() {
		afishoPermasa();
		return permasa2;
	}

	public double getPermasa3() {
		afishoPermasa();
		return permasa3;
	}

	private double afishoSiperfaqe(double permasa1, double permasa2, double permasa3) {
		double sp = 0;
		double a = permasa1 + permasa2;

		double b = permasa1 + permasa3;

		double c = permasa2 + permasa3;

		if ((a > permasa3) && ((Math.pow(permasa1, 2) + Math.pow(permasa2, 2)) == Math.pow(permasa3, 2))) {
			System.out.println("Siperfaqja e trekendeshit kendedrejte eshte:");
			sp = (permasa1 * permasa2) / 2;
			System.out.println(sp);
		} else if ((b > permasa2) && ((Math.pow(permasa1, 2) + Math.pow(permasa3, 2)) == Math.pow(permasa2, 2))) {
			sp = (permasa1 * permasa3) / 2;
			System.out.println(sp);
		} else if ((c > permasa1) && ((Math.pow(permasa2, 2) + Math.pow(permasa3, 2)) == Math.pow(permasa1, 2))) {
			sp = permasa2 * permasa3 / 2;
			System.out.println(sp);
		} else {
			System.out.println("Permasat e brinjeve nuk plotesojne kushtin per te krijuar nje trekendesh!");
		}
		return sp;
	}

	public double getSip() {
		afishoSiperfaqe(permasa1, permasa2, permasa3);
		return sip;
	}

	private double afishoPerimeter(double permasa1, double permasa2, double permasa3) {
		double p = 0;
		double a = permasa1 + permasa2;
		double b = permasa1 + permasa3;
		double c = permasa2 + permasa3;
		if ((a > permasa3) && (b > permasa2) && (c > permasa1)) {
			p = (permasa1 + permasa2 + permasa3);
			System.out.println("Perimetri eshte:" + " " + p + " .");
		}
		return p;
	}

	public double getP() {
		afishoPerimeter(permasa1, permasa2, permasa3);
		return p;

	}
	public void vizato() {
		System.out.println("Jep katetin e pare dhe katetin e dyte:");
	}

	public void jepPermasa() {
		System.out.println("Vizato trekendesh kende-drejte!");
	}

	
	
}