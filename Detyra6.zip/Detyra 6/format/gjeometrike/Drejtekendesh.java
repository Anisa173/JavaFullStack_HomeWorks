package format.gjeometrike;
import java.util.Scanner;
public class Drejtekendesh extends Katror {
private static Scanner sc = new Scanner(System.in);
	private double c;
	public Drejtekendesh() {
	
	}
	public Drejtekendesh(double b,double sip,double perimeter,double c) {
	super(b,sip,perimeter);	
	this.c = c;
	}
	private double afishoGjatesia() {
		System.out.println("Gjatesia e drejtkendeshit eshte:");
		double brinja = sc.nextDouble();
		System.out.println(brinja);
		return brinja;
	}

	public double getB() {
		afishoGjatesia();
		return b;
	}
	private double afishoGjeresia() {
		System.out.println("Gjeresia e drejtkendeshit eshte:");
		double brinja = sc.nextDouble();
		System.out.println(brinja);
		return brinja;
	}

	public double getC() {
		afishoGjeresia();
		return c;
	}

	private double afishoSip(double b,double c) {
		double s = b * c;
		System.out.println("Siperfaqja e drejtkendeshit eshte:" + " " + s + " .");
		return s;
	}

	public double getSip() {
		afishoSip(b,c);
		return sip;
	}

	private double afishoP(double b,double c) {
		double p = 2 * b*c;
		System.out.println("Perimetri i drejtkendeshit eshte:" + " " + p + " .");
		return p;
	}

	public double getPerimeter() {
		afishoP(b,c);
		return perimeter;



	}

















}
