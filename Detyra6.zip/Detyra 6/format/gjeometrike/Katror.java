package format.gjeometrike;

import java.util.Scanner;

public class Katror {
	static Scanner sc = new Scanner(System.in);
	protected double b;
	protected double sip;
	protected double perimeter;

	public Katror() {
		b = 4;
	}

	public Katror(double b) {
		this.b = b;
	}

	public Katror(double b, double sip, double perimeter) {
		this.b = b;
		this.sip = sip;
		this.perimeter = perimeter;
	}

	private double brinja() {
		System.out.println("Brinja e katrorit eshte:");
		double brinja = sc.nextDouble();
		System.out.println(brinja);
		return brinja;
	}

	public double getB() {
		brinja();
		return b;
	}

	private double afishoSip(double b) {
		double s = b * b;
		System.out.println("Siperfaqja e katrorit eshte:" + " " + s + " .");
		return s;
	}

	public double getSip() {
		afishoSip(b);
		return sip;
	}

	private double afishoP(double b) {
		double p = 4 * b;
		System.out.println("Perimetri e katrorit eshte:" + " " + p + " .");
		return p;
	}

	public double getPerimeter() {
		afishoP(b);
		return perimeter;
	}

	public void jepPermasa() {
	System.out.println("Jep brinjen e katrorit");
	}

	public void vizato() {
    System.out.println("Vizato katror!");
	}
}
