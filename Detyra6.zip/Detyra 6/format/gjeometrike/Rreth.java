package format.gjeometrike;

import java.util.Scanner;
import java.lang.Math;

public final class Rreth {
	static Scanner sc = new Scanner(System.in);
	protected double rreze;
	protected double sip;
	protected double perimeter;

	public Rreth() {
		rreze = 4;
	}

	public Rreth(double rreze) {
		this.rreze = rreze;
	}

	public Rreth(double rreze, double sip, double perimeter) {
		this.rreze = rreze;
		this.sip = sip;
		this.perimeter = perimeter;
	}

	private double afishoR() {
		System.out.println("Rrezja e rrethit eshte:");
		double brinja = sc.nextDouble();
		System.out.println(brinja);
		return brinja;
	}

	public double getRreze() {
		afishoR();
		return rreze;
	}

	private double afishoSip(double rreze) {
		double s = Math.PI * Math.pow(rreze, 2);
		System.out.println("Siperfaqja e rrethit eshte:" + " " + s + " .");
		return s;
	}

	public double getSip() {
		afishoSip(rreze);
		return sip;
	}

	private double afishoP(double rreze) {
		double p = 2 * Math.PI * rreze;
		System.out.println("Perimetri i rrethit eshte:" + " " + p + " .");
		return p;
	}

	public double getPerimeter() {
		afishoP(rreze);
		return perimeter;
	}

	public void jepPermasa() {
		System.out.println("Jep rrezen e rrethit:");
	}

	public void vizato() {
		System.out.println("Vizato rreth!");
	}

}
