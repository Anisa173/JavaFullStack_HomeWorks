package person1.oop;

import java.util.Scanner;

public class Studenti extends Person {
	private static Scanner in = new Scanner(System.in);
	private int nr_lendesh;// nr_lendesh ndjek studenti mesim
	 String[] lendeSt = new String[nr_lendesh];
	protected int[] nota = new int[nr_lendesh];
	private double mesatarja;

	public Studenti() {
		nr_lendesh = 10;
		mesatarja = 8.5;
	}

	public Studenti(String emer_mbiemer, String adrese, int nr_lendesh, String[] lendeSt, int[] nota,
			double mesatarja) {
		super(emer_mbiemer, adrese);
		this.nr_lendesh = nr_lendesh;
		this.lendeSt = lendeSt;
		this.nota = nota;
		this.mesatarja = mesatarja;
	}

	private int afishoNrLendesh() {
		System.out.println("Numri i lendeve eshte:");
		nr_lendesh = in.nextInt();
		System.out.println(nr_lendesh);
		return nr_lendesh;
	}

	public int getNr_lendesh() {
		afishoNrLendesh();
		return nr_lendesh;
	}

	private String[] afishoLendestudenti(int nr_lendesh) {
		System.out.println("Afishoni lendet qe ndjek studenti:");
		for (int i = 0; i < nr_lendesh; i++) {
			lendeSt[i] = in.next();
			System.out.println(lendeSt[i]);
		}
		return lendeSt;
	}

	public String[] getLendeSt() {
		afishoLendestudenti(nr_lendesh);
		return lendeSt;
	}

	int[] afishoNota(int nr_lendesh) {
		nr_lendesh = 5;

		System.out.println("Lista e notave te studentit");
		for (int i = 0; i < nr_lendesh; i++) {
			nota[i] = in.nextInt();
			System.out.print(nota[i]);
		}
		return nota;
	}

	public int[] getNota() {
		afishoNota(nr_lendesh);
		return nota;
	}

	private double afishoMesatareSt(int[] nota) {
		double shuma = 0;
		double mesatarja = 0;
		for (int i = 0; i < nr_lendesh; i++) {
			shuma = shuma + nota[i];
		}
		mesatarja = (shuma / nr_lendesh);
		System.out.println(mesatarja);
		return mesatarja;
	}

	public double getMesatarja() {
		afishoMesatareSt(nota);
		return mesatarja;
	}

	@Override
	public void doShopping() {
		System.out.println("Cdo fundjave bej blerje te produkteve te konsumit dhe atyre kancelarike ne supermarket.");
	}

	public void studiare() {
		System.out.println(
				"Une perpiqem te studjoj rregullisht sipas orait mesimor dhe perpiqem te hulumtoj mbi projekte para sezonale.");
	}

	public void degjonMuzike() {
		System.out.println(
				"Une degjoj rregullisht muzike relaksuese tipike per te studjuar dhe ne kohe te lire frekuentoj pub-et.");
	}

	public void fle() {
		System.out.println("Une mundohem te fle 5 deri ne 6 ore cdo nate.");
	}

}