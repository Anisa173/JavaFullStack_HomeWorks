package person1.oop;

import java.util.Scanner;

/**
 * Ushtrim 1
 * 
 * Krijoni klasën superklasën Person, me fusha private emer dhe adrese. Krijoni
 * nënklasën Student, me fusha private nrLendesh dhe mesatarja, per numrin e
 * lëndeve që frekuenton një student edhe për notën mesatare përkatësisht.
 * Krijoni nënklasën Pedagog , me fusha private nrLendesh dhe paga, për numrin e
 * lëndëve që jep mësim një pedagog edhe për pagën përkatësisht. Për çdo fushë
 * krijoni metodat get dhe set dhe për çdo klasë krijoni nje metode toString()
 * qe kthen nje String me te dhenat e objektit. Krijoni klasën Main për të
 * testuar të gjitha metodat e klasave të krijuara.
 **/

public class Main {
	static Scanner c = new Scanner(System.in);

	static Person person = new Person();
	static Studenti student = new Studenti();
	static Pedagog prof = new Pedagog();

	public static void main(String[] args) {

		// Personi
		person.setEmer_mbiemer("Anisa Cela");
		person.setAdrese("Rr:Sami Frasheri,Apartamenti 20");
		System.out.println("Personi me emer dhe mbiemer" + " " + person.getEmer_mbiemer() + " " + "banon ne adresen:"
				+ " " + person.getAdrese() + " .");
		person.doShopping();
		person.degjonMuzike();
		person.fle();
		person.studiare();
//Studenti

		student.setEmer_mbiemer("Anisa Cela");
		student.setAdrese("Tirana");

		System.out.println("Studentja" + " " + student.getEmer_mbiemer() + " " + "nga" + " " + student.getAdrese() + " "
				+ "ka frekuentuar vitin shkollor 2015-2016 duke ndjekur rregullisht" + " " + student.getNr_lendesh()
				+ "-lende .");
		System.out.println("Lendet qe ka frekuentuar studentja/studenti jane:" + " " + student.getLendeSt() + " .");
		System.out.println(
				"Studentja ka rezultuar me keto nota ne provimet e dy sezoneve:" + " " + student.getNota() + " .");
		System.out.println(
				"Mesatarja ponderuar e notave te ketij viti shkollor eshte:" + " " + student.getMesatarja() + " .");

		student.doShopping();
		student.degjonMuzike();
		student.fle();
		student.studiare();
// Pedagog

		prof.setAdrese("Tirana");
		prof.setEmer_mbiemer("Emer Mbiemer");
		prof.setPaga(150000);
		System.out
				.println("Profesori/profesoresha" + " ," + prof.getEmer_mbiemer() + " " + "nga" + " " + prof.getAdrese()
						+ " " + "jep mesim ne Universitetin e Tiranes" + " " + prof.getNr_lende() + "-lende.");
		System.out.println("Profesori/profesoresha  e ka pagen mujore:" + " " + prof.getPaga() + " .");
		System.out.println("Profesori/profesoresha" + " ," + prof.getEmer_mbiemer() + "jep mesim ne lendet si:");
		System.out.println(prof.getLendeP());
		System.out.println("Pedagogu afishon notat e studenteve ne cdo lende qe ai jep mesim:");
		prof.getStudent();
		System.out.println(prof.getStudent());

		prof.doShopping();
		prof.degjonMuzike();
		prof.fle();
		prof.studiare();
	}

}
