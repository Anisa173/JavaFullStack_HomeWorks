package person1.oop;

public class Person {
	String emer_mbiemer;
	String adrese;

	public Person() {
		emer_mbiemer = "Anisa_Cela";
		adrese = "Rr:Sami Frasheri,Apartamenti 20";
	}

	public Person(String emer_mbiemer, String adrese) {
		super();
		this.emer_mbiemer = emer_mbiemer;
		this.adrese = adrese;
	}

	public String getEmer_mbiemer() {
		return emer_mbiemer;
	}

	public void setEmer_mbiemer(String emer_mbiemer) {
		this.emer_mbiemer = emer_mbiemer;

	}

	public String getAdrese() {
		return adrese;
	}

	public void setAdrese(String adrese) {
		this.adrese = adrese;

	}

	public void doShopping() {
		System.out.println("Cdo fundjave bej blerje te produkteve te konsumit ne qender tregtare.");
	}

	public void studiare() {
		System.out.println("Une jam nje abonuese e rregullt e bibliotekes me te madhe ne qytet.");
	}

	public void degjonMuzike() {
		System.out.println("Frekuentoj 'muzik live' thuaje cdo fundjave me familjen.");
	}

	public void fle() {
		System.out.println("Une fle 8 deri ne 9 ore cdo nate.");
	}
}