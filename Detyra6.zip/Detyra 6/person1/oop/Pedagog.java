package person1.oop;

import java.util.Scanner;

public class Pedagog extends Person {
	private static Scanner sc = new Scanner(System.in);
	private static int nr_lende;// nr_lende qe jep mesim profesori/resha ne fakultet
	private double paga;
	private static String[] lendeP = new String[nr_lende];
	private static int nrStudente;
	Studenti[] student; // = new Studenti[nrStudente];

	public Pedagog() {
		nr_lende = 6;
		paga = 15478885;
		nrStudente = 120;

	}

	public Pedagog(String emer_mbiemer, String adrese, int nr_lende, double paga, String[] lendeP, Studenti[] student) {
		super(emer_mbiemer, adrese);
		this.nr_lende = nr_lende;
		this.paga = paga;
		this.lendeP = lendeP;
		this.student = student;
	}

	public void setPaga(double paga) {
		this.paga = paga;
	}

	public double getPaga() {
		return paga;
	}

	public int afishoNrLende() {
		System.out.println("Pedagogu/gia jep mesim nje numer lendesh ne Universitet.");
		nr_lende = sc.nextInt();
		System.out.println("Numri i lendeve eshte:" + " " + nr_lende + " .");
		return nr_lende;
	}

	public int getNr_lende() {
		afishoNrLende();
		return nr_lende;
	}

	protected String[] afishoLendet(int nr_lende) {
		for (int i = 0; i < nr_lende; i++) {
			lendeP[i] = sc.nextLine();
			System.out.println(lendeP[i]);
		}
		return lendeP;
	}

	public String[] getLendeP() {
		afishoLendet(nr_lende);
		return lendeP;
	}

//Metoda qe afishon te dhenat e studenteve per çdo lende dhe provim te ezauruar nga i njejti pedagog/e--lendet qe pedagogu/gia jep mesim
	public Studenti[] afishoNotaStudenti() {
		nrStudente = 200;
		/**
		 * Limiti maximal i numrit te studenteve qe marrin pjese neper provimet/lendet e
		 * pedagogut X--- Nr i studenteve qe hyjne ne provim nuk eshte i njejte ne te
		 * gjitha provimet por ne nje prej tyre do arrije nivelin e limitit maximum
		 **/

		Studenti st[] = new Studenti[nrStudente];

		for (int j = 0; j < nr_lende; j++) {
			for (int i = 0; i < nrStudente; i++) {
				System.out.println("Notat e lendes:" + " " + lendeP + " .");

				for (int k = 0; k < st[i].getNr_lendesh(); k++) {

					if (lendeP[j] == st[i].lendeSt[k]) {
						System.out.println("Nota qe merr studenti" + " " + (i + 1) + " " + "ne lenden:" + " "
								+ lendeP[j] + "eshte:" + st[i].nota[k]);

					} else {
						System.out.println(
								"Pedagogu/gia nuk i jep mesim studentit,ofrojne mesimdhenie te tjere pedagoge");
					}
				}
				System.out.println("Studentja " + " " + (i + 1) + " " + "eshte:" + st[i].getEmer_mbiemer());
				System.out.println("Adresa e studentit" + " " + (i + 1) + " " + "eshte:" + st[i].getAdrese());

			}

		}

		return st;
	}

	public Studenti[] getStudent() {
		afishoNotaStudenti();
		return student;
	}

	@Override

	public void doShopping() {
		System.out.println(
				"Cdo fundjave bej blerje te produkteve te konsumit,veshjeve dhe librave me te fundit ne qender tregtare.");
	}

	public void studiare() {
		System.out.println(
				"Kryej hulumtimet me te fundit rreth temes se doktoratures ose zhvillimeve me te fundit ne shkence dhe ekonomi");
	}

	public void degjonMuzike() {
		System.out.println(
				"Frekuentoj 'muzik live' me shoqerine dhe familjen sidomos sipas eventeve ne te cilat jam ftuar.");
	}

	public void fle() {
		System.out.println("Une fle 7 deri ne 9 ore cdo nate.");
	}

}