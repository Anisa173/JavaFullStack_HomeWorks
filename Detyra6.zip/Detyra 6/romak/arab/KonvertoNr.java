package romak.arab;

import java.util.Scanner;

public class KonvertoNr {
	static Scanner sc = new Scanner(System.in);
	private static String nrRomak;
	private static int nrArab;

	/**
	 * U1 - Krijoni një program në Java që konverton një numër Romak në Numër Arab
	 * (Integer). Numrat romake jepen si kombinim i gërmave të mëposhtme: Simboli
	 * Romak Vlera I - 1, V - 5, X - 10, L- 50, C- 100, D- 500, M- 1000
	 * 
	 * Numrat me poshte jane gjithashtu standarde: 4 - IV, 9 - IX, 40 - XL, 90 - XC,
	 * 400 - CD, 900 - CM
	 **/
	public KonvertoNr() {
		this.nrRomak = "II";
		this.nrArab = 3;
	}

	public KonvertoNr(String nrRomak, int nrArab) {
		this.nrRomak = nrRomak;
		this.nrArab = nrArab;
	}

	private static int konverto() {
		System.out.println("Vendosni numrin romak");
		nrRomak = sc.next();
		if (nrRomak == "I") {
			nrArab = 1;
			System.out.println("Numri Romak i konvertuar ne arab eshte:" + " " + nrArab + ".");
		}
		if (nrRomak == "IV") {
			nrArab = 4;
			System.out.println("Numri Romak i konvertuar ne arab eshte:" + " " + nrArab + ".");
		}

		if (nrRomak == " V") {
			nrArab = 5;
			System.out.println("Numri Romak i konvertuar ne arab eshte:" + " " + nrArab + ".");
		}
		if (nrRomak == "X") {
			nrArab = 10;
			System.out.println("Numri Romak i konvertuar ne arab eshte:" + " " + nrArab + ".");
		}
		if (nrRomak == "L") {
			nrArab = 50;
			System.out.println("Numri Romak i konvertuar ne arab eshte:" + " " + nrArab + ".");
		}
		if (nrRomak == "C") {
			nrArab = 100;
			System.out.println("Numri Romak i konvertuar ne arab eshte:" + " " + nrArab + ".");
		}
		if (nrRomak == "D") {
			nrArab = 500;
			System.out.println("Numri Romak i konvertuar ne arab eshte:" + " " + nrArab + ".");
		}
		if (nrRomak == "M") {
			nrArab = 1000;
			System.out.println("Numri Romak i konvertuar ne arab eshte:" + " " + nrArab + ".");
		}
		if (nrRomak == "IV") {
			nrArab = 4;
			System.out.println("Numri Romak i konvertuar ne arab eshte:" + " " + nrArab + ".");
		}
		if (nrRomak == "IX") {
			nrArab = 9;
			System.out.println("Numri Romak i konvertuar ne arab eshte:" + " " + nrArab + ".");
		}
		if (nrRomak == "XL") {
			nrArab = 40;
			System.out.println("Numri Romak i konvertuar ne arab eshte:" + " " + nrArab + ".");
		}
		if (nrRomak == "XC") {
			nrArab = 90;
			System.out.println("Numri Romak i konvertuar ne arab eshte:" + " " + nrArab + ".");
		}
		if (nrRomak == "CD") {
			nrArab = 400;
			System.out.println("Numri Romak i konvertuar ne arab eshte:" + " " + nrArab + ".");
		}
		if (nrRomak == "CM") {
			nrArab = 900;
			System.out.println("Numri Romak i konvertuar ne arab eshte:" + " " + nrArab + ".");
		} else {
			System.out.println("Numri romak i konvertuar ne arab nuk ekziston!");
		}
		return nrArab;
	}

	public int getNrArab() {
		konverto();
		return nrArab;
	}

}
