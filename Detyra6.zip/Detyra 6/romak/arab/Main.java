package romak.arab;

public class Main {

	public static void main(String[] args) {
		KonvertoNr k = new KonvertoNr();
		// PER KONSTRUKTORIN
		// kv.setNrRomak("II");
		// kv.setNrArab(3);
		// System.out.println("Numri romak:"+" "+kv.getNrRomak()+" "+"konvertohet ne
		// numer arab qe eshte:"+" "+kv.getNrArab()+" .");
		// Duke qene se jane nje seri numrash i marrim me skaner ...
		k.getNrArab();

	}

}
