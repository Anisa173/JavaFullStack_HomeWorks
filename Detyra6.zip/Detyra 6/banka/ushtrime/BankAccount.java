package banka.ushtrime;

import java.util.Scanner;

/**
 * U0 - Krijoni një klasë Java me emrin "BankAccount" me këto karakteristika:
 * 1.Një variabël instance private me emrin "balanca" e tipit double.
 * 2.Konstruktori që merr një vlerë fillestare si një argument double dhe
 * inicializon variablin e instancës "balance". 3.Një metodë që quhet "deposit"
 * që merr një shumë double dhe e shton atë në variablin e instancës "balance".
 * 4.Një metodë që quhet "withdraw" që merr një shumë double dhe e largon atë
 * nga variabli i instances balance (sigurohuni që të trajtoni rastin kur shuma
 * e tërheqjes është më e madhe se balanca dhe të kthehet një mesazh gabimi në
 * atë rast). 5.Një metodë getter që quhet "getBalance" që kthen balancën
 * aktuale. Pastaj, krijoni një metodë main në një klasë të ndarë që instancion
 * një objekt BankAccount me një balance fillestare dhe kryen disa depozita dhe
 * tërheqje duke përdorur metodat deposit dhe withdraw. Sigurohuni që të
 * printoni balancën aktuale pas çdo operacioni duke përdorur metodën
 * getBalance.
 **/
public class BankAccount {
	private static Scanner input = new Scanner(System.in);
	private double balanca = 5000000;
	private double vleraTotale;

	public BankAccount() {
		balanca = 5000000;
		// Konstruktor pa parameter
	}

	public BankAccount(int balanca) {
		this.balanca = balanca;
		// Konstruktor me parameter
		// System.out.println("Balanca fillestare eshte:" + " " + bank.getBalanca()); --
		// ekzekutohet ne main
	}

//Kur kryejme disa depozitime ne llogari
	public double deposit() {
		System.out.println("Vendosni numrin e depozitave qe do te kryeni");
		int n = input.nextInt();

		double depozitim[] = new double[n];
		for (int i = 0; i < n; i++) {
			if (depozitim[i] > 0) {
				System.out.println("Vlera monetare qe ju do te depozitoni:");
				depozitim[i] = input.nextDouble();
				System.out.println(depozitim[i]);
			} else {
				System.out.println("Ju nuk keni kryer depozitim parash!");
			}
			balanca = balanca + depozitim[i];
			System.out.println("Balanca pas depozitimit" + " " + (i + 1) + " " + "behet: " + balanca + " .");
		}
		return balanca;
	}

	public double getBalanca() {
		deposit();
		return balanca;
	}

	public double withdraw(double balanca) {
		vleraTotale = balanca;
		// Nese kryen terheqje nuk mund t'i terheqim te gjitha,duhet te qendrojne
		// minimalisht 15000 leke te vjetra
		vleraTotale = vleraTotale - 1500;
		double cash = 0;
		int m = 0;
		double shumaTerheqje[] = new double[m];
		System.out.println("Numri i terheqjeve qe keni kryer:");
		m = input.nextInt();
		for (int j = 0; j < m; j++) {
			if ((shumaTerheqje[j] > 0) && (shumaTerheqje[j] < vleraTotale)) {
				shumaTerheqje[j] = input.nextDouble();
				//

				System.out.println("Ju terhoqet shumen prej :" + " " + shumaTerheqje[j] + "-" + "Leke");
				vleraTotale = vleraTotale - shumaTerheqje[j];
				System.out.println("Gjendja e mbetur  ne llogari pas terheqjes se:" + " " + (j + 1) + " " + "eshte :"
						+ " " + vleraTotale + " .");
			} else {
				shumaTerheqje[j] = 0;
				System.out.println("Shuma qe ju kerkoni te terhiqni nuk eshte e disponnueshme ne llogarine tuaj!");
				System.out.println("Ju terhoqet" + " " + shumaTerheqje[j] + "-" + "Leke");
				System.out.println(
						"Nese deshironi te kryeni ndonje veprim tjeter , kthehu ne menu kryesore duke klikuar 'OK'"
								+ '\n' + "Nese jo klikoni butonin 'dil' merrni karten tuaj");
			}
			cash = cash + shumaTerheqje[j];
			System.out.println("Vlefta monetare ne perdorim nga une pas cdo terheqjeje eshte :" + " " + cash + " .");
		}
		return vleraTotale;
	}

	public double getVleraTotale() {
		withdraw(balanca);
		return vleraTotale;
	}
}