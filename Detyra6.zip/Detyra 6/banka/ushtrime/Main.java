package banka.ushtrime;

public class Main {
	

	static BankAccount bank = new BankAccount();

	public static void main(String[] args) {
	   
		System.out.println("Balanca fillestare eshte:" + " " + bank.getBalanca());
		System.out.println("Shtimet ne llogari!");
		bank.getBalanca();
		
		System.out.println("Terheqjet ne llogari:");
		
		bank.getVleraTotale();// Lexon shumen qe u terhoq nese po,nese jo lexon vleren '0'
	}
}
