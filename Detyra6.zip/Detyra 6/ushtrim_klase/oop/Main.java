package ushtrim_klase.oop;

import ushtrim_klase.oop.Kurs;
import ushtrim_klase.oop.Student;

public class Main {
    static Student st = new Student();
	static Kurs kursi = new Kurs();

  public static void main(String[] args) {
		kursi.setEmerkursi("Java BootCampI");
		kursi.setVitikursi(2023);
		System.out.println("Kursi qe ne do te ndjekim eshte:" + kursi.getEmerkursi() +" "+"dhe jemi ne vitin"+ " "+ kursi.getVitikursi());
		
        System.out.println("Afishojme te dhenat e studenteve te kursit tone:");
	   kursi.getSt();
        System.out.println(kursi.getSt());
	}
}