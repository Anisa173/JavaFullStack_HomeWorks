package ushtrim_klase.oop;

public class Kurs {

	private String emerkursi;
	private int vitikursi;
	static int nrStudent = 10;
	Student[] st = new Student[nrStudent];

	public Kurs() {
		this.emerkursi = "emerkursi";
		this.vitikursi = 2020;
	}

	public Kurs(String emerkursi, int vitikursi, Student[] st) {
		super();
		this.emerkursi = emerkursi;
		this.vitikursi = vitikursi;
		this.st = st;
	}

	public String getEmerkursi() {
		return emerkursi;
	}

	public void setEmerkursi(String emerkursi) {
		this.emerkursi = emerkursi;
	}

	public int getVitikursi() {
		return vitikursi;

	}

	public void setVitikursi(int vitikursi) {
		this.vitikursi = vitikursi;
	}

	public static Student[] afishoStudentKursi() {
		Student st1[] = new Student[nrStudent];
		for (int i = 0; i < nrStudent; i++) {
			System.out.println("Studenti" + " " + (i + 1) + " : ");

			System.out.println("Emri i studentit" + " " + (i + 1) + " " + "eshte:" + st1[i].getEmri());
			System.out.println("Mbiemri i studentit" + " " + (i + 1) + " " + "eshte:" + st1[i].getMbiemri());
			System.out.println("Kodi qe perfaqson studentin" + " " + (i + 1) + " " + "eshte:" + st1[i].getIdSt());
			System.out.println("Notat e provimeve per kete kurs studimi:");
			st1[i].getListe_notash();
			System.out.println("                                                         ");
		}
		return st1;
	}

	public Student[] getSt() {
		afishoStudentKursi();
		return st;
	}
}
