package ushtrim_klase.oop;

import java.util.Scanner;

public class Student {

	static Scanner a = new Scanner(System.in);
	static int nrSt = 100;
	static int nrLende = 10;
	private String emri;
	private String mbiemri;
	private String idSt;
	private int[] liste_notash = new int[nrLende];

    public Student() {
    	this.emri = "emri";
		this.mbiemri = "mbiemri";
		this.idSt = "idSt";
	}
    		 
	public Student(String emri, String mbiemri, String idSt, int[] liste_notash) {
		this.emri = emri;
		this.mbiemri = mbiemri;
		this.idSt = idSt;
		this.liste_notash = liste_notash;
	}


	private String afishoEmraSt() {
		String emri = null;
		// System.out.println("Vendos emrin e studentit:");
		emri = a.next();

		System.out.println(emri);
		return emri;
	}

	public String getEmri() {
		afishoEmraSt();
		return emri;
	}

	private String afishoMbiemerSt() {
		String mbiemri = null;
		// System.out.println("Vendos mbiemrin e studentit:");
		mbiemri = a.next();
		System.out.println(mbiemri);

		return mbiemri;
	}

	public String getMbiemri() {
		afishoMbiemerSt();
		return mbiemri;
	}

	private String afishoIDSt() {
      String idSt = null;
		// System.out.println("Vendos id-te e studentit:");
		idSt = a.next();
		System.out.println(idSt);
		return idSt;
	}

	public String getIdSt() {
		afishoIDSt();
		return idSt;
	}

	private static int[] listoNotat(int nrLende) {
		int[] nota = new int[nrLende];
		// System.out.println("Listo notat e studentit:");
		for (int j = 0; j < nota.length; j++) {
			nota[j] = a.nextInt();
		}
		for (int j = 0; j < nota.length; j++) {
			System.out.println(nota[j]);
		}
		return nota;
	}

	public int[] getListe_notash() {
		listoNotat(nrLende);
		return liste_notash;
	}
}
