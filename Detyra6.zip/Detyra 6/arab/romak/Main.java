package arab.romak;
import java.util.Scanner;
public class Main {
static Scanner sc = new Scanner(System.in);
	
	public static void main(String[] args) {
	Konverto kv = new Konverto();
	//PER KONSTRUKTORIN
	//kv.setNrRomak("II");
	//kv.setNrArab(3);
	//System.out.println("Numri romak:"+" "+kv.getNrRomak()+" "+"konvertohet ne numer arab qe eshte:"+" "+kv.getNrArab()+" .");
	//Duke qene se jane nje seri numrash i marrim me skaner ...
	kv.getNrArab();
	
	}

}
