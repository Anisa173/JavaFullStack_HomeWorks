package restorant.menu;

import java.util.Scanner;

/**
 * Ushtrim OOP.
 * 
 * Krijo nje app qe nepermjet modelimit me OOP realizon nje menaxhim te thjeshte
 * restoranti.
 * 
 * Hint: Klasat qe mund te perdoren jane
 * 
 * -> Restaurant -> Dish -> Order -> Customer Por mund te shtoni dhe klasa te
 * tjera si psh cilet jane ingredientet e nje ushqimi qe nje klient porosit ne
 * nje restorant.
 * 
 * p.s percaktoni karakteristika(variablat e instances) sipas deshires, p.sh per
 * nje customer ruani: nid-in, numer kontakti, adresa, emer, mbiemer
 * 
 * 
 * Perdorni marredheniet: is-a ose has-a, ku te jete e mundur.
 * 
 * Duhet qe nepermjet objektit restorant te realizohen sjelljet e meposhtme:
 * 
 * ->vendosPorosi(Dish[] dish , Customer customer); // shto porosi (order)
 * ->merrPorosiTeCustomer(Customer customer); // shfaq porosite qe klienti ka
 * bere ->merrDishTeCustomer(Customer customer); //shfaq produktet(objektet
 * Dish) qe klienti ka porositur ->shfaqCustomersTePorosise(Order order); //
 * shfaq customer qe ka bere porosine e dhene si parameter
 * ->shfaqPorosineMeTeShtrenjte(); // merr ne konsiderate koston totale te
 * porosise dhe kthe Orderin qe kete kosto e ka me te larte. Shtoni getters dhe
 * setters per cdo variabel instance dhe respektoni 3 shtyllat e OOP qe kemi
 * marre deri me tani: enkapsulimi, trashegimia, abstragimi(klasat abstrakte)
 **/
//Fast Delivery --'Foodini App' ose 'Baboon App' (apo 'KFC' APO sushiCO~monopol), hostohen ne nje numer restorante te llojeve te ndryshme per nga tipi dhe cilesia e sherbimit qe ofrojne
public class Restaurant {
	private static Scanner sc = new Scanner(System.in);
	private String emerR;
	private String kategoriaR; // Fusha e veprimtarise: Fast-Food , Kuzhine etj
	private String idRestorant;
	private String vendodhjeR;
	
	protected int nrRest = 25;// 25 pika ne te gjithe Tiranen apo Shqiperine te restorantit R..

	public Restaurant() {

	}

	public Restaurant(String emerR, String kategoriaR, String idRestorant) {
		this.emerR = emerR;
		this.kategoriaR = kategoriaR;
		this.idRestorant = idRestorant;

	}

	private String printoIdRestoranti() {
		String noNUIS = null;

		System.out.println("Restoranti identifikohet ne databazen e app nga nr NIPT-i :");
		noNUIS = sc.next();
		System.out.println(noNUIS);

		return noNUIS;

	}

	public String getIdRestorant() {
		printoIdRestoranti();
		return idRestorant;

	}

	void setEmerR(String emerR) {
		this.emerR = emerR;
	}

	public String getEmerR() {

		return emerR;
	}

	private String vendosVendodhjeRestorantesh(int nrRest) {
		String adresa = null;
		System.out.println("Vendodhja/et e restoranteve qe ofrojne sherbimin Delivery nepermjet App:");

		adresa = sc.nextLine();
		System.out.println(adresa);

		return adresa;
	}

	public String getVendodhjeR() {
		vendosVendodhjeRestorantesh(nrRest);
		return vendodhjeR;
	}

	private String afishoLlojiRestorantit(int nrRest) {
		String lloji = null;
		System.out.println("Lloji i sherbimit qe ofron Delivery restoranti nepermjet App:");

		lloji = sc.nextLine();
		System.out.println(lloji);

		return lloji;
	}

	public String getKategoriaR() {
		afishoLlojiRestorantit(nrRest);
		return kategoriaR;
	}

}
