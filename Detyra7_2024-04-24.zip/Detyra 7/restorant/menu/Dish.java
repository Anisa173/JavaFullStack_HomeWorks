package restorant.menu;

import java.util.Scanner;

public class Dish extends DishType {
	private static Scanner sc = new Scanner(System.in);
	private int[][] dish_Id;// kodi ne databaze e entitetit Dish per menune apo pjaten perkatese
	private String[][] dishTime;// koha e pergatitjes deri ne servirje
	protected String[][] dishName;// sipas llojit emrin perkates te menuse
	protected double[][] dishPrize;// kostoje e cdo menuje
	private int noDish;// numri i menuve qe lejohen te porositen
	private String[][] nameMenus;
	private double [][] nameMenuC ; 
	private String [][] nameMenuTime;
	private int [][] nameMenuId;
	public Dish() {
		noDish = 25;

	}

	public Dish(String[] dishType, int[] nodishType, int noType, int[][] dish_Id, String[][] dishTime,
			String[][] dishName, double[][] dishPrize, int noDish) {
		super();
		this.dish_Id = dish_Id;
		this.dishTime = dishTime;
		this.dishName = dishName;
		this.dishPrize = dishPrize;
		this.noDish = noDish;

	}

	private int vendosNrMenuR(int[] nodishType, int noType) {
		int noMenu = 0;
		int shuma = 0;
		System.out.println("Numri i te gjitha menuve eshte :");
		for (int i = 0; i < noType; i++) {
			shuma = shuma + nodishType[i];
		}
		noMenu = shuma;
		System.out.println(noMenu);
		return noMenu;
	}

	public int getNoDish() {
		vendosNrMenuR(nodishType, noType);
		return noDish;
	}

	private String[][] afishoMenuKategorish(int[] nodishType, int noType, String[] dishType) {
		int j = 0;
		
		nameMenus = null;
		for (int i = 0; i < noType; i++) {
			System.out.println("Menute per kategorine:" + " " + dishType[i] + " " + "jane:");
			for (j = 0; j < nodishType[i]; j++) {
				nameMenus[i][j] = sc.nextLine();
				System.out.println(nameMenus);
			}
		}
		return nameMenus;
	}

	public String[][] getDishName() {
		afishoMenuKategorish(nodishType, noType, dishType);
		return dishName;
	}

	private double[][] afishoMenuKosto(int[] nodishType, int noType, String[] dishType, String[][] dishName) {
		nameMenuC = null;
		for (int i = 0; i < noType; i++) {
			System.out.println("Cmimet e menuve per kategorine:" + " " + dishType[i] + " " + "jane:");
			for (int j = 0; j < nodishType[i]; j++) {
				System.out.println("Kosto e menuse :" + " " + dishName[i][j] + " " + "eshte:");
				nameMenuC[i][j] = sc.nextDouble();
				System.out.println(nameMenuC);
			}
		}
		return nameMenuC;
	}

	public double[][] getDishPrize() {
		afishoMenuKosto(nodishType, noType, dishType, dishName);
		return dishPrize;
	}

	private String[][] afishoMenuTime(int[] nodishType, int noType, String[] dishType, String[][] dishName) {
		nameMenuTime= null;
		for (int i = 0; i < noType; i++) {
			System.out.println(" 'Minutazhi' i cdo menuje per kategorine:" + " " + dishType[i] + " " + "eshte:");
			for (int j = 0; j < nodishType[i]; j++) {
				System.out.println("Koha e pergatitjes se menuse :" + " " + dishName[i][j] + " " + "eshte:");
				nameMenuTime[i][j] = sc.nextLine();
				System.out.println(nameMenuTime);
			}
		}
		return nameMenuTime;
	}

	public String[][] getDishTime() {
		afishoMenuTime(nodishType, noType, dishType, dishName);
		return dishTime;
	}

	private int[][] afishoMenuId(int[] nodishType, int noType, String[] dishType, String[][] dishName) {
		nameMenuId= null;
		for (int i = 0; i < noType; i++) {
			System.out.println(" Per kategorine:" + " " + dishType[i] + " :");
			for (int j = 0; j < nodishType[i]; j++) {
				System.out.println("Kodi qe perfaqeson menune :" + " " + dishName[i][j] + " " + "eshte:");
				for (int k = 0; k < 2; k++) {
					nameMenuId[0][j] = (i + 1);
					nameMenuId[1][j] = j;

					System.out.print(nameMenuId[k][j]);
				}
				System.out.println();
			}
		}
		return nameMenuId;
	}

	public int[][] getDish_Id() {
		afishoMenuId(nodishType, noType, dishType, dishName);
		return dish_Id;
	}

	@Override
	public void bejPorosi(String[] dishType, int[] nodishType, String dishName[][]) {

		System.out
				.println("Nepermjet aplikacionit te 'It's OK for breakfast!' , restoranti ju ofron keto lloj menush:");
		for (int i = 0; i < 4; i++) {
			dishType[0] = "Sandwich";
			dishType[1] = "Rizoto";
			dishType[2] = "Pica";
			dishType[3] = "Kalcone";
			nodishType[0] = 3;
			nodishType[1] = 2;
			nodishType[2] = 3;
			nodishType[3] = 4;
			System.out.println(dishType[i]);
			System.out.println(
					"Për menune:" + " " + dishType[i] + " " + ", ne ofrojme" + " " + nodishType[i] + "-lloje menush");
			for (int j = 0; j < nodishType[i]; j++) {
				System.out.println("Për menune: " + " " + dishType[i] + " " + "llojet e menuse jane:");
				dishName[0][0] = "Sanduic me mish pule";
				dishName[0][1] = "Sanduic me  proshute";
				dishName[0][2] = "Sanduic Vegjetarian";
				dishName[1][0] = "Rizoto me perime";
				dishName[1][1] = "Rizoto me fruta-deti";
				dishName[2][0] = "Pica me kerpudha normale";
				dishName[2][1] = "Margehrita";
				dishName[2][2] = "Kapricoza";
				dishName[3][0] = "Kalcone Proshutë djathë";
				dishName[3][1] = "Kalcone Vegjetariane";
				dishName[3][2] = "Kalcone Ton Kerpudhe";
				dishName[3][3] = "Kalcone Ton";
				System.out.println(dishName[i][j]);
			}

		}
	}

}