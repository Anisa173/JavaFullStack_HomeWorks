package restorant.menu;

public class AppRestorant extends App {
	private static final int nrRest = 25;
	Restaurant[] resto;
	CustomerLoyalty[] cust;
	Orders[] ord = new Orders[nrRest];

	public AppRestorant() {
	}

	public AppRestorant(String emerApp, String idApp, Restaurant[] resto, CustomerLoyalty[] cust, Orders[] ord) {
		super();
		this.resto = resto;
		this.cust = cust;
		this.ord = ord;
	}

	private Restaurant[] vendosRestorantet(int nrRest) {
		Restaurant[] rest = new Restaurant[nrRest];
		for (int i = 0; i < nrRest; i++) {
			rest[i].getIdRestorant();
			rest[i].getEmerR();
			rest[i].getVendodhjeR();
			rest[i].getKategoriaR();
			System.out.println(rest[i]);
		}
		return rest;
	}

	public Restaurant[] getResto() {
		vendosRestorantet(nrRest);
		return resto;
	}

	private Orders[] shfaqPorosiRestoranti() {
		Orders[] ord = new Orders[nrRest];
		for (int i = 0; i < nrRest; i++) {
			System.out.println("Restoranti i" + " " + (i + 1) + " " + "ka keto porosish:");
			ord[i].getOrderPrize();
			ord[i].getOrderId();
			ord[i].getWaitOrder_time();
			ord[i].getCust();
			ord[i].getOrder_status();
			System.out.println(ord);
		}
		return ord;
	}

	public Orders[] getOrd() {
		shfaqPorosiRestoranti();
		return ord;
	}
    
	
	private CustomerLoyalty[] afishoKlienteRestoranti(int nrRest) {
		CustomerLoyalty[] cl = new CustomerLoyalty[nrRest];
		for (int i = 0; i < nrRest; i++) {
			System.out.println("Per restorantin e " + " " + (i + 1) + " ," + "te dhenat e klienteve jane :");
			cl[i].getCustomerId();
			cl[i].getOrd();
			cl[i].getNid();
			cl[i].getEmer();
			cl[i].getAdresa();
			cl[i].getCardId();
			cl[i].getMbiemer();
			cl[i].getUsername();
			cl[i].getPassword();
			cl[i].getNrCel();
		}
		return cl;
	}

	public CustomerLoyalty[] getCust() {
		afishoKlienteRestoranti(nrRest);
		return cust;
	}

	public void rregjistrohu() {
		System.out.println("Klienti i interesuar 'per te bere porosi' duhet te krijoje llogari te aplikacioni");
	}
}