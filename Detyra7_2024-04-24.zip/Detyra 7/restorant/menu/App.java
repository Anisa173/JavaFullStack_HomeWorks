package restorant.menu;

public abstract class App {
	private String emerApp;
	private String idApp;

	public App() {
		emerApp = "Foodini";
		idApp = "idProdukti";// Kompania 'ikubINFO' per cdo sherbim e kryen ndaj klienteve , (ne rastin ne
								// fjale eshte nje aplikacion qe mund te instalohet qofte edhe ne cdo telefon) i
								// gjenerohet nje kod Id ne relacionin perkates te databazes ,per cdo projekt
								// apo produkt te linçuar
	}

	public App(String emerApp, String idApp) {
		this.emerApp = emerApp;
		this.idApp = idApp;
	}

	public  void setEmerApp(String emerApp) {
		this.emerApp = emerApp;
	}

	public String getEmerApp() {
		return emerApp;
	}
	public void setIdApp(String idApp) {
		this.idApp = idApp;
	}

	public String getIdApp() {
		return idApp;
	}
	public abstract void rregjistrohu();

}