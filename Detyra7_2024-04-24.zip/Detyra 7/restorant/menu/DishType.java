package restorant.menu;

import java.util.Scanner;

public abstract class DishType {
	private static Scanner in = new Scanner(System.in);
	protected String[] dishType;// emrat e kategorive
	protected int[] nodishType;// nr i menuve per kategori
	protected int noType;// nr i kategorive

	public DishType() {
		noType = 6;
	}

	public DishType(String[] dishType, int[] nodishType, int noType) {
		this.dishType = dishType;
		this.nodishType = nodishType;
		this.noType = noType;
	}

	private int vendosNrKategorie() {
		int no = 0;
		System.out.println("Vendos numrin e kategorive te menuve:");
		no = in.nextInt();
		System.out.println(no);
		return no;
	}

	public int getNoType() {
		vendosNrKategorie();
		return noType;
	}

	private String[] afishoKategoriMenush(int noType) {
		String[] menu = new String[noType];
		for (int i = 0; i < noType; i++) {
			System.out.println("Menuja e" + " " + (i + 1) + " " + "eshte:");
			menu[i] = in.nextLine();
			System.out.println(menu[i]);
		}
		return menu;
	}

	public String[] getDishType() {
		afishoKategoriMenush(noType);
		return dishType;
	}

	private int[] afishoNrMenushKategori(int noType) {
		int [] noMenu = new int [noType];
		for (int i = 0; i < noType; i++) {
			System.out.println("Numri i menuve per kategorine" + " " + (i + 1) + " " + "eshte:");
			noMenu[i] = in.nextInt();
			System.out.println(noMenu[i]);
		}
		return noMenu;
	}

	public int [] getNodishType() {
		afishoNrMenushKategori(noType);
		return nodishType;
	}
	public abstract void bejPorosi(String [] dish,int [] nodishType,String dishName[][]);// selecto menune ose menute e preferuara







}