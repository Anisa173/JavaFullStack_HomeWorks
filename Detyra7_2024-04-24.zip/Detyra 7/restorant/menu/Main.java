package restorant.menu;

public class Main {
	static Customer c = new Customer();
	static CustomerLoyalty clo = new CustomerLoyalty();
	static Orders o = new Orders();
	static Restaurant r = new Restaurant();
	static Dish d = new Dish();
	static AppRestorant appR = new AppRestorant();

	public static void main(String[] args) {
//AppRestorant
		appR.setEmerApp("It's OK for breakfast!");
		appR.getEmerApp();
		appR.setIdApp("019");
		appR.getIdApp();
		appR.getResto();
		appR.getOrd();
		appR.getCust();
//Restaurant	

		r.setEmerR("It's OK for breakfast!");
		r.getEmerR();
		r.getIdRestorant();
		r.getVendodhjeR();
		r.getKategoriaR();
//Customer	
		c.getNrkliente();
		c.getNid();
		c.getEmer();
		c.getMbiemer();
		c.getNrCel();
		c.getAdresa();
		c.getCardId();
		c.getUsername();
		c.getPassword();
//CustomerLoyalty
		clo.getCustomerId();
		clo.getOrd();
//Orders	
		o.getNrPorosi();
		o.getOrderPrize();
		o.getOrder_status();
		o.getOrderId();
		o.getWaitOrder_time();
		o.getCust();
//Dish	
		d.getNoDish();
		d.getDishName();
		d.getDishPrize();
		d.getDishTime();
		d.getDish_Id();

	}

}
