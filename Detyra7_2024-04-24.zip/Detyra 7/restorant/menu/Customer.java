package restorant.menu;

import java.util.Scanner;

public class Customer {
	private static Scanner sc = new Scanner(System.in);
//Kur klienti ben 'sign up' per here te pare duhet te plotesoje keto te dhena
	private String[] username;// nenkupton email
	private String[] password;// Strong pasword
	private String[] nid;
	private String[] emer;
	private String[] mbiemer;
	private int[] nrCel;
	private String[] adresa;
	private String[] cardId;// jo fushe e detyrueshme kur plotesohet formesi pasi mund te paguaje edhe me
							// cash
	protected int nrkliente;

	public Customer() {
		/**
		 * nid = "J25317719A"; emer = "emerPersoni"; mbiemer = "Mbiemer personi"; nrCel
		 * = "0676475397"; adresa = "Tirane,Apartamenti 20"; cardId = "cardId"; username
		 * = "celaanisa07@outlook.com"; password = "CCaa1703@@#";
		 */
	}

	public Customer(String[] username, String[] password, String[] nid, String[] emer, String[] mbiemer, int[] nrCel,
			String[] adresa, String[] cardId, Orders[] ord, int nrkliente) {
		this.nid = nid;
		this.emer = emer;
		this.mbiemer = mbiemer;
		this.nrCel = nrCel;
		this.adresa = adresa;
		this.cardId = cardId;
		this.username = username;
		this.password = password;
	}

	protected int printonrKliente() {
		System.out.println("Numri i klienteve ne restorant eshte:");
		nrkliente = sc.nextInt();
		System.out.println(nrkliente);
		return nrkliente;
	}

	public int getNrkliente() {
		printonrKliente();
		return nrkliente;
	}

	private String[] afishoNid() {
		String idPersonale[] = new String[nrkliente];
		for (int i = 0; i < nrkliente; i++) {
			System.out.println("Numri personal i identitetit per klientin e" + " " + (i + 1) + " " + "eshte:");
			idPersonale[i] = sc.next();
			System.out.println(idPersonale);
		}
		return idPersonale;
	}

	public String[] getNid() {
		afishoNid();
		return nid;
	}

	private String[] afishoemerKlienti() {
		String emerKl[] = new String[nrkliente];
		for (int i = 0; i < nrkliente; i++) {
			System.out.println("Emri i klientit te" + " " + (i + 1) + " " + "eshte:");
			emerKl[i] = sc.nextLine();
			System.out.println(emerKl);
		}
		return emerKl;
	}

	public String[] getEmer() {
		afishoemerKlienti();
		return emer;
	}

	private String[] afishombiemerKlienti() {
		String mbiemerKl[] = new String[nrkliente];
		for (int i = 0; i < nrkliente; i++) {
			System.out.println("Mbiemri i klientit te" + " " + (i + 1) + " " + "eshte:");
			mbiemerKl[i] = sc.nextLine();
			System.out.println(mbiemerKl);
		}
		return mbiemerKl;
	}

	public String[] getMbiemer() {
		afishombiemerKlienti();
		return mbiemer;
	}

	private int[] afishonrTelKlienti() {
		int nrKl[] = new int[nrkliente];
		for (int i = 0; i < nrkliente; i++) {
			System.out.println("Numri i cel te klientit te" + " " + (i + 1) + " " + "eshte:");
			nrKl[i] = sc.nextInt();
			System.out.println(nrKl);
		}
		return nrKl;
	}

	public int[] getNrCel() {
		afishonrTelKlienti();
		return nrCel;
	}

	private String[] afishoadreseKlienti() {
		String adreseKl[] = new String[nrkliente];
		for (int i = 0; i < nrkliente; i++) {
			System.out.println("Adresa e  klientit te" + " " + (i + 1) + " " + "eshte:");
			adreseKl[i] = sc.nextLine();
			System.out.println(adreseKl);
		}

		return adreseKl;
	}

	public String[] getAdresa() {
		afishoadreseKlienti();
		return adresa;
	}

	private String[] afishoCardIdKlienti() {
		String CardIdKl[] = new String[nrkliente];
		for (int i = 0; i < nrkliente; i++) {
			System.out.println("Kodi i kartes bankare te klientit te" + " " + (i + 1) + " " + "eshte:");
			CardIdKl[i] = sc.nextLine();
			System.out.println(CardIdKl);
		}

		return CardIdKl;
	}

	public String[] getCardId() {
		afishoCardIdKlienti();
		return cardId;
	}

	private String[] afishoUsernameKlienti() {
		String emailKl[] = new String[nrkliente];
		for (int i = 0; i < nrkliente; i++) {
			System.out.println("Adresa e emailit te klientit te" + " " + (i + 1) + " " + "eshte:");
			emailKl[i] = sc.nextLine();
			System.out.println(emailKl);
		}
		return emailKl;
	}

	public String[] getUsername() {
		afishoUsernameKlienti();
		return username;
	}

	private String[] afishoPasswordKlienti() {
		String passKl[] = new String[nrkliente];
		for (int i = 0; i < nrkliente; i++) {
			System.out.println("Paswordi i klientit te" + " " + (i + 1) + " " + "eshte:");
			passKl[i] = sc.nextLine();
			System.out.println(passKl);
		}
		return passKl;
	}

	public String[] getPassword() {
		afishoPasswordKlienti();
		return password;
	}

	public void kryejBlerjeApp() {
		System.out.println("Klienti nuk duhet te qendroje si nje vizitor por duhet te krijoje llogari.");
	}
}