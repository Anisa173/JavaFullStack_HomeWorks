package restorant.menu;

import java.util.Scanner;

public class Orders extends Dish {
	private static Scanner sc = new Scanner(System.in);
	private int[][] OrderId;// krijohet automatikisht pasi klienti ka zgjedhur cilat menu preferon te
							// porosise dhe vendos te paguaj me kodin e kartes se tij ose cash
	private double[] OrderPrize;// shuma e kostove te menuve te porositura plus kosto transporti ose transport
								// free nese eshte klient i besuar
	private String Order_status;// pending~ne pritje,processed ~ kur e merr porosine ne dore klienti e nxjerr
								// nga kutia , transportuesi skanon barcodin e kriptuar qe i eshte shoqeruar
								// 'OrderId-se'dhe menjehere kalon ne status processed
	// private String OrderDate;// koha kur ben klienti porosine --- ore:min:sek
	// viti:muaj:dita
	private String[] waitOrder_time;// koha e transportit nga restoranti i zgjedhur per adresen e klientit deri ne
	private String orderItems[][]; // çastin qe supozohet te marre porosin ne dore
	private int itemQuantity[][]; // ,supozohet se mund te kete edhe rradhe...
	private double[][] costOR;
	protected int nrPorosi;
	boolean processed = true;
	boolean pending = false;
	CustomerLoyalty[][] cust;

	public Orders() {

		Order_status = "Processed";

	}

	public Orders(String[] dishType, int[] nodishType, int noType, int[][] dish_Id, String[][] dishTime,
			String[][] dishName, double[][] dishPrize, int noDish, int[][] OrderId, double[] OrderPrize,
			String Order_status, String[] waitOrder_time) {
		super();
		this.OrderId = OrderId;
		this.Order_status = Order_status;

		this.waitOrder_time = waitOrder_time;
	}

	private int afishonrP() {
		System.out.println("Numri i porosive te klientit eshte:");
		nrPorosi = sc.nextInt();
		System.out.println(nrPorosi);
		return nrPorosi;
	}

	public int getNrPorosi() {
		afishonrP();
		return nrPorosi;
	}

	private double[] afishoKostoPorosie(String[] dishType, int[] nodishType, String[][] dishName, int noType,
			int nrPorosi) {
		double temp = 0;
		itemQuantity = null;
		orderItems = null;
		costOR = null;
		double costOrderid[] = new double[nrPorosi];
		for (int z = 0; z < nrPorosi; z++) {
			for (int i = 0; i < noType; i++) {
				for (int j = 0; j < nodishType[i]; j++) {
					System.out.println("Deshiroj te me sherbehet produkti i kategorise se" + " " + dishType[i] + " "
							+ "dhe menuse" + " " + dishName[i][j] + " .");
					orderItems[z][j] =  dishName[i][j];
					System.out.println("Sasia e kerkuar e produktit  qe i perket kategorise se" + " " + dishType[i]
							+ " " + "dhe menuse" + " " + dishName[i][j] + " " + "eshte:");
					itemQuantity[i][j] = sc.nextInt();
					System.out.println(itemQuantity[i][j]);
					System.out.println("Kosto e porosise"+" "+(z+1)+" "+"qe i perket kategorise se" + " " + dishType[i] + " "
							+ "dhe menuse" + " " + dishName[i][j] + " " + "eshte:");
					costOR[i][j] = itemQuantity[i][j] * dishPrize[i][j];
					costOrderid[z] = costOR[i][j];
					System.out.println(costOrderid);
					System.out.println("Menute e porosise:"+" "+(z+1)+" "+ "jane");
					System.out.println(orderItems[z][j]);
					
				}
			}
			if (costOrderid[z] > costOrderid[z + 1]) {
				temp = costOrderid[z];
				costOrderid[z] = costOrderid[z + 1];
				costOrderid[z + 1] = temp;
				System.out.println(costOrderid[z]);System.out.println(orderItems[z]);
				System.out.println(costOrderid[z + 1]);System.out.println(orderItems[z+1]);
			}
		}
		return costOrderid;
	}

	public double[] getOrderPrize() {
		afishoKostoPorosie(dishType, nodishType, dishName, noType, nrPorosi);
		return OrderPrize;
	}

	private String afishoStatusinPorosise() {

		switch (Order_status) {
		case "Processed":

			System.out.println(" Porosia eshte me status:" + " " + Order_status + " .");
		case "Pending":

			System.out.println(" Porosia eshte:" + " " + Order_status + " .");
		default:
			System.out.println(" Nje incident ka ndodhur,porosia eshte me status 'Cancel' ");
		}
		return Order_status;
	}

	public String getOrder_status() {
		afishoStatusinPorosise();
		return Order_status;
	}

//id krijohet by_default nga databaza

	private int[][] afishoIdPorosie(int nrPorosi) {

		int id[][] = new int[6][nrPorosi];
		int dita = 0;
		int muaji = 0;
		int viti = 0;
		int hour = 0;
		int min = 0;
		int sek = 0;
		for (int j = 0; j < nrPorosi; j++) {
			for (int i = 0; i < 6; i++) {
				if (sc.hasNextInt()) {
					dita = sc.nextInt();
					id[0][j] = dita;
				} else {
					System.out.println("Dita duhet te jete numer nje apo dyshifror:");
					sc.next();
				}
				if (sc.hasNextInt()) {
					hour = sc.nextInt();
					id[1][j] = hour;
				} else {
					System.out.println("Ora duhet te jete numer njeshifror apo dyshifror sipas kohes:");
					sc.next();
				}
				if (sc.hasNextInt()) {
					viti = sc.nextInt();
					id[2][j] = viti;
				} else {
					System.out.println("Viti duhet te jete numer katershifror:");
					sc.next();
				}
				if (sc.hasNextInt()) {
					min = sc.nextInt();
					id[3][j] = min;
				} else {
					System.out.println("Minutat duhet te jene numer nje apo dyshifror:");
					sc.next();
				}
				if (sc.hasNextInt()) {
					muaji = sc.nextInt();
					id[4][j] = muaji;
				} else {
					System.out.println("Muaji duhet te jete numer nje apo dyshifror:");
					sc.next();
				}
				if (sc.hasNextInt()) {
					sek = sc.nextInt();
					id[5][j] = sek;
				} else {
					System.out.println("Sekondat duhet te jene numer nje apo dyshifror:");
					sc.next();
				}

				System.out.print(id);
			}
			System.out.println();
		}
		return id;
	}

	public int[][] getOrderId() {
		afishoIdPorosie(nrPorosi);
		return OrderId;
	}

	private String[] afishokohePritje(int nrPorosi) {
		String koheP[] = new String[nrPorosi];
		for (int i = 0; i < nrPorosi; i++) {
			koheP[i] = sc.nextLine();
			System.out.println(koheP);
		} // koha kalkulohet nga koha e pergatitjes se menuse + koha e
			// transportit(relative)+koha e pritjes ne rradhe...(relative)
		return koheP;
	}

	public String[] getWaitOrder_time() {
		afishokohePritje(nrPorosi);
		return waitOrder_time;
	}

	// Override e metodes abstrakte nga klasa parent abstrakte tek child i saj
	public void vendosPorosi() {
		System.out.println(
				"Klienti mund te porosise menu nga te gjitha kategorite e menuve duke paguar me cash ose me karte.");
	}

	private CustomerLoyalty[][] shfaqCustomersPorosie(int nrPorosi) {
		int nrClient = 100;
		CustomerLoyalty[][] cust = new CustomerLoyalty[nrClient][nrPorosi];
		for (int j = 0; j < nrPorosi; j++) {
			for (int i = 0; i < nrClient; i++) {
				System.out.println("Klienti " + " " + (i + 1) + " " + "i cili ka kryer porosine" + " " + (j + 1) + " "
						+ "ka keto te dhena:");
				cust[i][j].getCustomerId();
				cust[i][j].getNid();
				cust[i][j].getEmer();
				cust[i][j].getMbiemer();
				cust[i][j].getAdresa();
				cust[i][j].getNrCel();
				cust[i][j].getPassword();
				cust[i][j].getUsername();
				cust[i][j].getCardId();
			}
		}
		return cust;
	}

	public CustomerLoyalty[][] getCust() {
		shfaqCustomersPorosie(nrPorosi);
		return cust;
	}

}