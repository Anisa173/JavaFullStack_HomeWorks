package restorant.menu;

import java.util.Scanner;

public class CustomerLoyalty extends Customer {
	private static Scanner input = new Scanner(System.in);
	private int[][] CustomerId;

	Orders[][] ord;

	public CustomerLoyalty() {

	}

	public CustomerLoyalty(String[] username, String[] password, String[] nid, String[] emer, String[] mbiemri,
			int[] nrTel, String[] adresa, String[] cardID, int[][] CustomerId, Orders[] ord, int nrkliente) {
		super();
		this.CustomerId = CustomerId;
		this.nrkliente = nrkliente;
	}

	/**
	 * Pasi arrin nje nr te caktuar porosish ne nje periudhe prej 6 muajsh
	 * ,supozojme: 15 porosi ,klientit kur logohet ne aplikacion i shfaqet nje
	 * fushe:CustomerId, dhe ne textArea kodi by default qe aplikacioni i ka
	 * vendosur dhe e pyet nese kerkon te vazhdoje ,nese po kliko vazhdo nese jo nuk
	 * kerkon te behesh klient i besuar i restorantit
	 **/
	private int[][] afishoKlientId() {
		int[][] cLId = new int[nrkliente][5];
		int muajiF = 0;
		int ditaL = 0;
		int viti = 0;
		int muajL = 0;
		int dita = 0;
		for (int i = 0; i < nrkliente; i++) {
			for (int j = 0; j < 5; j++) {
				System.out.println("Vendos diten kur eshte kryer porosia e pare:");
				if (input.hasNextInt()) {
					dita = input.nextInt();
					cLId[i][0] = dita;
				} else {
					System.out.println("Muaji duhet te jete numer!");
					input.next();
				}
				System.out.println("Vendos Muajin kur eshte kryer porosia e pare:");
				if (input.hasNextInt()) {
					muajiF = input.nextInt();
					cLId[i][1] = muajiF;
				} else {
					System.out.println("Muaji duhet te jete numer!");
					input.next();
				}
				System.out.println("Vendos diten  kur eshte kryer porosia limit:");
				if (input.hasNextInt()) {
					ditaL = input.nextInt();
					cLId[i][2] = ditaL;
				} else {
					System.out.println("Dita e muajit duhet te jete numer!");
					input.next();
				}
				System.out.println("Vendos muajin kur eshte kryer porosia limit:");
				if (input.hasNextInt()) {

					muajL = input.nextInt();
					cLId[i][3] = muajL;
				} else {
					System.out.println("Muaji duhet te jete numer !");
					input.next();
				}
				System.out.println("Vendos vitin kur eshte kryer porosia limit:");
				if (input.hasNextInt()) {
					viti = input.nextInt();
					cLId[i][4] = viti;
				} else {
					System.out.println("Viti duhet jete numer katershifror!");
					input.next();
				}

				System.out.print(cLId);
			}
			System.out.println();
		}
		return cLId;
	}

	public int[][] getCustomerId() {
		afishoKlientId();
		return CustomerId;

	}

	private Orders[][] shfaqPorosiTëKlienti(int nrkliente) {
		int nrPorosi = 50;// supozojme raportin ditor pra 50 porosi ne dite
		Orders[][] order = new Orders[nrkliente][nrPorosi];
		for (int i = 0; i < nrkliente; i++)
			for (int j = 0; j < nrPorosi; j++) {
				System.out.println("Porosia e" + " " + (j + 1) + " " + "qe ka bere klienti" + " " + (i + 1) + " "
						+ " permban keto te dhena:");
				order[i][j].getOrderPrize();
				order[i][j].getOrderId();
				order[i][j].getWaitOrder_time();
			}
		return order;

	}
	public Orders[][] getOrd() {
		shfaqPorosiTëKlienti(nrkliente);
		return ord;
	}

	public void kryejBlerjeApp() {
		System.out.println("Klienti tashme i besuar ka krijuar llogari dhe vijon te kryeje blerje ne App.");
	}

}