package biblioteka.menaxhimi;

import java.util.*;

/**
 * Krijoni një sistem menaxhimi biblioteke duke përdorur konceptet OOP në Java.
 * Biblioteka duhet të ketë funksionalitetin e mëposhtëm:
 *
 * Shtoni një libër në bibliotekë: Përdoruesi duhet të jetë në gjendje të shtojë
 * një libër në bibliotekë duke dhënë titullin e librit, autorin, ISBN dhe vitin
 * e botimit.
 *
 * Fshij një libër nga biblioteka: Përdoruesi duhet të jetë në gjendje të fshijë
 * një libër nga biblioteka duke dhënë ISBN e librit.
 *
 * Kërkoni një libër: Përdoruesi duhet të jetë në gjendje të kërkojë një libër
 * duke dhënë titullin, autorin ose ISBN e librit. Shfaqni të gjithë librat:
 * Përdoruesi duhet të jetë në gjendje të shohë një listë të të gjithë librave
 * në bibliotekë, të renditur alfabetikisht sipas titullit.
 *
 * Merrni një libër: Përdoruesi duhet të jetë në gjendje të marre një libër duke
 * dhënë ISBN e librit. Sistemi duhet të mbajë gjurmë të librave që janë marre
 * dhe kush i ka marre ato.
 *
 * Kthe librin: Përdoruesi duhet të jetë në gjendje të kthejë një libër duke
 * dhënë ISBN e librit. Sistemi duhet të përditësojë statusin e librit për të
 * treguar se është në dispozicion për tu marre serish.
 *
 * Ju duhet të krijoni klasa dhe metoda të përshtatshme për të zbatuar këtë
 * sistem biblioteke duke përdorur konceptet e OOP si mbivendosje, trashëgim,
 * dhe polimorfizëm. Ju gjithashtu duhet të konsideroni se si të trajtoni gabime
 * dhe raste kufizuese, siç është çfarë të bëni nëse një përdorues provon të
 * marre një libër që është marre tashmë nga dikush tjeter.
 */
class Libri {
	private String ISBN;
	private String titullLibri;
	private String autori;
	private String vitBotimi;
	private String gjuha;
     private String bookId;
	public Libri(String tL, String a, String vB, String is, String gj ,String id) {
		titullLibri = tL;
		autori = a;
		vitBotimi = vB;
		ISBN = is;
		gjuha = gj;
	    bookId = id;
	}

	public String toString() {
		return  bookId + ":" + titullLibri + " , " + autori + "," + vitBotimi + " , " + gjuha+" , "+ ISBN;

	}
}

class Administratori {

	//Populojme biblioteken me libra, privilegj qe e posedon vec administratori
	public static void main(String[] args) {
		LinkedList<Libri> lb = new LinkedList<Libri>();
		System.out.println("Librat e shtuar ne biblioteke jane:");
		lb.add(new Libri("J12358B", "I huaji", "Albert Camus", "1942", "Frengjisht"," 1") );
		lb.add(new Libri("J12368B", "Në kërkim të kohës së humbur", "Marcel Proust", "1913-1927", "Frengjisht","2"));
		lb.add(new Libri("J12378B", "Procesi", "Franz Kafka", "1925", "Gjermanisht","3"));
		lb.add(new Libri("J12388B", "Princi i Vogël", "Antoine de Saint-Exupéry", "1943", "Frëngjisht","4"));
		lb.add(new Libri("J12389B", "Gjendja Njerzore", "André Malraux", "1933", "Frëngjisht","5"));
		lb.add(new Libri("J12390B", "Voyage au bout de la nuit", "Louis-Ferdinand Céline", "1932", "Frëngjisht","6"));
		lb.add(new Libri("J12400B", "Vilet e Zemërimit", "John Steinbeck Nobel prize medal", "1939", "Anglisht","7"));
		lb.add(new Libri("J12401B", "Për kë bien këmbanat", "Ernest Hemingway Nobel prize", "1940", "Anglisht","8"));
		lb.add(new Libri("J12402B", "Le Grand Meaulnes", "Alain-Fournier", "1913", "Frëngjisht","9"));
		lb.add(new Libri("J12403B", "Shkuma e Ditëve", "Boris Vian", "1947", "Frëngjisht","10"));
		lb.add(new Libri("J12404B", "Madam Bovari", "Gustav Flober", "1949", "Frëngjisht","11"));
		lb.add(new Libri("J12405B", "Duke pritur Godonë", "Samuel Beckett Nobel prize medal", "1952", "Frëngjisht","12"));
		lb.add(new Libri("J12406B", "Qënia dhe Hiçi", "Jean-Paul Sartre Nobel prize medal", "1943", "Frëngjisht","13"));
		lb.add(new Libri("J12407B", "Emri i trëndafilit", "Umberto Eco", "1980", "Italisht","14"));
		lb.add(new Libri("J12408B", "Arkipelagu gulag", "Aleksandr Solzhenitsyn Nobel prize medal", "1973", "Rusisht","15"));
		lb.add(new Libri("J12409B", "Paroles", "Jacques Prévert", "1946", "Frëngjisht","16"));
		lb.add(new Libri("J12410B", "Alcools", "Guillaume Apollinaire", "1913", "Frëngjisht","17"));
		lb.add(new Libri("J12411B", "Ditari", "Anne Frank", "1947", "Gjermanisht","18"));
		lb.add(new Libri("J12412B", "Tristes tropiques", "Claude Lévi-Strauss", "1955", "Frëngjisht","19"));
		lb.add(new Libri("J12413B", "Më e Mira e Botave", "Aldous Huxley", "1932", "Anglisht","20"));
		lb.add(new Libri("J12414B", "1984", "George Orwell", "1949", "Anglisht","21"));
		lb.add(new Libri("J12415B", "Asterix", "René Goscinny dhe Albert Uderzo", "1959", "Frëngjisht","22"));
		lb.add(new Libri("J12416B", "La Cantatrice chauve", "Eugène Ionesco", "1952", "Frëngjisht","23"));
		lb.add(new Libri("J12417B", "Three Essays on the Theory of Sexuality", "Sigmund Freud", "1905", "Gjermanisht","24"));
		lb.add(new Libri("J12418B", "L'Œuvre au noir", "Marguerite Yourcenar", "1968", "Frëngjisht","25"));
		lb.add(new Libri("J12419B", "Lolita", "Vladimir Nabokov", "1955", "Anglisht","26"));
		lb.add(new Libri("J12420B", "Uliksi", "James Joyce", "1922", "Anglisht","27"));
		lb.add(new Libri("J12421B", "Shkretëtira e Tartarëve", "Dino Buzzati", "1940", "Italisht","28"));
		lb.add(new Libri("J12422B", "Les Faux-monnayeurs", "André Gide Nobel prize medal", "1925", "Frëngjisht","29"));
		lb.add(new Libri("J12423B", "Le Hussard sur le toit", "Jean Giono", "1951", "Frëngjisht","30"));
		lb.add(new Libri("J12424B", "Belle du Seigneur", "Albert Cohen", "1968", "Frëngjisht","31"));
		lb.add(new Libri("J12425B", "Njëqind vjet vetmi", "Gabriel García Márquez Nobel prize", "1967", "Spanjisht","32"));
		lb.add(new Libri("J12426B", "The Sound and the Fury", "William Faulkner Nobel prize medal", "1929",
				"Anglisht","33"));
		lb.add(new Libri("J12427B", "Thérèse Desqueyroux", "François Mauriac Nobel prize medal", "1927", "Frëngjisht","34"));
		lb.add(new Libri("J12428B", "Zazie dans le métro", "Raymond Queneau", "1959", "Frëngjisht","35"));
		lb.add(new Libri("J12429B", "Peshtjellim ndjenjash", "Stefan Zweig", "1927", "Gjermanisht","36"));
		lb.add(new Libri("J12430B", "Iku bashkë me erën", "Margaret Mitchell", "1936", "Anglisht","37"));
		lb.add(new Libri("J12431B", "Lady Chatterley's Lover", "D. H. Lawrence", "1928", "Anglisht","38"));
		lb.add(new Libri("J12432B", "Der Zauberberg", "Thomas Mann Nobel prize medal", "1924", "Gjermanisht","39"));
		lb.add(new Libri("J12433B", "Bonjour tristesse", "Françoise Sagan", "1954", "Frëngjisht","40"));
		lb.add(new Libri("J12434B", "Le Silence de la mer", "Vercors", "1942", "Frëngjisht","41"));
		lb.add(new Libri("J12435B", "La Vie mode d'emploi", "Georges Perec", "1978", "Frëngjisht","42"));
		lb.add(new Libri("J12436B", "The Hound of the Baskervilles", "Arthur Conan Doyle", "1901-1902", "Anglisht","43"));
		lb.add(new Libri("J12437B", "Sous le soleil de Satan", "Georges Bernanos", "1926", "Frëngjisht","44"));
		lb.add(new Libri("J12438B", "Getsbi i Madh", "F. Scott Fitzgerald", "1925", "Anglisht","45"));
		lb.add(new Libri("J12439B", "Shakaja", "Milan Kundera", "1967", "Çekisht","46"));
		lb.add(new Libri("J12440B", "Il disprezzo", "Alberto Moravia", "1954", "Italisht","47"));
		lb.add(new Libri("J12441B", "The Murder of Roger Ackroyd", "Agatha Christie", "1926", "Anglisht","48"));
		lb.add(new Libri("J12442B", "Nadja", "André Breton", "1928", "Frëngjisht","49"));
		lb.add(new Libri("J12443B", "Aurélien", "Louis Aragon", "1944", "Frëngjisht","50"));
		lb.add(new Libri("J12444B", "Le Soulier de satin", "Paul Claudel", "1929", "Frëngjisht","51"));
		lb.add(new Libri("J12445B", "Sei personaggi in cerca d'autore", "Luigi Pirandello Nobel prize medal", "1921",
				"Italisht","52"));
		lb.add(new Libri("J12446B", "Arturo Ui", "Bertolt Breht", "1959", "Gjermanisht","53"));
		lb.add(new Libri("J12447B", "Vendredi ou les Limbes du Pacifique", "Michel Tournier", "1967", "Frëngjisht","54"));
		lb.add(new Libri("J12448B", "Lufta mes boteve", "Herbert Xhorxh Uells", "1898", "Anglisht","55"));
		lb.add(new Libri("J12449B", "Se questo è un uomo", "Primo Levi", "1947", "Italisht","56"));
		lb.add(new Libri("J12450B", "Kryezoti i unazave", "J. R. R. Tolkien", "1954-1955", "Anglisht","57"));
		lb.add(new Libri("J12451B", "Capitale de la douleur", "Paul Éluard", "1926", "Frëngjisht","58"));
		lb.add(new Libri("J12452B", "Martin Iden", "Jack London	", "1909", "Anglisht","59"));
		lb.add(new Libri("J12453B", "La Ballade de la mer salée", "Hugo Pratt", "1967", "Italisht","60"));
		lb.add(new Libri("J12454B", "Le Degré zéro de l'écriture", "Roland Barthes", "1953", "Frëngjisht","61"));
		lb.add(new Libri("J12455B", "Die verlorene Ehre der Katharina Blum", "Heinrich Böll Nobel prize medal", "1974",
				"Gjermanisht","62"));
		lb.add(new Libri("J12456B", "Le Rivage des Syrtes", "Julien Gracq", "1951", "Frëngjisht","63"));
		lb.add(new Libri("J12457B", "Les Mots et les Choses", "Michel Foucault", "1966", "Frëngjisht","64"));
		lb.add(new Libri("J12458B", "On the Road", "Jack Kerouac", "1957", "Anglisht","65"));
		lb.add(new Libri("J12459B", "Aventurat e Nils Holgersson", "Selma Lagerlof Nobel prize medal", "1906-1907",
				"Suedisht","66"));
		lb.add(new Libri("J12460B", "Një Dhomë më Vete", "Virginia Woolf", "1929", "Anglisht","67"));
		lb.add(new Libri("J12461B", "The Martian Chronicles", "Ray Bradbury", "1950", "Anglisht","68"));
		lb.add(new Libri("J12462B", "Le Ravissement de Lol V. Stein", "Marguerite Duras", "1964", "Frëngjisht","69"));
		lb.add(new Libri("J12463B", "Le Process-verbal", "Jean-Marie Gustave Le Clézio Nobel prize medal", "1963",
				"Frëngjisht","70"));
		lb.add(new Libri("J12464B", "Tropismes", "Nathalie Sarraute", "1939", "Frëngjisht","71"));
		lb.add(new Libri("J12465B", "Journal  1887–1910", "Jules Renard", "1925", "Frëngjisht","72"));
		lb.add(new Libri("J12466B", "Lordi Xhim", "Joseph Conrad", "1900", "Anglisht","73"));
		lb.add(new Libri("J12467B", "Écrits", "Jacques Lacan", "1966", "Frëngjisht","74"));
		lb.add(new Libri("J12468B", "Le Théâtre et son double", "Antonin Artaud", "1938", "Frëngjisht","75"));
		lb.add(new Libri("J12469B", "Manhattan Transfer", "John Dos Passos	", "1925", "Anglisht","76"));
		lb.add(new Libri("J12470B", "Fiksionet", "Jorge Luis Borges", "1944", "Spanjisht","77"));
		lb.add(new Libri("J12471B", "Moravagine", "Blaise Cendrars", "1926", "Frëngjisht","78"));
		lb.add(new Libri("J12472B", "Gjenerali i ushtrisë së vdekur", "Ismail Kadare", "1963", "Shqip","79"));
		lb.add(new Libri("J12473B", "Sophie's Choice", "William Styron", "1979", "Anglisht","80"));
		lb.add(new Libri("J12474B", "Romancero gitano", "Federico García Lorca", "1928", "Spanjisht","81"));
		lb.add(new Libri("J12475B", "Pietr-le-Letton", "Georges Simenon", "1931", "Frëngjisht","82"));
		lb.add(new Libri("J12476B", "Notre-Dame-des-Fleurs", "Jean Genet", "1944", "Frëngjisht","83"));
		lb.add(new Libri("J12477B", "Der Mann ohne Eigenschaften", "Robert Musil", "1930-1932", "Gjermanisht","84"));
		lb.add(new Libri("J12478B", "Fureur et mystère", "René Char", "1948", "Frëngjisht","85"));
		lb.add(new Libri("J12479B", "Fëmijët e mesnatës", "Salman Rushdie", "1981", "Anglisht","86"));

		for (Libri val : lb) {
			System.out.println(val + "\n");
			System.out.println();
		}
		System.out.println("Numri i librave eshte:" + " " + lb.size());
		System.out.println("Pasi administratori fshin librin , lista e librave eshte:");
		lb.removeFirst();
		System.out.println(lb);
		System.out.println("Numri i librave pas fshirjes eshte:" + " " + lb.size());
	}
}
