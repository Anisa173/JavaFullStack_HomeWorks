package ushtrime.java;
class Main{
	public static void main(String[]args) {
System.out.println("Mire se erdhet ne bootcampin Java");
System.out.println(" ");
System.out.println("***********ikubINFO***********");
System.out.println(" ");
System.out.println("-------------2023-------------");
	}}

