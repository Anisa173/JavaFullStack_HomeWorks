package al.academy.ikubinfo.java;
import java.lang.Math;
public class VeprimeNumerike {
double no_1 = 10000.5555555 ;
double no_2 = 15.07;
static double shuma_pas_presjes ;
static double shuma_pas_presjes1;
boolean nr_i_plote = true;
boolean nr_jo_i_plote = false ;
private int i;
double shumaN;
double difN;
double productN;
public static void main(String[] args) {
     VeprimeNumerike rezultati = new VeprimeNumerike();
 rezultati.shumaDy_Numrave();
 rezultati.tipi_i_numrit();
 rezultati.veprimeNr();
  }
public double shumaDy_Numrave() {

double shm = no_1 + no_2 ; 
System.out.println("Shuma e numrit te pare me vlere" + " "+ no_1 + " " + "dhe numrit te dyte me vlere" + " "+ no_2 + " "  + "eshte" + " " + shm );
return shm;
}

public void tipi_i_numrit() {

int a= 15 , x = 10000 , y = 555555 , z = 7;	
i = 6;
shuma_pas_presjes = y * Math.pow(1/10, i);  
i = 2 ;
shuma_pas_presjes1 = z * Math.pow(1/10, i);
no_1 = x + y * shuma_pas_presjes ;
no_2 = a + z * shuma_pas_presjes1 ;
System.out.println(" Numrat jane:" + " " + nr_jo_i_plote );			
x = (int)no_1;
a = (int)no_2;
shuma_pas_presjes = shuma_pas_presjes1 = 0;
int shumA = x+a;
System.out.println(" Numrat jane: " + " " +x+ " "+ "dhe" +" "+a+ " " + "dhe shuma eshte " + shumA + " "+ "." + '\n' + "Tipi i numrave :" + " " + nr_i_plote);
}
public void veprimeNr() {
 double one = 50, two = 20.9 ;
 shumaN = one + two ;
 difN = one - two ;
 productN = one * two ;
 System.out.println(" Vlerat e dy variablave(lokale) me te cilat u kryen veprimet e meposhtme jane : " + " " + one + " " + two);
 System.out.println("Veprimet Numerike jane si :" + " " + "Shuma = " + shumaN + " , " + "Diferenca = " + difN + " , " + "Prodhimi i nr = " + productN);
 double tree = two + 0.1 ;
 one = tree;
System.out.println("Vlera e re e numrit me presje eshte:" + " " + tree);
System.out.println("Vlera e re qe merr variabli i pare pas shkëmbimit eshte :" + " " + one );
}}
