INSERT INTO orderitems(name,itemID,price,OrderId)
VALUES('Mercedes Benz',1,70,1),
('Gucci Bag',2,10,2),
('Mercedes Benz',1,10,3),
('Rolex',3,10,4),
('Boeing 777',4,100,5),
('Boeing 777',4,100,6),
('Boeing 777',4,100,7),
('Gucci Bag',2,10,8),
('Gucci Bag',2,10,9),
('Mercedes Benz',1,70,10),
('Rolex',3,10,11);