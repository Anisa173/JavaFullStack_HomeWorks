/**2. Gjeneroni nje query e cila liston te gjithe klientet te cilet kane dhene porosi me me shume 
sesa 2 artikuj per porosi.*/
SELECT 
    id AS CustomerID,
    CONCAT(name, ' ', lastname) AS CustomerName,
    AMOUNT AS OrderAmount
FROM
    orders
        LEFT JOIN
    customer ON orders.OrderId = customer.id
WHERE
    AMOUNT > 2