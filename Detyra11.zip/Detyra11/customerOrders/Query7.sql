/**7. Krijoni nje query ne SQL qe liston te gjithe artikujt , te cilet jane blere nga me shume se 2 
persona.*/
SELECT 
    oi.itemId, COUNT(o.customerID) AS countCustomer
FROM
    orderitems AS oi
        LEFT JOIN
    orders AS o ON oi.OrderId = o.orderID
HAVING countCustomer > 2 
