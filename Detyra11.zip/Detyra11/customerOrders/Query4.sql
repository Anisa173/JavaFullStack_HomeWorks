/** 4 - Krijoni nje query qe liston 2 punonjesit/klientët që kane shpenzuar më shumë para dhe sasinë që 
kanë shpenzuar. (Hint: mund perdorni keywords: limit , group by , order by )*/
SELECT 
    c.id AS CustomerID,
    CONCAT(c.name, ' ', c.lastname) AS CustomerName,
    SUM(o.AMOUNT * i.Price) AS total
FROM
    orders AS o
        INNER JOIN
    orderitems AS i ON o.orderID = i.OrderId
        LEFT JOIN
    customer AS c ON o.orderID = c.id
HAVING COUNT(c.id) = 2
ORDER BY total DESC
