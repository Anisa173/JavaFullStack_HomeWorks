/*1. Gjeneroni nje query e cila shfaq id e klientit , emrin dhe mbiemrin e klientit si nje kolone e 
vetme customer_name , sasine e artikullit qe ka blere si kolona order_amount , emrin e 
artikullit qe ka blere si kolona item_name si dhe cmimin perkates. Per me teper konsultohuni 
me sc e meposhtem. (Hint: per customer_name , mund te perdoret nje funksion I gatshem I 
SQL per bashkimin e stringave , beni researchin tuaj … )*/
SELECT 
    c.id AS Customer_Id,
    CONCAT(c.name, ' ', c.lastname) AS CustomerName,
    o.AMOUNT AS OrderAmount,
    oi.Name AS ItemName,
    oi.Price AS ItemPrice
FROM
    orders AS o
        LEFT JOIN
    customer AS c ON o.orderID = c.id
        LEFT JOIN
    orderItems AS oi ON o.orderID = oi.OrderId