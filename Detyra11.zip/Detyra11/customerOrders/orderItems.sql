SELECT 
    *
FROM
    ordersdb.orderitems;