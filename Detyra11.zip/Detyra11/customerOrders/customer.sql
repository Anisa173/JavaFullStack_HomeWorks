SELECT 
    *
FROM
    ordersdb.customer;