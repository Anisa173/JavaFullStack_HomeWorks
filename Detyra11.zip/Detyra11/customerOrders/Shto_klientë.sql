insert INTO CUSTOMER(id,name,lastname,age,country)
VALUES(1,'John', 'Reinhard', 22, 'Albania'),
(2,'Ema','Watson',32,'China'),
(3,'James','Bond' ,76,'USA'),
(4,'Brad','Pit',45,'USA');