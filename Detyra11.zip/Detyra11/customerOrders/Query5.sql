/** 5*. Krijoni nje query qe liston gjithe punonjesit nga USA me kushtin qe numri i porosive qe 
kane dhene te jete me i madh se 2 , por sasia totale e shpenzuar mos te jete me e madhe se 
800 si dhe te shfaqen shuma totale e shpenzuar dhe numri i porosive. (Hint: Perdorni clauses 
qe u dhane ne hint-in e ushtrimit 4 ) (Hint: Perdorni having clause )*/
SELECT 
    *
FROM
    customer
WHERE
    c.id IN (SELECT 
            COUNT(o.AMOUNT) AS orderNo,
                SUM(o.AMOUNT * oi.Price) AS total
        FROM
            orders AS o
                RIGHT JOIN
            customer AS c ON o.orderID = c.id
                LEFT JOIN
            orderitems AS oi ON o.orderID = oi.OrderId
        WHERE
            c.country = 'USA'
        HAVING ((total <= 800) AND (orderNo > 2))
        ORDER BY c.id)