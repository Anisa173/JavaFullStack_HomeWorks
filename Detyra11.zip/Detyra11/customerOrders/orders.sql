SELECT 
    *
FROM
    ordersdb.orders;