/**6. Krijoni nje query ne SQL qe liston te gjithe porosite e bera nga nje person me origjine nga USA.*/

SELECT 
    *
FROM
    customer
WHERE
    c.id IN (SELECT 
		o.AMOUNT , o.orderID 
        FROM
            orders AS o
                 left JOIN
            customer AS c ON o.orderID = c.id
        WHERE
            c.country = 'USA' 
   union
 SELECT 
		o.AMOUNT , o.orderID 
        FROM
            orders AS o
                 RIGHT JOIN
            customer AS c ON o.orderID = c.id
        WHERE
            c.country = 'USA' 
 )