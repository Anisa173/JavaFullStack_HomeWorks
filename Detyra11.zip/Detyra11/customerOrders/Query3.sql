/**3. Krijoni nje query qe liston gjithe punonjesit qe kane blere nje Boeing 777.*/
SELECT 
    c.ID AS Customer_ID,
    CONCAT(c.name, ' ', c.lastname) AS CustomerName
FROM
    orders AS o
        LEFT JOIN
    customer AS c ON o.orderID = c.id
        INNER JOIN
    orderitems AS ot ON o.orderID = ot.itemID
WHERE
    ot.Name = 'Boeing 777';             