SELECT sum(SALARY) AS TOTALsalary
FROM ordersdb.employee
