SELECT NAME 
FROM ordersdb.employee
order by NAME ASC