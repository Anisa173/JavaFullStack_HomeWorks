package sqlConnector;

import java.sql.*;
import java.util.*;

/**
 * 4-Deletes a customer and all their orders from a customer table and an orders
 * table using a transaction.Promt the user to enter the customer's ID
 */
public class MySqlcon3 {
	static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {
		try {
			// Class.forName("com.mysql.jdbc.Driver");
			Connection con = ConnectionManager.getConnection();
			System.out.println("Ju do te fshini klientin me ID :");
			int a = sc.nextInt();
			Statement st = con.createStatement();
			int i = st.executeUpdate("Delete From customer AS c Where c.customerId = " + a);
			if (i != 0) {
				System.out.println("Klienti u fshi!");
			} else {
				System.out.println("Klienti nuk ekziston!");
			}
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}

	}
}
