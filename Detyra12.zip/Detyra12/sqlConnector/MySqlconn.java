package sqlConnector;

import java.sql.*;
import java.util.*;

/**
 * 1-Retrieves the name and the email addresses of all customers from a customer
 * table.Display the result in the console
 */
public class MySqlconn {
	static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {
		try {
			// Class.forName("com.mysql.jdbc.Driver");
			Connection con = ConnectionManager.getConnection();
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from customer");
			while (rs.next()) {
				int customerId = rs.getInt("customerId");
				String emCust = rs.getString("emCust");
				String custName = rs.getString("custName");
				System.out.println("customerId :" + " " + customerId + " " + "emailCustomer: " + " " + emCust + "  "
						+ "CustomerName :" + " " + custName);
			}

			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	}

}
