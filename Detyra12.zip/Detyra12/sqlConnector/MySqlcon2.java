package sqlConnector;

import java.sql.*;
import java.util.*;

/**
 * 3-Updates the email address of a customer in the customer table using a
 * prepared statement.
 */
public class MySqlcon2 {

	public static void main(String[] args) {
		try (Scanner sc = new Scanner(System.in)) {
			try {
				// Class.forName("com.mysql.jdbc.Driver");
				Connection con = ConnectionManager.getConnection();
				System.out.println('\n' + "Vendos email te klientit");
				String email = sc.nextLine();
				System.out.println("Përditëso Id të klientit");
				int idC = sc.nextInt();
				PreparedStatement pt1 = con
						.prepareStatement("UPDATE customer SET customerId = " + idC + " Where emCust = " + email);

				pt1.executeUpdate();
				con.close();
			} catch (Exception e) {
				System.out.println(e);
			}
		}
	}

}
