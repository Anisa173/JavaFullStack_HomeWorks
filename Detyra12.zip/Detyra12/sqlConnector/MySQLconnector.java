package sqlConnector;

import java.sql.*;


public class MySQLconnector {

	public static void main(String[] args) throws SQLException {
		 
	       // Class.forName ("oracle.jdbc.driver.OracleDriver");    
	        Connection con = ConnectionManager.getConnection();
	        PreparedStatement ps = con.prepareStatement("Delete From customer Where customerId = ?");
	        ps.setInt(1,12345);
	        ps.executeUpdate();
	      
	     
	        ps.close ();
	        con.close ();
	    } 
	
	}


