package sqlConnector;

import java.sql.*;
import java.util.*;

public class ShtoPorosi {
	static Scanner input = new Scanner(System.in);

	public static void main(String[] args) {

		try {
			Connection conn = ConnectionManager.getConnection();

			System.out.println("Id e porosisë është :");
			int idO = input.nextInt();
			System.out.println("Numri i artikujve të porositur është :");
			int OrderItems = input.nextInt();
			System.out.println("Koha e kryerjes nga klienti të porosisë është :");
			String time = input.next();
			System.out.println("Koha e proçesimit të  nga porosisë është :");
			String timeProcessed = input.next();
			System.out.println("Id e klientit që porosit është :");
			int idC = input.nextInt();
			PreparedStatement st = conn.prepareStatement(
					"Insert table order(OrderID,OrderAmount,OrderDate,OrderDateprocessed,customerID) VALUES(?,?,?,?,?)");
			st.setInt(1, idO);
			st.setInt(2, OrderItems);
			st.setString(3, time);
			st.setString(4, timeProcessed);
			st.setInt(5, idC);
			int i = st.executeUpdate();
			if (i != 0) {
				System.out.println("added");
			} else {
				System.out.println("failed to add");
			}
			conn.close();
		} catch (SQLException e) {

			System.out.println(e);
		}
	}

}
