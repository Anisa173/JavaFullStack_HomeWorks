package sqlConnector;

import java.sql.*;
import java.util.*;

/**
 * 2- Inserts a new customer into a customers table using a prepared
 * statement.Promt the user to enter the customer's name and email address and
 * generate a unique ID for the customer.
 */
public class MySqlconn1 {
	static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {
		try {
			// Class.forName("com.mysql.jdbc.Driver");
			Connection con = ConnectionManager.getConnection();
			System.out.println('\n' + "Vendos CustomerId:");
			int id = sc.nextInt();
			System.out.println("Vendos Adresen e Emailit:");
			String emailC = sc.nextLine();
			System.out.println("Vendos Emrin dhe Mbiemrin e Klientit :");
			String customerName = sc.nextLine();
			PreparedStatement pt = con
					.prepareStatement("INSERT INTO customer(customerId,emCust,custName) VALUES(?,?,?)");
			pt.setInt(1, id);
			pt.setString(2, emailC);
			pt.setString(3, customerName);
			int i = pt.executeUpdate();
			if (i != 0) {
				System.out.println("added");
			} else {
				System.out.println("failed to add");
			}
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	}

}
