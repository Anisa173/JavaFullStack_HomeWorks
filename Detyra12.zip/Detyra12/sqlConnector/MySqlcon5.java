package sqlConnector;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.*;

public class MySqlcon5 {
	static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {
		try {
			Connection con = ConnectionManager.getConnection();
			System.out.println('\n' + "Vendos id  të porosisë së klientit");
			int idO = sc.nextInt();

			System.out.println("Përditëso id të klientit");

			int idC = sc.nextInt();
			PreparedStatement pt2 = con.prepareStatement("UPDATE order SET customerId = ? From   Where OrderID = ?");
			pt2.setInt(1, idO);
			pt2.setInt(2, idC);
			pt2.executeUpdate();
			con.close();
		} catch (SQLException e) {

			e.printStackTrace();
		}

	}

}
