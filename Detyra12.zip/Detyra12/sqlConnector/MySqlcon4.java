package sqlConnector;

import java.sql.Connection;


import java.sql.PreparedStatement;
import java.util.*;

/**
 * 5-Retrieves all orders placed on a specific date from an order table and
 * displays the orders's Id-s,customerNames and OrderAmount in the console.Join
 * the orders and customer table to get the customer names.
 */
public class MySqlcon4 {
	static Scanner in = new Scanner(System.in);

	public static void main(String[] args) {
		try {
			Connection conn = ConnectionManager.getConnection();
			System.out.println("Filtro sipas datës së kryerjes");
			// String datePoint = in.next();
			PreparedStatement pt = conn.prepareStatement(
					"Select o.OrderID ,c.custName,o.OrderAmount,o.OrderDate From customer AS c INNER JOIN orders AS o ON c.customerId = o.customerID  Where o.OrderDate ='2022-03-03' ");
			pt.executeUpdate();
			conn.close();
		} catch (Exception e) {

			e.printStackTrace();
		}

	}

}
