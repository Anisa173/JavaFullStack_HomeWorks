Insert into Customer(customerId,emailcust,custName) 
VALUES(12345,'celaanisa07@gmail.com','Anisa Çela'),
(13345,'plakuanisa02@outlook.com','Anisa Plaku'),
(14345,'cockaadela01@yahoo.com','Adela Çoçka'),
(15345,'celaervis86@hotmail.com','Ervis Çela'),
(16345,'kushivahbi22@outlook.com','Vehbi Kushi');