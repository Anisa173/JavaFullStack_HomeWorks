SELECT 
    *
FROM
    customerorder.customer;