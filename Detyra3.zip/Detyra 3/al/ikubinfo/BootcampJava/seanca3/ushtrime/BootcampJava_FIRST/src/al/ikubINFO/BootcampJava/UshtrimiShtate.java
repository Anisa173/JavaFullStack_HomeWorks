package al.ikubINFO.BootcampJava;
import java.util.Scanner;
public class UshtrimiShtate {
private static Scanner input;

public static void main(String[] args) {
input = new Scanner(System.in);
System.out.println("Vendosni se sa here deshironi te afishoni tekstin");
int n = input.nextInt();
System.out.println("Vendosni stringun");
String c = input.next();
System.out.println('\n' + "Stringu i afishuar" + '\n');
for(int i=0;i<n;i++) {System.out.println(c);
}

}}
