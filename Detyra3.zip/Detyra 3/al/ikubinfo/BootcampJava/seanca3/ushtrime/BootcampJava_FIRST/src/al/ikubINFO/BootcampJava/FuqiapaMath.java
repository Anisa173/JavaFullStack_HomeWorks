package al.ikubINFO.BootcampJava;
import java.util.Scanner;
public class FuqiapaMath {
//Ushtrimi 10
	static int no1,no2, result;
	private static Scanner input;
	public static void main(String[] args) {
input = new Scanner(System.in);
System.out.println("Vendosni inputin ne konsole :");
no1 = input.nextInt();		 
no2 = input.nextInt();	
result =ngrejFuqi();
System.out.println(result);
	}
public static int ngrejFuqi() {
int n1=no1; int n2 = no2;int n=1;
int vlera =1;
while(n<=n2) {	
vlera*=n1;
n++;
}
System.out.println("Rezultati i" +" " + n1+ " "+"i ngritur ne fuqi te "+ " " + n2 + " " + "eshte :");
return vlera;
}}
