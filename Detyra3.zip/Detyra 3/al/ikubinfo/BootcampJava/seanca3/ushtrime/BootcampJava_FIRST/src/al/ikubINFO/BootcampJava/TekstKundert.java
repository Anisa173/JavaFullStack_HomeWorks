package al.ikubINFO.BootcampJava;
import java.util.Scanner;
public class TekstKundert {
private static Scanner input;
static char n,n1,n2,n3,n4;

static boolean palindrome = true;
static boolean joPalindrome =false;
public static void main(String[] args) {
input = new Scanner(System.in);
boolean pohimi;
System.out.println("Stringu yne prej pese karakteresh eshte :");
if(input.hasNext()) {n = input.next().charAt(0);}
else {System.out.println("Useri ka vndosur gabim inputin");}
if(input.hasNext()) {n1 = input.next().charAt(0);}
else {System.out.println("Useri ka vndosur gabim inputin");}	
if(input.hasNext()) {n2 = input.next().charAt(0);}
else {System.out.println("Useri ka vndosur gabim inputin");}
if(input.hasNext()) {n3 = input.next().charAt(0);}
else {System.out.println("Useri ka vndosur gabim inputin");}
if(input.hasNext()) {n4 = input.next().charAt(0);}
else {System.out.println("Useri ka vndosur gabim inputin");}
System.out.print(n);
System.out.print(n1);
System.out.print(n2);
System.out.print(n3);
System.out.print(n4);
System.out.println('\n'+"Stringu i invertuar eshte :");
System.out.print(n4);
System.out.print(n3);
System.out.print(n2);
System.out.print(n1);
System.out.print(n);
boolean a=(n1==n3);
boolean b=(n==n4);
if(b&&a) {pohimi = palindrome;System.out.println('\n'+"Stringu yne eshte palindrome:" +" "+ pohimi+" !" );
} else {pohimi = joPalindrome;System.out.println('\n'+"Stringu yne eshte palindrome:" +" "+ pohimi+" !" );

}}}
