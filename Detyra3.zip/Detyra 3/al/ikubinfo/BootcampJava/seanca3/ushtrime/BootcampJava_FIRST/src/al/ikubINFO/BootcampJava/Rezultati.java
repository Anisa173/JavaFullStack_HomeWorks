package al.ikubINFO.BootcampJava;
import java.util.Scanner;
import java.lang.Math;
public class Rezultati {
static double shuma = -0.5;
private static Scanner input;
public static void main(String[] args) {
 input = new Scanner(System.in);
System.out.println("Vendosni parametrin : ");
double n = input.nextDouble();
System.out.println("Shuma eshte :");
for(int i=0;i<=n;i++) {
shuma = shuma + Math.pow(0.5,i);}
System.out.println(shuma);

	}
}
