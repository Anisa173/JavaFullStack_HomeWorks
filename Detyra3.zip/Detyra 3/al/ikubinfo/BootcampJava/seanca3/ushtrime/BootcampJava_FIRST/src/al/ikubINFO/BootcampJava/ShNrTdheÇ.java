package al.ikubINFO.BootcampJava;
import java.util.Scanner;
public class ShNrTdheÇ {
	
	static int nr, result;
	private static Scanner sc;
	public static void main(String[] args) {
	 sc = new Scanner(System.in);
	System.out.println("Vendosni te gjithe numrat me te medhenj se 35 , por me te vegjel se 100 !");
	 nr = sc.nextInt();
	result = shumaTek();
	System.out.println("Shuma e numrave tek  eshte");
	System.out.println(result);
	System.out.println("                        ");
	result = shumaCift();
	System.out.println("Shuma e numrave cift eshte");
	System.out.println(result);
	System.out.println("                        ");
	result = shumaTotale();
	System.out.println("Shuma e totale e numrave  eshte : ");
	System.out.println(result);
	}
	public static int shumaTek() {
	int sh=0;
	for(nr = 37;nr <=99; nr+=2) {

	sh = sh + nr;
	}
	return sh;}

	public static int shumaCift() {
	int sh1 = 0;
	for(nr = 36;nr <=99; nr+=2) {
	sh1 = sh1 + nr;
	}
	return sh1;	}


	public static int shumaTotale() {
	int shm = 0;
	for(nr =36 ; nr<= 99; nr++) {
	shm = shm + nr;
	}
	return shm;}}
