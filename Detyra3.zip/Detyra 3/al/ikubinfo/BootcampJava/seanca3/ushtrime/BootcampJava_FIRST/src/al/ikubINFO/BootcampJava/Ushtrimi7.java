package al.ikubINFO.BootcampJava;
import java.util.Scanner;
public class Ushtrimi7 {
private static Scanner input;
	public static void main(String[] args) {
 input = new Scanner(System.in);
System.out.println("Vendosni numrin e afishimit ");
int n = input.nextInt();

for(int i=0;i<n;i++) {System.out.println( "Mire se erdhe ne programin e Java Bootcamp!"+ '\n' );

}}}
