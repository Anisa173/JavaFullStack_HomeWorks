package al.ikubINFO.BootcampJava;

import java.lang.Math;
public class RezultatiSerisekohore {
static double shuma= 1;
static double m;
public static void main(String[] args) {

System.out.println("Shuma e serise kohore eshte:");

for(m=2;m<=10.65;m++){ shuma = shuma + Math.pow(0.5, m);
System.out.println(shuma);}

}}
