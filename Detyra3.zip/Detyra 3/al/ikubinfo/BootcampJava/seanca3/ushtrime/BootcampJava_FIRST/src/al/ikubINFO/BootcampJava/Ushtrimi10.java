package al.ikubINFO.BootcampJava;
import java.util.Scanner;
public class Ushtrimi10 {
static int no1,no2, result;
	private static Scanner input;
	public static void main(String[] args) {
input = new Scanner(System.in);
System.out.println("Vendosni inputin ne konsole :");
no1 = input.nextInt();		 
no2 = input.nextInt();	
result =ngrejFuqi();
System.out.println(result);
	}
public static int ngrejFuqi() {
int n1=no1; int n = no2;
int vlera =1;
int pow[] = new int[n];
for(int i=0;i<n;i++) {	
pow[i]= n1;	
vlera *=pow[i];}	
System.out.println("Numri i pare i plote" + " "+ n1+ " "+ "i ngritur ne fuqi te" +" "+ n+" " + "sa vlera e numrit te dyte te plote , eshte i barabarte me :");
return vlera;
}}