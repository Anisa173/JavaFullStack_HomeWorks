package al.ikubINFO.BootcampJava;
import java.util.Scanner;
public class AfishoYjeKatror {
private static Scanner input;
static int i;
private final static int n = 6;
public static void main(String[] args) {
	input = new Scanner(System.in);
String v[] = new String[n]; 

System.out.println("Mbushni katrorin me yje:");
for(i = 0; i < n ;i++) {
v[i] = input.next();
}
for(i = 0; i<n;i++) {String m1[] = new String[n];
m1[i]= v[i];
System.out.print(m1[i]);}
System.out.println("                                       ");
for(i = 0; i<n;i++) {
String m1[] = new String[n];
	m1[i]= v[i];
System.out.print(m1[i]);}
System.out.println("                                       ");
for(i = 0; i<n;i++) {
String m1[] = new String[n];
	m1[i]= v[i];
System.out.print(m1[i]);}
System.out.println("                                       ");
for(i = 0; i<n;i++) {
String m1[] = new String[n];
	m1[i]= v[i];
System.out.print(m1[i]);}
System.out.println("                                       ");
for(i = 0; i<n;i++) {
String m1[] = new String[n];
	m1[i]= v[i];
System.out.print(m1[i]);}
System.out.println("                                       ");
for(i = 0; i<n;i++) {
String m1[] = new String[n];
	m1[i]= v[i];
System.out.print(m1[i]);}
}}


