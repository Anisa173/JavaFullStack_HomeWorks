package al.ikubINFO.BootcampJava;
import java.util.Scanner;
public class NrRendikundert {
static int n1,n2,n3,n4,n5;
	private static Scanner in;
	public static void main(String[] args) {
 in = new Scanner(System.in);
System.out.println("Numri yne dyshifror eshte:");
if(in.hasNextInt()&& (n1<10)) {
 n1 = in.nextInt();} else if(n1>=10) {System.out.println("Numri i pare nuk eshte numer njeshifror!");}
 else{System.out.println("Numri i pare nuk eshte numer i plote njeshifror");in.next();}
if(in.hasNextInt()&&(n2<10)) {
n2 = in.nextInt();} else if(n2 >=10) {System.out.println("Numri i dyte nuk eshte nje numer njeshifror");}
else{System.out.println("Numri i dyte nuk eshte numer i plote njeshifror!");in.next();}
System.out.print(n1);
System.out.print(n2);
System.out.println('\n'+ "Numri dyshifror i invertuar eshte :");
System.out.print(n2);
System.out.print(n1);
System.out.println("                                         ");
System.out.println("Numri yne trishifror eshte :");
if(in.hasNextInt()&&(n3 < 10)) {n3=in.nextInt();}
else if(n3>=10) {System.out.println("Numri i pare nuk eshte numer njeshifror!");}
else{System.out.println("Numri i pare nuk eshte numer i plote njeshifror");in.next();} 
if(in.hasNextInt()&& (n4 < 10)) {n4=in.nextInt();} 
else if(n4>=10) {System.out.println("Numri i pare nuk eshte numer njeshifror!");}
else{System.out.println("Numri i dyte nuk eshte numer i plote njeshifror");in.next();} 
if(in.hasNextInt()&& (n5<10)) {n5 = in.nextInt();} 
else if(n5>=10) {System.out.println("Numri i pare nuk eshte numer njeshifror!");}
else{System.out.println("Numri i trete nuk eshte numer i plote njeshifror");in.next();} 
System.out.print(n3);
System.out.print(n4);
System.out.print(n5);
System.out.print('\n' + "Numri treshifror i invertuar eshte :" + '\n');
System.out.print(n5);
System.out.print(n4);
System.out.print(n3);
System.out.println("                                         ");
System.out.println("Numri yne kater shifror eshte :");
if(in.hasNextInt()&&(n1 < 10)) {n1=in.nextInt();}
else if(n1>=10) {System.out.println("Numri i pare nuk eshte numer njeshifror!");}
else{System.out.println("Numri i pare nuk eshte numer i plote njeshifror");in.next();} 
if(in.hasNextInt()&& (n2 < 10)) {n2=in.nextInt();} 
else if(n2>=10) {System.out.println("Numri dyte nuk eshte numer njeshifror!");}
else{System.out.println("Numri i dyte nuk eshte numer i plote njeshifror");in.next();} 
if(in.hasNextInt()&&(n4<10)){n4 = in.nextInt();}
else if(n4>=10) {System.out.println("Numri i trete nuk eshte numer njeshifror!");}
else{System.out.println("Numri i trete nuk eshte numer i plote njeshifror");in.next();} 
if(in.hasNextInt()&& (n5<10)) {n5 = in.nextInt();} 
else if(n5>=10) {System.out.println("Numri i katert nuk eshte numer njeshifror!");}
else{System.out.println("Numri i trete nuk eshte numer i plote njeshifror");in.next();} 
System.out.print(n1);
System.out.print(n2);
System.out.print(n4);
System.out.print(n5);
System.out.print('\n' + "Numri katershifror i invertuar eshte :"+'\n');
System.out.print(n5);
System.out.print(n4);
System.out.print(n2);
System.out.print(n1);
	}

}
