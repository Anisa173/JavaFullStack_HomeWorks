package al.ikubINFO.BootcampJava;
import java.util.Scanner;
public class TrekendeshScanner {
private static Scanner input;
	public static void main(String[] args) {
	input = new Scanner(System.in);	
	// n= 5 sic kerkohet neushtrim, por mund te jete nje numer cfaredo 
	System.out.println("Vendos numrin e elementeve :");
	int n = input.nextInt();
	System.out.println("                                            ");
	for(int i=0;i <= n-1;i++) {
			for(int j=n-2*i;j< n;j++) {
			System.out.print("*");}
		System.out.println("*");
		System.out.println("                                         ");
			}
	}
}
