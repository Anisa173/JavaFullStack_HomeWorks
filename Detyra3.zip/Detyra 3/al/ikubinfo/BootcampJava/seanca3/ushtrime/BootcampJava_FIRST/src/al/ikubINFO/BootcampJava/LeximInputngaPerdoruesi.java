package al.ikubINFO.BootcampJava;

import java.util.Scanner;
import java.lang.Math;
public class LeximInputngaPerdoruesi {
private static Scanner input;
    public static void main(String[] args) {
        int numriPare = 0;
        double numriDyte = 0;
        input = new Scanner(System.in);
        System.out.println("Ju lutem vleren e numrit te pare ");
        if(input.hasNextInt()) { // Kontrollo nese inputi i dhene nga perdoruesi eshte ne formatin qe na duhet
            numriPare = input.nextInt(); //Nese tipi eshte i sakte, marrim vleren
        } else {
            System.out.println("Keni dhene nje vlere te gabuar!");//Nese jo, japim nje mesazh qe inputi ishte i gabuar
            input.next();//Perdorim metoden next() per te konsumuar vleren e gabuar, e te kemi mundesi qe te marrim inputin e radhes
        }

        System.out.println("Ju lutem vleren e numrit te dyte ");
        if(input.hasNextDouble()) {
            numriDyte = input.nextDouble();
        } else {
            System.out.println("Keni dhene nje vlere te gabuar!");
            input.next();
        }
        System.out.println("Shuma e numrave te kaluar si input eshte  " + (numriPare + numriDyte));
    System.out.println("Diferenca e numrave te kaluar si input eshte  " + Math.abs(numriPare - numriDyte));
    System.out.println("Produkti i numrave te kaluar si input eshte  " + (numriPare * numriDyte));
    }
}

