package al.ikubINFO.BootcampJava;

import java.util.Scanner;

public class Inverse {
	private static Scanner input;
   static int i,temp;
	public static void main(String[] args) {
		input = new Scanner(System.in);	
	
	System.out.println("Vendosni nr e elementeve : ");
		int n = input.nextInt();
		int numri[] = new int[n];int nr[] = new int[n];
		System.out.println("Vendosni elementet njeshifrore : ");
		for (i = 0; i < n; i++){
		numri[i] = input.nextInt();}
		System.out.println("Numri eshte :");
		for(i= 0; i < n; i++) {
		nr[i] = numri[i];
		System.out.print(nr[i]);
		}
		System.out.println('\n');
		//Kembimi numrave
     System.out.println("Numri i invertuar eshte :");
     
     for(i=0;i<n;i++){int j = n-i-1;
		
        temp = nr[i];
		nr[i]= nr[j];
		nr[j]= temp; 
        System.out.print(nr[i]);}}
        
        
}
        
		
		
	
	

		
		