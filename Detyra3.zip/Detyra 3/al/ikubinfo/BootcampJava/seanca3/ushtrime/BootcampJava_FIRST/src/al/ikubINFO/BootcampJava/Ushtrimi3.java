package al.ikubINFO.BootcampJava;
import java.util.Scanner;
public class Ushtrimi3 {
static double  result;private static Scanner sc;
static int n,i;
static double num,sh;
public static void main(String[] args) {
sh = 0;
sc = new Scanner(System.in);
System.out.println("Sa numra do te vendosni  si input :");
if(sc.hasNextInt()){
 n = sc.nextInt();}
else{System.out.println("Kemi hedhje te gabuar te n-se "); sc.next();}

System.out.println("Futni  numrat dyshifror ne konsole:");
	for(i = 0;i < n; i++) {
	if(sc.hasNextDouble()){
		double c[] = new double[n];
		c[i] = sc.nextDouble();
	sh = sh + c[i];System.out.println("Shuma i numrave dyshifror eshte :" + " " + sh);}
	
	else{System.out.println("Kemi vendosur te dhenat e gabuara ne console");sc.next();}
	}}}
	
			


		


		
		
		
	


