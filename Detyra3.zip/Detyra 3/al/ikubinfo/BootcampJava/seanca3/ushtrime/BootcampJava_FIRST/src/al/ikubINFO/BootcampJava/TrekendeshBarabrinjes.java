package al.ikubINFO.BootcampJava;
import java.util.Scanner;
public class TrekendeshBarabrinjes {
private static Scanner input;
	public static void main(String[] args) {
	input = new Scanner(System.in);	
	// n= 5 sic kerkohet ne ushtrim, por mund te jete nje numer cfaredo 
	System.out.println("Vendos numrin e elementeve :");
	int n = input.nextInt();
	System.out.println("                                            ");
	for(int i=0;i < n;i++){
	for(int j=0;j< n-i-1;j++){
		System.out.print(" ");}
			for(int m=n-i;m<=n+i;m++) { System.out.print("*");}
			System.out.println(" ");}
			}
	}
	

	