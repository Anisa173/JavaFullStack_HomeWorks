package al.ikubINFO.BootcampJava;
import java.util.Scanner;
public class NrSeancesSwitch {
private static Scanner x;
	public static void main(String[] args) {
	x = new Scanner(System.in);
System.out.println("Mire se erdhet ne programin Java Bootcamp 2023!");
System.out.println("                                               ");
System.out.println("Ju lutem vendosni numrin e seances:");

int nrSeanca = x.nextInt();
switch(nrSeanca) {
case 1:
System.out.println("Hyrje ne Java");
break;
case 2:
System.out.println("Strukturat e Kontrollit dhe Operatoret Logjike");
break;
case 3:
System.out.println("Loops ,Switch dhe  Jumping statements");	
break;
case 4:
System.out.println("Arrays 1D dhe 2D");			
break;
default:
System.out.println("Moduli i pare nuk permban nje teme per seancen qe ju kerkuat!");
}}}
