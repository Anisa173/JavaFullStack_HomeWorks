package al.ikubINFO.BootcampJava;

import java.util.Scanner;

public class AfishoMbrapsht {
			private static Scanner input;
		static int i,temp,k;
		 
			public static void main(String[] args) {
				input = new Scanner(System.in);	
			
			System.out.println("Vendosni nr e elementeve : ");
				int n = input.nextInt(); 
				int numri[] = new int[n];int nr[] = new int[n];
				System.out.println("Vendosni elementet njeshifrore : ");
				for (i = 0; i < n; i++){
				numri[i] = input.nextInt();}
				System.out.println("Numri eshte :");
				for(i= 0; i < n; i++) {
				
				nr[i] = numri[i];
				System.out.print(nr[i]);
				}
				System.out.println('\n');
				//Kembimi numrave
		        System.out.println("Numri i invertuar eshte :");
				
				for(k=n-1;k<n;--k){ 
		        for(i=0;i<k;i++)
			{   
		        temp = nr[i];
				nr[i]= nr[i+1];
			    nr[i+1]= temp; 
		    
		       System.out.print(nr[i]);} }
		          }
		        }
	


