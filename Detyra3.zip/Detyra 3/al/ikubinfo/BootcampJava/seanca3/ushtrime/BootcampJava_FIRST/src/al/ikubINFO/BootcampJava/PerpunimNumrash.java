package al.ikubINFO.BootcampJava;

public class PerpunimNumrash {
	
		static int i;
		static int sh = 0;
		static int sh1 = 0;
		static int shm = 0; 

		@SuppressWarnings("static-access")
		public static void main(String[] args) {
				// TODO Auto-generated method stub
		PerpunimNumrash pn = new PerpunimNumrash();
		pn.shumaCift();
		pn.shumaTek();
		pn.shumaT();
		}

		public static int shumaCift(){

		for(i=36 ; i < 100 ; i++)
		{ int mbetja = i%2;
		if(mbetja == 0) {
		sh= sh + i;
		System.out.println("Shuma e numrave cift eshte :" + " "+ sh+ "");}
		}
		System.out.println("                 ");
		return sh;
		}

		public static int shumaTek() {
			for(i=36 ; i < 100 ; i++)
			{ int mbetja = i%2;

			if(mbetja!=0) { sh1 = sh1+i;
		System.out.println("Shuma e numrave tek eshte :" + " "+ sh1+ "");}}
		System.out.println("                     ");
			return sh1;
		}
		public static int shumaT() {
			for(i=36 ; i < 100 ; i++) {
			shm= shm + i;
		System.out.println("Shuma Totale e numrave tek dhe cift eshte : "+ " "+ shm);
			}
		return shm;}}

