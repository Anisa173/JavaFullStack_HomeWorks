package al.ikubINFO.BootcampJava;
import java.util.Scanner;
public class InverseString {
private static Scanner input;
static char t;
public static void main(String[] args) {
input = new Scanner(System.in);
System.out.println("Vendosni numrin e karaktereve te stringut :");
int n = input.nextInt();
char v[] = new char[n];char v1[]= new char[n];char m[]= new char[n];
System.out.println("Futni karakteret e stringut ne konsole");
for(int i =0;i<n;i++) {
v[i] = input.next().charAt(i);
}
System.out.println("Stringu yne eshte :");
for(int i =0;i<n;i++) {
v1[i]= v[i];	
System.out.print(v1[i]);
if(v1[i]==v1[n-i-1]) {System.out.println("Stringu yne eshte palindrome");}
else {System.out.println("Stringu yne nuk eshte palindrome");}}
System.out.println("                          ");
System.out.println("Stringu i invertuar eshte :" + '\n');
for(int j=n-1;j<n;--j ) {
for(int i = 0;i<j;j++) {
 t = v1[i];
v1[i]= v1[i+1];
v1[i+1] = t;
for( i =0;i<n;i++) {
m[i] = v1[i];
System.out.print(m[i]);}}}
}}
