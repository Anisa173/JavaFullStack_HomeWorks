package al.ikubINFO.BootcampJava;
import java.util.Scanner;
public class AfishoYjeKatror1 {
private static Scanner input;
	public static void main(String[] args) {
input = new Scanner(System.in);

System.out.println("Vendosni numrin e elemnteve");
int n = input.nextInt();
for(int i=0;i<n;i++) {
for(int j=0; j<n ;j++) {

System.out.print("*");
}System.out.println("*"); }


}}
