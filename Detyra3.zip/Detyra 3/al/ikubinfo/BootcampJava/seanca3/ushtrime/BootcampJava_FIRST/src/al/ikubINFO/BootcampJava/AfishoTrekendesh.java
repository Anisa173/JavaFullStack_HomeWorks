package al.ikubINFO.BootcampJava;
	public class AfishoTrekendesh {
	private static int n = 5;
		@SuppressWarnings("static-access")
		public static void main(String[] args) {
AfishoTrekendesh trek = new AfishoTrekendesh();
System.out.println("Afisho trekendeshin");
System.out.println("                       ");
trek.afisho();}
public static void afisho() {
int i,j;
	for( i=0;i <= n-1;i++) {
	for( j=n-2*i;j< n;j++) {
	System.out.print("*");}
System.out.println("*");
System.out.println("                                         ");
	}}}
