package al.ikubINFO.BootcampJava;
import java.lang.Math;
public class InversepaScanner {
	

	static int no,nr_inverse ;
	static int i, j;
	public static void main(String[] args) {
	InversepaScanner input = new InversepaScanner();	
	input.afishoInverse();
	}

	public int afishoInverse() {
	int nr1 = 5, nr2 = 4, nr3 = 6 , nr4 = 2, nr5 = 8 ;
	System.out.println("Numri qe ne lexojme eshte 5-shifror");
	no = (int) (nr1*Math.pow(10,0) + nr2*Math.pow(10,1) + nr3*Math.pow(10,2) + nr4*Math.pow(10,3) + nr5*Math.pow(10, 4));
	System.out.println(no);
	nr_inverse = (int)(nr1*Math.pow(10, 4) + nr2*Math.pow(10, 3) + nr3*Math.pow(10, 2) + nr4*Math.pow(10,1) + nr5 * Math.pow(10,0)); 
	System.out.println("Numri i invertuar eshte :" + " " + '\n' + nr_inverse);
	return nr_inverse;  }}
	