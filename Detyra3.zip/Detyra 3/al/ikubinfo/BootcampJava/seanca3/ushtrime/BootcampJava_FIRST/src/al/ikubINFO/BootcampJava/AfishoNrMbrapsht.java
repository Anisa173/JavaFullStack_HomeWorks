package al.ikubINFO.BootcampJava;
	import java.util.Scanner;
	import java.lang.Math;
	public class AfishoNrMbrapsht {
	static int n1,n2,n3,n4,n5,n6,n7;
	static double no,r1,r2,r3,r4,r5,r6;
    private static Scanner input;
	public static void main(String [] args) {
    
		input = new Scanner(System.in);   
        System.out.println("Vendosni numrat njeshifror :");
        n1 = input.nextInt();
        n2 = input.nextInt();
        n3 = input.nextInt();
        n4 = input.nextInt();
        n5 = input.nextInt();
        n6 = input.nextInt();
        n7 = input.nextInt();
        r1=afishoInDyshifror();
r2 = afishoInTrishifror();
r3 = afishoInKatershifror();
r4 = afishoInPeseshifror();	
r5 = afishoInGjashteshifror();
r6 =afishoInShtateshifror();
	}
    public static double afishoInDyshifror(){
double in =1;
        if(no<=99){ no = n2*Math.pow(10,1) + n1*Math.pow(10,0);
            System.out.println("Numri Dyshifror eshte :");
            System.out.println(no);
            in = n1*Math.pow(10,1) + n2*Math.pow(10,0);
            System.out.println('\n'+"Inversi i numrit Dyshifror:");System.out.println(in);}
        return in;}
    public static double afishoInTrishifror(){
double inverse =1;
        if((no>99)&&(no<=999))

        {no = n5*Math.pow(10,2) + n4*Math.pow(10,1) + n3*Math.pow(10,0);
            System.out.println("Numri Treshifror eshte :");
            System.out.println(no);
            inverse = n3*Math.pow(10,2) + n4*Math.pow(10,1) + n5*Math.pow(10,0);
            System.out.println('\n'+"Inversi i numrit Treshifror eshte:");
            System.out.println(inverse);}
        return inverse;}

    public static double afishoInKatershifror(){
    	double inverse1 =1;
    	        if((no>999)&&(no<=10000))

    	        {no = n5*Math.pow(10,3) + n4*Math.pow(10,2) + n3*Math.pow(10,1) + n2*Math.pow(10,0);
    	            System.out.println("Numri Katershifror eshte :");
    	            System.out.println(no);
    	            inverse1 = n2*Math.pow(10,3) + n3*Math.pow(10,2) + n4*Math.pow(10,1) + n5*Math.pow(10,0);
    	            System.out.println('\n'+"Inversi i numrit Katershifror eshte:");
    	            System.out.println(inverse1);}
    	        return inverse1;}	
    public static double afishoInPeseshifror(){
    	double inverse2 =1;
    	        if((no>10000)&&(no<=100000))

    	        {no = n5*Math.pow(10,4) + n4*Math.pow(10,3) + n3*Math.pow(10,2) + n2*Math.pow(10,1) + n1*Math.pow(10,0);
    	            System.out.println("Numri Peseshifror eshte :");
    	            System.out.println(no);
    	            inverse2 = n1*Math.pow(10,4) + n2*Math.pow(10,3) + n3*Math.pow(10,2) + n4*Math.pow(10,1)+ n5*Math.pow(10,0);
    	            System.out.println('\n'+"Inversi i numrit Peseshifror eshte:");
    	            System.out.println(inverse2);}
    	        return inverse2;}
    public static double afishoInGjashteshifror(){
    	double inverse3 =1;
    	        if((no>100000)&&(no<=1000000))

    	        {no = n1*Math.pow(10,5) + n2*Math.pow(10,4) + n3*Math.pow(10,3) + n4*Math.pow(10,2) + n5*Math.pow(10,1) + n6*Math.pow(10,0);
    	            System.out.println("Numri Gjashteshifror eshte :");
    	            System.out.println(no);
    	            inverse3 = n6*Math.pow(10,5) + n5*Math.pow(10,4) + n4*Math.pow(10,3) + n3*Math.pow(10,2)+ n2*Math.pow(10,1)+ n1;
    	            System.out.println('\n'+"Inversi i numrit Gjashteshifror eshte:");
    	            System.out.println(inverse3);}
    	        return inverse3;}
    public static double afishoInShtateshifror(){
    	double inverse4 =1;
    	        if((no>1000000)&&(no<=10000000))

    	        {no = n1*Math.pow(10,6) + n2*Math.pow(10,5) + n3*Math.pow(10,4) + n4*Math.pow(10,3) + n5*Math.pow(10,2) + n6*Math.pow(10,1) + n7;
    	            System.out.println("Numri Shtateshifror eshte :");
    	            System.out.println(no);
    	            inverse4 = n7*Math.pow(10,6) + n6*Math.pow(10,5) + n5*Math.pow(10,4) + n4*Math.pow(10,3)+ n3*Math.pow(10,2)+ n2*Math.pow(10,1) + n1;
    	            System.out.println('\n'+"Inversi i numrit Shtateshifror eshte:");
    	            System.out.println(inverse4);}
    	        return inverse4;}
    
	}
