package al.ikubINFO.BootcampJava;
import java.util.Scanner;
public class Ushtrimi9 {
static double nr1,nr2 , shuma ;
static boolean vazhdon = true;
static boolean nukVazhdon = false;
static boolean vlera,pohimi;
private static Scanner in;
public static void main(String[] args) {
in = new Scanner(System.in);
pohimi = in.nextBoolean();
//Njeri prej numrave duhet te jete pa shifra pas presjes dhjetore

System.out.println("Vendosni inputin ne konsole");
nr1 = in.nextDouble();
nr2 = in.nextDouble();
shuma = llogaritje();
System.out.println(shuma);
vlera = konfirmoInput();
System.out.println(vlera);
}

public static double llogaritje() {
double n1,n2,sh;
n1 = nr1;n2 = nr2;
sh = n1 + n2;
System.out.println("Rezultati nga inputet e marrura si : " + " "+ n1+ " "+ "dhe" + " " +n2+ " " + "eshte :");
return sh;
}
public static boolean konfirmoInput() {
double x,y,sh1;
x=nr1;
y=nr2;
sh1=x+y;
System.out.println("Ju lutem konfirmoni nese do te vazhdoni me futjen e inputeve tuaja apo jo");
boolean p = pohimi;
if(p==vazhdon) {System.out.println("Rezultati nga inputet e marrura si : " + " "+ x+ " "+ "dhe" + " " +y+ " " + "eshte :" + sh1 + " .");}
else if(p==nukVazhdon)
	 {System.out.println("Falemnderit për inputet tuaja!");}
return p;
	
}}
