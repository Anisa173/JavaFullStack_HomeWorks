package ushtrimi1.generics;

import java.util.*;

class Studenti {
	private String Nid;
	private String emer;
	private String mbiemri;
	private String degeStudimi;
	private String vitiStudimit;

	Studenti(String nId, String emri, String mbiemri, String degeStudimi, String vitiStudimit) {
		this.Nid = nId;
		this.emer = emri;
		this.mbiemri = mbiemri;
		this.degeStudimi = degeStudimi;
		this.vitiStudimit = vitiStudimit;
	}

	public String toString() {
		return Nid + " | " + emer + " | " + mbiemri + " | " + degeStudimi + " | " + vitiStudimit;
	}
}

class Libri {
	private String autori;
	private String titulli;
	private String lloji;
	private String Isbn;
	private String VitiBotimit;

	Libri(String a, String t, String ll, String I, String Viti) {
		this.autori = a;
		this.titulli = t;
		this.lloji = ll;
		this.Isbn = I;
		this.VitiBotimit = Viti;
	}

	public String toString() {
		return Isbn + " | " + autori + " | " + titulli + " | " + lloji + " | " + VitiBotimit;
	}
}

class GenericTest {

	public static void main(String[] args) {
		System.out.println('\n'+"Studentat qe lexojne librat e meposhtem:" + '\n');
		LinkedList<Studenti> st = new LinkedList<Studenti>();
		st.add(new Studenti(" "+"J25346189H", "Altin", "Kavaja", "Finance", "2022-2023"));
		st.add(new Studenti(" "+"J35689722H", "Anisa", "Rama", "Informatik", "2020-2021"));
		for (Studenti element : st) {
			System.out.println(element + "\n");
		}
		System.out.println();
		System.out.println("Libri qe unë preferoj" + '\n');
		HashSet<Libri> lib = new HashSet<Libri>();
		lib.add(new Libri("9789928455581", "Franz Kafka", "Letra e Milenës", "Roman/Autobiography", "2021"));
		lib.add(new Libri("9789928354983", "Zija Çela", "Banka e ankesave", "Roman/Utopik&Distopik", "2022"));
		lib.add(new Libri("9789928265494", " Morgan Housel", "Psikologjia e Parasë", "Roman/Psichological", "2022"));
		lib.add(new Libri("9789994306565", " Lea Ypi ", "Të Lirë", "Roman/Saga&History", "2021"));
		lib.add(new Libri("9789995621094", " Joan Vys ", "Familja Robinson", "Roman/Realism", "2008"));
		lib.add(new Libri("9789928341303", " Matt Haig ", "Biblioteka e Mesnatës", "Roman/Mister&Thriller", "2021"));

		for (Libri element : lib) {
			System.out.println(element + "\n");
		}

	}
}
