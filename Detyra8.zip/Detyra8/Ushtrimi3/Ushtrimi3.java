package generics;

public class Ushtrimi3 {

	public static void main(String[] args) {
		Integer[] inums = { 2, 4 };
		Generic1<Integer> iob = new Generic1<Integer>(inums);
		double v = iob.shuma();
		System.out.println('\n'+"Shuma e dy elementeve 'Integer' eshte :" + v+'\n');
		Double[] dnums = { 3.5, 6.5 };
		Generic1<Double> dob = new Generic1<Double>(dnums);
		double d = dob.shuma();
		System.out.println("Shuma e dy elementeve 'Double' eshte :" + d);
	}

}
