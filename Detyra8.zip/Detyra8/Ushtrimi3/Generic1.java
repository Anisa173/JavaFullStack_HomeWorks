package generics;

public class Generic1<T extends Number> {
	T[] nums;

	public Generic1(T[] num) {
		this.nums = num;
	}

	public double shuma() {
		double sum = 0.0;
		for (int i = 0; i < nums.length; i++) {
			sum = sum + nums[i].doubleValue();
		}
		return sum;
	}
}
