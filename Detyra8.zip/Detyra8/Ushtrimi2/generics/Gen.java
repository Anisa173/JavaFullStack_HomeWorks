package generics;

public class Gen<T> {
	T obj;

	public Gen(T o) {
		this.obj = o;

	}

	T getObj() {
		return obj;
	}

	void showType() {
		System.out.println("Type of T is : " + obj.getClass().getName());
	}
}