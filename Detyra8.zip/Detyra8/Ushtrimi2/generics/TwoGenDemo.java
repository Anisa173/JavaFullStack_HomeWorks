package generics;

public class TwoGenDemo {

	public static void main(String[] args) {
		TwoGen<Integer, String> tgObj = new TwoGen<Integer, String>(88, "Generics");
		tgObj.showType();
		int v = tgObj.getOb1();
		System.out.println("Value is :" + " " + v);
		String st = tgObj.getOb2();
		System.out.println("Value is :" + " " + st);
	}

}
