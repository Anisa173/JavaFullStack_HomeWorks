insert into userpost.posts(title , postStatus , user_id)
Values('Post1','Body of Post 1',4);
insert into userpost.posts(title , postStatus , user_id)
Values('Post2','Body of Post 2',1);
insert into userpost.posts(title , postStatus , user_id)
Values('Post3','Body of Post 3',3);
insert into userpost.posts(title , postStatus , user_id)
Values('Post4','Body of Post 4',5);
insert into userpost.posts(title , postStatus , user_id)
Values('Post5','Body of Post 5',2);
insert into userpost.posts(title , postStatus , user_id)
Values('Post6','Body of Post 6',2);
insert into userpost.posts(title , postStatus , user_id)
Values('Post7','Body of Post 7',3);
insert into userpost.posts(title , postStatus , user_id)
Values('Post8','Body of Post 8',6);
insert into userpost.posts(title , postStatus , user_id)
Values('Post9','Body of Post 9',9);
insert into userpost.posts(title , postStatus , user_id)
Values('Post10','Body of Post 10',8);
insert into userpost.posts(title , postStatus , user_id)
Values('Post11','Body of Post 11',10);
insert into userpost.posts(title , postStatus , user_id)
Values('Post12','Body of Post 12',12);
insert into userpost.posts(title , postStatus , user_id)
Values('Post13','Body of Post 13',7);
insert into userpost.posts(title , postStatus , user_id)
Values('Post14','Body of Post 14',11);
insert into userpost.posts(title , postStatus , user_id)
Values('Post15','Body of Post 15',14);
insert into userpost.posts(title , postStatus , user_id)
Values('Post16','Body of Post 16',13);
insert into userpost.posts(title , postStatus , user_id)
Values('Post17','Body of Post 17',2);
insert into userpost.posts(title , postStatus , user_id)
Values('Post18','Body of Post 18',3);
insert into userpost.posts(title , postStatus , user_id)
Values('Post19','Body of Post 19',10);
insert into userpost.posts(title , postStatus , user_id)
Values('Post20','Body of Post 20',14);
insert into userpost.posts(title , postStatus , user_id)
Values('Post21','Body of Post 21',9);
insert into userpost.posts(title , postStatus , user_id)
Values('Post22','Body of Post 22',7);
insert into userpost.posts(title , postStatus , user_id)
Values('Post23','Body of Post 23',4);
insert into userpost.posts(title , postStatus , user_id)
Values('Post24','Body of Post 24',5);










