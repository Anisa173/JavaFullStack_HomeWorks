create database postCategories;
use postCategories;