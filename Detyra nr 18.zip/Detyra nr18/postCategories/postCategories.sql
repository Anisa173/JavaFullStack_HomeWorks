CREATE TABLE postCategories (
    id INTEGER AUTO_INCREMENT ,
    categoriesId INTEGER NOT NULL,
    postId INTEGER NOT NULL,
    date_created DATETIME DEFAULT CURRENT_TIMESTAMP,
    date_modified DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    FOREIGN KEY (categoriesId)
        REFERENCES categories (id),
    FOREIGN KEY (postId)
        REFERENCES posts (id)
	ON DELETE SET NULL ON UPDATE CASCADE
)
