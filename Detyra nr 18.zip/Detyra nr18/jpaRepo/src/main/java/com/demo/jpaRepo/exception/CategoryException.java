package com.demo.jpaRepo.exception;

public class CategoryException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2998084552700918728L;

	public CategoryException(String message) {
	super(message);
	}

}
