package com.demo.jpaRepo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpaRepoApplication {

	public static void main(String[] args) {
		SpringApplication.run(JpaRepoApplication.class, args);
	}

}
