package com.demo.jpaRepo.service;

import java.util.List;

import com.demo.jpaRepo.entity.Categories;
import com.demo.jpaRepo.entity.Posts;
import com.demo.jpaRepo.entity.PostsCategories;
import com.demo.jpaRepo.repository.PostsRepository;

public interface BlogService {

	List<PostsRepository> getPostsCategories() throws Exception;

	List<PostsCategories> getPostsCategoryById(Integer categoryId) throws Exception;

	Categories addCategory(Categories categories) throws Exception;

	void deleteCategory(Integer categId) throws Exception;

	List<Posts> getPosts() throws Exception;

	List<Posts> getPostsByCategory(Integer categoryId) throws Exception;

	void deletePost(Integer id) throws Exception;

}
