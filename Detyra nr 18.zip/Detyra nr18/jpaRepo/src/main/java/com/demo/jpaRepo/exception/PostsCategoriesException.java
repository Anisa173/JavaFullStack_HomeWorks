package com.demo.jpaRepo.exception;

public class PostsCategoriesException  extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = -2945483507504240072L;

	public PostsCategoriesException(String mesg) {
		super(mesg);
	}

}
