package com.demo.jpaRepo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.demo.jpaRepo.entity.Posts;

public interface PostsRepository extends JpaRepository<Posts, Integer>{

	List<Posts> findAllByUser_id(Integer user_id);

	Posts findPostsOfUsersById(Integer user_id, Integer id);

	void deletePostUsersById(Integer userId, Integer postId);

	List<Posts> findAllById(Integer categoryId);

}
