package com.demo.jpaRepo.controller.advice;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.demo.jpaRepo.exception.GenericExceptionResponse;
import com.demo.jpaRepo.exception.UsersException;
import com.demo.jpaRepo.exception.UsersPostException;

import jakarta.servlet.http.HttpServletRequest;

@ControllerAdvice
public class UserExceptionHandler {

	@ExceptionHandler
	public ResponseEntity<GenericExceptionResponse> handlerUserNotFoundException(UsersException usersException,
			HttpServletRequest request) {
		var resp_request = new GenericExceptionResponse(HttpStatus.NOT_FOUND.value(), request.getRequestURI(),
				usersException.getMessage());

		return new ResponseEntity<GenericExceptionResponse>(resp_request, HttpStatus.BAD_REQUEST);

	}

	@ExceptionHandler
	public ResponseEntity<GenericExceptionResponse> handlerUsersPostNotFoundException(UsersPostException usersPost,
			HttpServletRequest servletRequest) {
		var response = new GenericExceptionResponse(HttpStatus.NOT_FOUND.value(), servletRequest.getRequestURI(),
				usersPost.getMessage());

		return new ResponseEntity<GenericExceptionResponse>(response, HttpStatus.NOT_FOUND);
	}

}
