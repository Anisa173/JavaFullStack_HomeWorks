package com.demo.jpaRepo.exception;

public class UsersException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = -6188948602343893281L;

	public UsersException(String message) {
		super(message);
	}

}
