package com.demo.jpaRepo.entity;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "Posts")
public class Posts extends BaseEntity<Integer> {
	@OneToMany(mappedBy = "PostsCategoriesDto", cascade = CascadeType.ALL)
	private List<PostsCategories> pcategories = new ArrayList<PostsCategories>();
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "user_id", referencedColumnName = "id")
	private Users user_post;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	@Column(name = "title")
	private String title;
	@Column(name = "postStatus")
	private String postStatus;
	@Column(name = "date_created")
	private LocalDateTime date_created;
	@Column(name = "date_modified")
	private LocalDateTime date_modified;

	public Posts() {
		super();
	}

	public Posts(String title, String postStatus, LocalDateTime date_created, LocalDateTime date_modified,
			Users user_post, List<PostsCategories> pcategories) {
		super();

		this.setTitle(title);
		this.setPostStatus(postStatus);
		this.setDate_created(date_created);
		this.setDate_modified(date_modified);
		this.user_post = user_post;
		this.pcategories = pcategories;
	}

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getPostStatus() {
		return postStatus;
	}

	public void setPostStatus(String postStatus) {
		this.postStatus = postStatus;
	}

	public LocalDateTime getDate_created() {
		return date_created;
	}

	public void setDate_created(LocalDateTime date_created) {
		this.date_created = date_created;
	}

	public LocalDateTime getDate_modified() {
		return date_modified;
	}

	public void setDate_modified(LocalDateTime date_modified) {
		this.date_modified = date_modified;
	}

	public void setUser_post(Users user_post) {
		this.user_post = user_post;
	}

	public Users getUser_post() {
		return user_post;
	}

	public void setCategories(List<PostsCategories> pcategories) {
		this.pcategories = pcategories;
	}

	public List<PostsCategories> getPcategories() {
		return pcategories;
	}

	public String toString() {
		return "Posts[id = " + id + ",title = " + title + ",postStatus = " + postStatus + ",date_created = "
				+ date_created + ",date_modified =" + date_modified + ",user_post =" + user_post + ",pcategories ="
				+ pcategories + "]";
	}

	

}
