package com.demo.jpaRepo.controller.advice;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.demo.jpaRepo.exception.CategoryException;
import com.demo.jpaRepo.exception.GenericExceptionResponse;
import com.demo.jpaRepo.exception.PostException;
import com.demo.jpaRepo.exception.PostsCategoriesException;

import jakarta.servlet.http.HttpServletRequest;

@ControllerAdvice
public class BlogExceptionHandler {

	@ExceptionHandler
	public ResponseEntity<GenericExceptionResponse> handlerPostsNotFoundException(PostException exceptionPost,
			HttpServletRequest request) {

		var response = new GenericExceptionResponse(HttpStatus.NOT_FOUND.value(), request.getRequestURI(),
				exceptionPost.getMessage());

		return new ResponseEntity<GenericExceptionResponse>(response, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler
	public ResponseEntity<GenericExceptionResponse> handlerPostCategoriesNotFoundException(
			HttpServletRequest servletRequest, PostsCategoriesException postsCategoriesException) {

		var res_request = new GenericExceptionResponse(HttpStatus.NOT_FOUND.value(),
				postsCategoriesException.getMessage(), servletRequest.getRequestURI());

		return new ResponseEntity<GenericExceptionResponse>(res_request, HttpStatus.NOT_FOUND);

	}

	@ExceptionHandler
	public ResponseEntity<GenericExceptionResponse> handlerCategoryNotFoundException(CategoryException exception,
			HttpServletRequest req) {
		var response = new GenericExceptionResponse(HttpStatus.NOT_FOUND.value(), req.getRequestURI(),
				exception.getMessage());

		return new ResponseEntity<GenericExceptionResponse>(response, HttpStatus.NOT_FOUND);
	}

}
