package com.demo.jpaRepo.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demo.jpaRepo.entity.Posts;
import com.demo.jpaRepo.entity.Users;
import com.demo.jpaRepo.service.UserService;

@RestController
@RequestMapping("Users")
public class UserController {

	private final UserService userService;

	public UserController(UserService userService) {
		super();
		this.userService = userService;
	}

	@GetMapping
	public ResponseEntity<List<Users>> getUsers() throws Exception {
		return ResponseEntity.ok(userService.getUsers());
	}

	@PostMapping
	public ResponseEntity<Users> addUsers(@RequestBody Users users) throws Exception {
		return ResponseEntity.ok(userService.addUsers(users));
	}

	@PutMapping("/{id}")
	public ResponseEntity<Users> updateUsers(@RequestBody Users users, @PathVariable Integer id) throws Exception {
		return ResponseEntity.ok(userService.updateUsers(users, id));
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deleteUserById(Integer id) throws Exception {
		userService.deleteUserById(id);
		return new ResponseEntity<Void>(HttpStatus.OK);
	}

	@GetMapping("/{id}")
	public ResponseEntity<List<Posts>> getUsersPosts(Integer userId) throws Exception {
		return ResponseEntity.ok(userService.getUsersPosts(userId));
	}

	@GetMapping("/{id}")
	public ResponseEntity<Posts> getUserPostsById(@PathVariable Integer user_id, @PathVariable Integer id)
			throws Exception {
		return ResponseEntity.ok(userService.getUserPostsById(user_id, id));
	}

	@PostMapping("/{id}")
	public ResponseEntity<Posts> addUserPost(@PathVariable Integer user_id, @RequestBody Posts post) throws Exception {
		return ResponseEntity.ok(userService.addUserPost(user_id, post));
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deleteUsersPost(@PathVariable Integer user_id, @PathVariable Integer id)
			throws Exception {
		userService.deleteUsersPost(user_id, id);
		return new ResponseEntity<Void>(HttpStatus.OK);

	}

}
