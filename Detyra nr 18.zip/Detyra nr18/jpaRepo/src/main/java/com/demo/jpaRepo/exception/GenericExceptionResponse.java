package com.demo.jpaRepo.exception;

import java.time.LocalDateTime;

public class GenericExceptionResponse {

	private LocalDateTime time = LocalDateTime.now();
	private Integer statusCode;
	private String message;
	private String path;

	public GenericExceptionResponse() {
		super();
	}

	public GenericExceptionResponse(Integer statusCode, String message, String path) {
		super();
		this.setStatusCode(statusCode);
		this.setMessage(message);
		this.setPath(path);
	}

	public LocalDateTime getTime() {
		return time;
	}

	public void setTime(LocalDateTime time) {
		this.time = time;
	}

	public Integer getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(Integer statusCode) {
		this.statusCode = statusCode;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String toString() {
		return "GenericExceptionResponse[time =" + time + ",statusCode =" + statusCode + ",message =" + message
				+ ",path =" + path + " ]";
	}
}
