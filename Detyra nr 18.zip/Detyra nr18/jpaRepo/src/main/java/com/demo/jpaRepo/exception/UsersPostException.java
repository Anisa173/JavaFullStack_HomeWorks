package com.demo.jpaRepo.exception;

public class UsersPostException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = -4347927674295877498L;

	public UsersPostException(String message) {
	super(message);
	}

}
