package com.demo.jpaRepo.service;

import java.util.List;

import com.demo.jpaRepo.entity.Posts;
import com.demo.jpaRepo.entity.Users;

public interface UserService {

	List<Users> getUsers() throws Exception;

	Users getUserById(Integer id) throws Exception;

	Users addUsers(Users users) throws Exception;

	Users updateUsers(Users users, Integer id) throws Exception;

	void deleteUserById(Integer id) throws Exception;

	List<Posts> getUsersPosts(Integer userId) throws Exception;

	Posts getUserPostsById(Integer userId,Integer postId) throws Exception;

	Posts addUserPost(Integer userId,Posts post) throws Exception;

	void deleteUsersPost(Integer userId, Integer postId) throws Exception;
}