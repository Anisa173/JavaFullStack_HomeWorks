package com.demo.jpaRepo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.demo.jpaRepo.entity.Categories;

public interface CategoriesRepository extends JpaRepository<Categories, Integer>{

}
