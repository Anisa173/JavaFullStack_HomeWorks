package com.demo.jpaRepo.service.Impl;

import java.util.List;

import com.demo.jpaRepo.entity.Posts;
import com.demo.jpaRepo.entity.Users;
import com.demo.jpaRepo.repository.PostsRepository;
import com.demo.jpaRepo.repository.UsersRepository;
import com.demo.jpaRepo.service.UserService;

public class UsersServiceImpl implements UserService {
	private final UsersRepository usersRepository;
	private final PostsRepository postsRepository;

	public UsersServiceImpl(UsersRepository usersRepository, PostsRepository postsRepository) {
		super();
		this.usersRepository = usersRepository;
		this.postsRepository = postsRepository;
	}

	@Override
	public List<Users> getUsers() throws Exception {

		return usersRepository.findAll();
	}

	@Override
	public Users getUserById(Integer id) throws Exception {

		return usersRepository.findById(id).orElse(null);
	}

	@Override
	public Users addUsers(Users users) throws Exception {

		return usersRepository.save(users);
	}

	@Override
	public Users updateUsers(Users users, Integer id) throws Exception {
		Users users2 = getUserById(id);
		users2.setEmail(users.getEmail());
		users2.setUsername(users.getUsername());
		users2.setPassword(users.getPassword());
		return usersRepository.save(users);
	}

	@Override
	public void deleteUserById(Integer id) throws Exception {

		usersRepository.deleteById(id);
	}

	@Override
	public List<Posts> getUsersPosts(Integer user_id) throws Exception {

		return postsRepository.findAllByUser_id(user_id);
	}

	@Override
	public Posts getUserPostsById(Integer user_id, Integer id) throws Exception {

		return postsRepository.findPostsOfUsersById(user_id,id);
	}

	@Override
	public Posts addUserPost(Integer userId, Posts post) throws Exception {

		return postsRepository.save(post);
	}

	@Override
	public void deleteUsersPost(Integer userId, Integer postId) throws Exception {
 postsRepository.deletePostUsersById(userId,postId);
	}

}
