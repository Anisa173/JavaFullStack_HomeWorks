package com.demo.jpaRepo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.demo.jpaRepo.entity.PostsCategories;

public interface PostsCategoriesRepository extends JpaRepository<PostsRepository, Integer>{

	List<PostsCategories> findAllById();

}
