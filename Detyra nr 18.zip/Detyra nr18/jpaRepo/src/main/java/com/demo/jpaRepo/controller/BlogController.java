package com.demo.jpaRepo.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demo.jpaRepo.entity.Categories;
import com.demo.jpaRepo.entity.Posts;
import com.demo.jpaRepo.entity.PostsCategories;
import com.demo.jpaRepo.repository.PostsRepository;
import com.demo.jpaRepo.service.BlogService;

@RestController
@RequestMapping("PostsCategories")
public class BlogController {

	private final BlogService blogService;

	public BlogController(BlogService blogService) {
		super();
		this.blogService = blogService;
	}

	@GetMapping
	public ResponseEntity<List<PostsRepository>> getPostsCategories() throws Exception {
		return ResponseEntity.ok(blogService.getPostsCategories());
	}

	@GetMapping("/{id}")
	public ResponseEntity<List<PostsCategories>> getPostsCategoryById(@PathVariable Integer categoryId)
			throws Exception {
		return ResponseEntity.ok(blogService.getPostsCategoryById(categoryId));
	}

	@PostMapping
	public ResponseEntity<Categories> addCategory(@RequestBody Categories categories) throws Exception {
		return ResponseEntity.ok(blogService.addCategory(categories));
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deleteCategory(@PathVariable Integer categId) throws Exception {
		blogService.deleteCategory(categId);
		return new ResponseEntity<Void>(HttpStatus.OK);
	}

	@GetMapping
	public ResponseEntity<List<Posts>> getPosts() throws Exception {
		return ResponseEntity.ok(blogService.getPosts());
	}

	@GetMapping("/{id}")
	public ResponseEntity<List<Posts>> getPostsByCategory(@PathVariable Integer cgId) throws Exception {
		return ResponseEntity.ok(blogService.getPostsByCategory(cgId));
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deletePost(@PathVariable Integer id) throws Exception {
		blogService.deletePost(id);
		return new ResponseEntity<Void>(HttpStatus.OK);
	}
}