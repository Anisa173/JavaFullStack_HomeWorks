package com.demo.jpaRepo.service.Impl;

import java.util.List;

import com.demo.jpaRepo.entity.Categories;
import com.demo.jpaRepo.entity.Posts;
import com.demo.jpaRepo.entity.PostsCategories;
import com.demo.jpaRepo.repository.CategoriesRepository;
import com.demo.jpaRepo.repository.PostsCategoriesRepository;
import com.demo.jpaRepo.repository.PostsRepository;
import com.demo.jpaRepo.service.BlogService;

public class BlogServiceImpl implements BlogService {
	private final CategoriesRepository categoriesRepository;
	private final PostsRepository postsRepository;
	private final PostsCategoriesRepository postsCategoriesRepository;

	public BlogServiceImpl(CategoriesRepository categoriesRepository, PostsRepository postsRepository,
			PostsCategoriesRepository postsCategoriesRepository) {
		super();
		this.categoriesRepository = categoriesRepository;
		this.postsRepository = postsRepository;
		this.postsCategoriesRepository = postsCategoriesRepository;
	}

	@Override
	public List<PostsRepository> getPostsCategories() throws Exception {

		return (List<PostsRepository>) postsCategoriesRepository.findAll();
	}

	@Override
	public List<PostsCategories> getPostsCategoryById(Integer categoryId) throws Exception {

		return postsCategoriesRepository.findAllById();
	}

	@Override
	public Categories addCategory(Categories categories) throws Exception {

		return categoriesRepository.save(categories);
	}

	@Override
	public void deleteCategory(Integer categId) throws Exception {
		categoriesRepository.deleteById(categId);
	}

	@Override
	public List<Posts> getPosts() throws Exception {

		return postsRepository.findAll();
	}

	@Override
	public List<Posts> getPostsByCategory(Integer categoryId) throws Exception {

		return postsRepository.findAllById(categoryId);
	}

	@Override
	public void deletePost(Integer id) throws Exception {

		postsRepository.deleteById(id);
	}

}
