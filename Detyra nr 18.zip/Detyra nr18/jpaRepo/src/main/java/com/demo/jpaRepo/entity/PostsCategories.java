package com.demo.jpaRepo.entity;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "PostsCategoriesDto")
public class PostsCategories extends BaseEntity<Integer> {
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "categoryId", referencedColumnName = "id")
	private List<Categories> category = new ArrayList<Categories>();
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "postId", referencedColumnName = "id")
	private List<Posts> posts = new ArrayList<Posts>();

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@Column(name = "date_created")
	private LocalDateTime date_created;
	@Column(name = "date_modified")
	private LocalDateTime date_modified;

	public PostsCategories() {
		super();
	}

	public PostsCategories(List<Categories> category, List<Posts> posts, LocalDateTime date_created,
			LocalDateTime date_modified) {
		super();
		this.category = category;
		this.posts = posts;
		this.setDate_created(date_created);
		this.setDate_modified(date_modified);
	}

	@Override
	public Integer getId() {

		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public List<Posts> getPosts() {
		return posts;
	}

	public void setPosts(List<Posts> posts) {
		this.posts = posts;
	}

	public List<Categories> getCategory() {
		return category;
	}

	public void setCategory(List<Categories> category) {
		this.category = category;
	}

	public LocalDateTime getDate_created() {

		return date_created;
	}

	public void setDate_created(LocalDateTime date_created) {
		this.date_created = date_created;
	}

	public LocalDateTime getDate_modified() {
		return date_modified;
	}

	public void setDate_modified(LocalDateTime date_modified) {
		this.date_modified = date_modified;
	}

	public String toString() {
		return "Postscategories[id = " + id + ",date_created = " + date_created + ",date_modified =" + date_modified
				+ ",category =" + category + ",posts=" + posts + "]";

	}

}
