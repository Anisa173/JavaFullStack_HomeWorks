package com.demo.jpaRepo.entity;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;

public class Categories extends BaseEntity<Integer> {
	@OneToMany(mappedBy = "PostCategories", cascade = CascadeType.ALL)
	private List<PostsCategories> postsCategories = new ArrayList<PostsCategories>();

	@Id
	@Column
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	@Column(name = "name")
	private String name;
	@Column(name = "date_created")
	private LocalDateTime date_created;
	@Column(name = "date_modified")
	private LocalDateTime date_modified;

	public Categories() {
		super();
	}

	public Categories(String name, LocalDateTime date_created, LocalDateTime date_modified,
			List<PostsCategories> postsCategories) {
		super();
		this.setName(name);
		this.setDate_created(date_created);
		this.setDate_modified(date_created);
		this.postsCategories = postsCategories;
	}

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public LocalDateTime getDate_created() {
		return date_created;
	}

	public void setDate_created(LocalDateTime date_created) {
		this.date_created = date_created;
	}

	public LocalDateTime getDate_modified() {
		return date_modified;
	}

	public void setDate_modified(LocalDateTime date_modified) {
		this.date_modified = date_modified;
	}

	public void setPosts(List<PostsCategories> postsCategories) {
		this.postsCategories = postsCategories;
	}

	public List<PostsCategories> getPostsCategories() {
		return postsCategories;
	}

	public String toString() {
		return "Categories[id = " + id + ",name = " + name + ",date_created =" + date_created + ",date_modified ="
				+ date_modified + ",postsCategories =" + postsCategories + "]";
	}

}
