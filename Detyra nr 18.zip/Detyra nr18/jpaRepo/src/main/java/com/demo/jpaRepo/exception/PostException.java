package com.demo.jpaRepo.exception;

public class PostException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7600499972641499210L;

	public PostException(String message) {
		super(message);
	}

}
