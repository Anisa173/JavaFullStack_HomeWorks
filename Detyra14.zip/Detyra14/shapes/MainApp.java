package com.shapes;

import com.shapes.service.Shape2D;
import com.shapes.service.Shape3D;
import com.shapes.service.implementation.Cilinder;
import com.shapes.service.implementation.Drejtkendeshi;
import com.shapes.service.implementation.FormaGjeometrike;
import com.shapes.service.implementation.Katrori;
import com.shapes.service.implementation.Kubi;
import com.shapes.service.implementation.Kuboid;
import com.shapes.service.implementation.Rombi;
import com.shapes.service.implementation.StrukturaGjeometrike;
import com.shapes.service.implementation.Trapezi;
import com.shapes.service.implementation.Trekendeshi;

public class MainApp {
	private static final Shape2D TSHAPE2D = new Trekendeshi();
	private static final Shape2D TPSHAPE2D = new Trapezi();
	private static final Shape2D RSHAPE2D = new Rombi();
	private static final Shape2D KSHAPE2D = new Katrori();
	private static final Shape2D DSHAPE2D = new Drejtkendeshi();
	private static final Shape3D CSHAPE3D = new Cilinder();
	private static final Shape3D KSHAPE3D = new Kubi();
	private static final Shape3D KBSHAPE3D = new Kuboid();

	public static void main(String[] args) {

		FormaGjeometrike formaGjeometrike = new FormaGjeometrike(TSHAPE2D);
		boolean tshape2d = formaGjeometrike.isShapeTypeSupported();
		System.out.print(tshape2d);
		double Stshape2d = formaGjeometrike.calculateArea2D();
		System.out.println(Stshape2d);
		double Ptshape2d = formaGjeometrike.calculatePerimeter2D();
		System.out.println(Ptshape2d);

		formaGjeometrike = new FormaGjeometrike(TPSHAPE2D);
		boolean tpshape2d = formaGjeometrike.isShapeTypeSupported();
		System.out.println(tpshape2d);
		double Stpshape2d = formaGjeometrike.calculateArea2D();
		System.out.println(Stpshape2d);
		double Ptpshape2d = formaGjeometrike.calculatePerimeter2D();
		System.out.println(Ptpshape2d);

		formaGjeometrike = new FormaGjeometrike(RSHAPE2D);
		boolean rshape2d = formaGjeometrike.isShapeTypeSupported();
		System.out.println(rshape2d);
		double Srshape2d = formaGjeometrike.calculateArea2D();
		System.out.println(Srshape2d);
		double Prshape2d = formaGjeometrike.calculatePerimeter2D();
		System.out.println(Prshape2d);

		formaGjeometrike = new FormaGjeometrike(KSHAPE2D);
		boolean kshape2d = formaGjeometrike.isShapeTypeSupported();
		System.out.println(kshape2d);
		double Skshape2d = formaGjeometrike.calculateArea2D();
		System.out.println(Skshape2d);
		double Pkshape2d = formaGjeometrike.calculatePerimeter2D();
		System.out.println(Pkshape2d);

		formaGjeometrike = new FormaGjeometrike(DSHAPE2D);
		boolean dshape2d = formaGjeometrike.isShapeTypeSupported();
		System.out.println(dshape2d);
		double Sdrshape2d = formaGjeometrike.calculateArea2D();
		System.out.println(Sdrshape2d);
		double Pdrshape2d = formaGjeometrike.calculatePerimeter2D();
		System.out.println(Pdrshape2d);

		StrukturaGjeometrike strukturaGjeometrike = new StrukturaGjeometrike(CSHAPE3D);
		boolean cshape3d = strukturaGjeometrike.isShapeTypeSupported();
		System.out.println(cshape3d);
		double Scshape2d = strukturaGjeometrike.calculateArea3D();
		System.out.println(Scshape2d);
		double Vcshape3d = strukturaGjeometrike.calculateVolume3D();
		System.out.println(Vcshape3d);

		strukturaGjeometrike = new StrukturaGjeometrike(KSHAPE3D);
		boolean kshape3d = strukturaGjeometrike.isShapeTypeSupported();
		System.out.println(kshape3d);
		double Skshape3d = strukturaGjeometrike.calculateArea3D();
		System.out.println(Skshape3d);
		double Vkshape3d = strukturaGjeometrike.calculateVolume3D();
		System.out.println(Vkshape3d);

		strukturaGjeometrike = new StrukturaGjeometrike(KBSHAPE3D);
		boolean kbshape3d = strukturaGjeometrike.isShapeTypeSupported();
		System.out.println(kbshape3d);
		double Skbshape3d = strukturaGjeometrike.calculateArea3D();
		System.out.println(Skbshape3d);
		double Vkbshape3d = strukturaGjeometrike.calculateVolume3D();
		System.out.println(Vkbshape3d);

	}

}
