package com.shapes.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.shapes.service.Shape2D;
import com.shapes.service.Shape3D;
import com.shapes.service.implementation.Cilinder;
import com.shapes.service.implementation.Drejtkendeshi;
import com.shapes.service.implementation.Katrori;
import com.shapes.service.implementation.Kubi;
import com.shapes.service.implementation.Kuboid;
import com.shapes.service.implementation.Rombi;
import com.shapes.service.implementation.Trapezi;
import com.shapes.service.implementation.Trekendeshi;

@Configuration
public class ShapesConfiguration {
    @Bean
    Shape2D getShape2D() {
		return new Drejtkendeshi();
	}

    @Bean
    Shape2D getShape2D1() {
		return new Katrori();
	}

    @Bean
    Shape2D getShape2D2() {
		return new Rombi();
	}

    @Bean
    Shape2D getShape2D3() {
		return new Trekendeshi();
	}
    @Bean
    Shape2D getShape2D4() {
		return new Trapezi();
	}
    @Bean
    Shape3D getShape3D() {
		return new Cilinder();
	}
    @Bean
    Shape3D getShape3D1() {
		return new Kubi();
	}
    @Bean
    Shape3D getShape3D2() {
		return new Kuboid();
	}


}
