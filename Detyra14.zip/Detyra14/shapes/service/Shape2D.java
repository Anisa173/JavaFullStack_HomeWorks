package com.shapes.service;
public interface Shape2D extends Shape {
boolean isShapeTypeSupported();

	Double calculateArea2D(Double... doubles);
		

	Double calculatePerimeter2D(Double... doubles) ;
		
	}

