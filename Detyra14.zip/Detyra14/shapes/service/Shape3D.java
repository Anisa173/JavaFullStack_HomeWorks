package com.shapes.service;
public interface Shape3D extends Shape {
@Override
	boolean isShapeTypeSupported();

   Double calculateArea3D(Double...doubles) ;
	
    Double calculateVolume3D(Double...doubles) ;
		
	
}

