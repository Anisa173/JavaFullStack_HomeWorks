package com.shapes.service.implementation;

import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;

import java.util.*;
import com.shapes.service.Shape2D;
@Service
public class Drejtkendeshi implements Shape2D {
	private static Scanner scanner = new Scanner(System.in);
	private static boolean eshte = true;
	private static boolean seshte = false;

	public Double calculateArea2D(Double... doubles) {
		double sip = 0.0;
		System.out.println("Gjatesia e drejtekendeshit eshte :");
		doubles[0] = scanner.nextDouble();
		System.out.println("Gjeresia e drejtkendeshit eshte :");
		doubles[1] = scanner.nextDouble();
		sip = doubles[0] * doubles[1];
		System.out.println("Siperfaqja e drejtkendeshit eshte :"+" "+sip);
		return sip;
	}

	public Double calculatePerimeter2D(Double... doubles) {
		Double p = (double) 0;
		System.out.println("Gjatesia e drejtkendeshit eshte :");
		doubles[0] = scanner.nextDouble();
		System.out.println("Gjeresia e drejtkendeshit eshte :");
		doubles[1] = scanner.nextDouble();
		p = 2 * (doubles[0] * doubles[1]);
		System.out.println("Perimetri i drejtkendeshit eshte :"+" "+p);
		return p;
	}

	@Override
	public boolean isShapeTypeSupported() {
		boolean p = false;
		String shape = scanner.nextLine();
		List<String> sh2D = Arrays.asList("Trekendesh", "Trapez", "Katror", "Drejtkendesh", "Romb");
		for (String sh : sh2D) {
			if (sh.equals(shape)) {
				p = eshte;
				System.out.println("Forma e kerkuar eshte forma gjeometrike -" + p);
			} else {
				p = seshte;
				System.out.println("Forma e kerkuar eshte forma gjeometrike -" + p);

			}
		}
		return p;
	}

}
