package com.shapes.service.implementation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.shapes.service.Shape3D;
@Component
public class StrukturaGjeometrike {
	
@Autowired
	private final Shape3D shape3d;

	public StrukturaGjeometrike(Shape3D shape3d) {
		this.shape3d = shape3d;

	}

	public Shape3D getShape3d() {
		return shape3d;

	}

	public boolean isShapeTypeSupported() {
		
		return shape3d.isShapeTypeSupported();
	}

	public  double calculateArea3D() {
		
		return shape3d.calculateArea3D();
	}

	public double calculateVolume3D() {
	
		return shape3d.calculateVolume3D();
	}
}
