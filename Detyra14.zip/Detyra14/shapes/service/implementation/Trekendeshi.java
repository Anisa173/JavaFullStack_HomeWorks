package com.shapes.service.implementation;

import java.util.*;

import java.util.Scanner;

import org.springframework.stereotype.Service;

import com.shapes.service.Shape2D;

@Service
public class Trekendeshi implements Shape2D {
	private static Scanner scanner = new Scanner(System.in);
	private static boolean eshte = true;
	private static boolean seshte = false;

	@Override
	public boolean isShapeTypeSupported() {
		boolean p = false;
		String shape = scanner.nextLine();
		List<String> sh2D = Arrays.asList("Trekendesh", "Trapez", "Katror", "Drejtkendesh", "Romb");
		for (String sh : sh2D) {
			if (sh.equals(shape)) {
				p = eshte;
				System.out.println("Forma e kerkuar eshte forma gjeometrike -" + p);
			} else {
				p = seshte;
				System.out.println("Forma e kerkuar eshte forma gjeometrike -" + p);

			}
		}
		return p;
	}

	public Double calculateArea2D(Double... doubles) {
		double s = 0;
		System.out.println("Brinja e pare e trekendeshit eshte :");
		doubles[0] = scanner.nextDouble();
		System.out.println("Brinja e dyte e trekendeshit eshte :");
		doubles[1] = scanner.nextDouble();
		System.out.println("Brinja e tretë e trekendeshit eshte :");
		doubles[2] = scanner.nextDouble();
		System.out.println("Lartesia e trekendeshit eshte :");
		doubles[3] = scanner.nextDouble();
		if ((doubles[0] + doubles[1]) > doubles[2]) {
			s = (doubles[2] * doubles[3]) / 2;
			System.out.println("Siperfaqja e trapezit eshte :" + s);
		} else if ((doubles[2] + doubles[1]) > doubles[0]) {
			s = (doubles[0] * doubles[3]) / 2;
			System.out.println("Siperfaqja e trapezit eshte :" + s);
		} else if ((doubles[0] + doubles[2]) > doubles[1]) {
			s = (doubles[1] * doubles[3]) / 2;
			System.out.println("Siperfaqja e trapezit eshte :" + s);

		} else {
			System.out.println("Rivendos te dhenat!");
		}
		return s;

	}

	public Double calculatePerimeter2D(Double... doubles) {
		double p = 0;
		System.out.println("Brinja e pare e trekendeshit eshte :");
		doubles[0] = scanner.nextDouble();
		System.out.println("Brinja e dyte e trekendeshit eshte :");
		doubles[1] = scanner.nextDouble();
		System.out.println("Brinja e tretë e trekendeshit eshte :");
		doubles[2] = scanner.nextDouble();
		if ((doubles[0] + doubles[1]) > doubles[2]) {
			p = (doubles[2] * doubles[3]) / 2;
			System.out.println("Perimetri i trapezit eshte :" + p);
		} else if ((doubles[2] + doubles[1]) > doubles[0]) {
			p = (doubles[0] * doubles[3]) / 2;
			System.out.println("Perimetri i trapezit eshte :" + p);
		} else if ((doubles[0] + doubles[2]) > doubles[1]) {
			p = (doubles[1] * doubles[3]) / 2;
			System.out.println("Perimetri i trapezit eshte :" + p);

		} else {
			System.out.println("Rivendos te dhenat!");
		}
		return p;
	}

}
