package com.shapes.service.implementation;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

import org.springframework.stereotype.Service;

import com.shapes.service.Shape3D;

@Service
public class Kubi implements Shape3D {
	private static Scanner scanner = new Scanner(System.in);
	private static boolean eshte = true;
	private static boolean seshte = false;

	@Override
	public boolean isShapeTypeSupported() {
		boolean p = false;
		String shape = scanner.nextLine();
		List<String> sh3D = Arrays.asList("Cilinder", "Kub", "Kuboid");
		for (String sh : sh3D) {
			if (sh.equals(shape)) {
				p = eshte;
				System.out.println("Forma e kerkuar eshte forma gjeometrike -" + p);
			} else {
				p = seshte;
				System.out.println("Forma e kerkuar eshte forma gjeometrike -" + p);

			}
		}
		return p;
	}

	public Double calculateArea3D(Double... doubles) {
		double sp = 0;
		System.out.println("Brinja e kubit eshte :");
		doubles[0] = scanner.nextDouble();
		sp = 6 * Math.pow(doubles[0], 2);
		System.out.println("Siperfaqja e kubit eshte :" + sp);
		return sp;
	}

	public Double calculateVolume3D(Double... doubles) {
		double v = 0;
		System.out.println("Brinja e kubit eshte :");
		doubles[0] = scanner.nextDouble();
		v = Math.pow(doubles[0], 3);
		System.out.println("Vellimi i kubit eshte :" + v);
		return v;
	}

}
