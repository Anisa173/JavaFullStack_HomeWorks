package com.shapes.service.implementation;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

import org.springframework.stereotype.Service;

import com.shapes.service.Shape2D;

@Service
public class Rombi implements Shape2D {
	private static Scanner scanner = new Scanner(System.in);
	private static boolean eshte = true;
	private static boolean seshte = false;

	@Override
	public boolean isShapeTypeSupported() {
		boolean p = false;
		String shape = scanner.nextLine();
		List<String> sh2D = Arrays.asList("Trekendesh", "Trapez", "Katror", "Drejtkendesh", "Romb");
		for (String sh : sh2D) {
			if (sh.equals(shape)) {
				p = eshte;
				System.out.println("Forma e kerkuar eshte forma gjeometrike -" + p);
			} else {
				p = seshte;
				System.out.println("Forma e kerkuar eshte forma gjeometrike -" + p);

			}
		}
		return p;
	}

	public Double calculateArea2D(Double... doubles) {
		double s = 0;
		System.out.println("Brinja e rombit eshte :");
		doubles[0] = scanner.nextDouble();
		System.out.println("Diagonalia e pare e rombit eshte :");
		doubles[1] = scanner.nextDouble();
		System.out.println("Diagonalia e dyte e rombit eshte :");
		doubles[2] = scanner.nextDouble();
		if (((2 * doubles[0]) > doubles[1]) && ((2 * doubles[0]) > doubles[2])) {
			s = doubles[1] * doubles[2];
			System.out.println("Siperfaqja e rombit eshte :" + s);
		} else {
			System.out.println("Rivendos te dhenat!");
		}
		return s;
	}

	public Double calculatePerimeter2D(Double... doubles) {
		double p = 0;
		System.out.println("Brinja e rombit eshte :");
		doubles[0] = scanner.nextDouble();
		System.out.println("Diagonalia e pare e rombit eshte :");
		doubles[1] = scanner.nextDouble();
		System.out.println("Diagonalia e dyte e rombit eshte :");
		doubles[2] = scanner.nextDouble();
		if (((2 * doubles[0]) > doubles[1]) && ((2 * doubles[0]) > doubles[2])) {
			p = 4 * doubles[0];
			System.out.println("Perimetri i rombit eshte :" + p);
		} else {
			System.out.println("Rivendos te dhenat!");
		}
		return p;

	}

}
