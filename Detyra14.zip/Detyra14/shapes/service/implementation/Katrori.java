package com.shapes.service.implementation;

import java.util.*;

import org.springframework.stereotype.Service;

import com.shapes.service.Shape2D;

@Service
public class Katrori implements Shape2D {
	private static Scanner scanner = new Scanner(System.in);
	private static boolean eshte = true;
	private static boolean seshte = false;

	@Override
	public boolean isShapeTypeSupported() {
		boolean p = false;
		String shape = scanner.nextLine();
		List<String> sh2D = Arrays.asList("Trekendesh", "Trapez", "Katror", "Drejtkendesh", "Romb");
		for (String sh : sh2D) {
			if (sh.equals(shape)) {
				p = eshte;
				System.out.println("Forma e kerkuar eshte forma gjeometrike -" + p);
			} else {
				p = seshte;
				System.out.println("Forma e kerkuar eshte forma gjeometrike -" + p);

			}
		}
		return p;
	}

	public Double calculateArea2D(Double... doubles) {
		double sip = 0;
		System.out.println("Brinja e katrorit eshte :");
		doubles[0] = scanner.nextDouble();
		sip = Math.pow(doubles[0], 2);
		System.out.println("Siperfaqja e katrorit  eshte :" + " " + sip);
		return sip;
	}

	public Double calculatePerimeter2D(Double... doubles) {
		double p = 0;

		System.out.println("Brinja e katrorit eshte :");
		doubles[0] = scanner.nextDouble();
		p = 4 * doubles[0];
		System.out.println("Perimetri i katrorit  eshte :" + " " + p);
		return p;
	}

}
