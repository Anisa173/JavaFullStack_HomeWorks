package com.shapes.service.implementation;

import com.shapes.service.Shape2D;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class FormaGjeometrike {
	
@Autowired
	private final Shape2D shape2d;

	public FormaGjeometrike(Shape2D shape2d) {
		this.shape2d = shape2d;
	}

	public Shape2D getShape2d() {
		return shape2d;
	}

	public  boolean isShapeTypeSupported() {
		
		return shape2d.isShapeTypeSupported();
	}

	public  double calculateArea2D() {
		
		return shape2d.calculateArea2D();
	}

	public  double calculatePerimeter2D() {
	
		return shape2d.calculatePerimeter2D();
	}

	 

	

}
