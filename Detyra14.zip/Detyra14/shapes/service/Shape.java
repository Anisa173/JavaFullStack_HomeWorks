package com.shapes.service;

public interface Shape {

	boolean isShapeTypeSupported();


	
}
