package com.strukturagjeometrike.service.Implementation;
import org.springframework.stereotype.Service;
import java.lang.Math;
import com.strukturagjeometrike.model.Shape3Enum;
import com.strukturagjeometrike.service.Shape3D;
@Service
public class Cilinder implements Shape3D {

	 Shape3Enum shape = Shape3Enum.CILINDER;

	@Override
	public Double calculateArea3D(Double...digits) {
		return 2 * Math.PI * digits[1] * (digits[0] + digits[1]);
	}

	@Override
	public Double calculateVolume3D(Double... digits) {

		return Math.PI * Math.pow(digits[0], 2) * digits[1];
	}

	@Override
	public boolean isShapeTypeSupported(String val) {
		return shape == Shape3Enum.fromValue(val);
	}
	
}
