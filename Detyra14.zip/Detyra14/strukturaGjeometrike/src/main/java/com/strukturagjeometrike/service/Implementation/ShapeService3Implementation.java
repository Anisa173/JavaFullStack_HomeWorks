package com.strukturagjeometrike.service.Implementation;

import java.util.*;
import org.springframework.stereotype.Component;
import com.strukturagjeometrike.service.Shape3D;


@Component
public class ShapeService3Implementation {
private final List<Shape3D> shape3D ;
	
	public ShapeService3Implementation(List<Shape3D> shape3D) {
		this.shape3D = shape3D;
	}

	public Double calculateA3D(String shapeType,Double...digits) {
		return shape3D.stream()
				.filter(s -> s.isShapeTypeSupported(shapeType))
				.findFirst()
				.map(s -> s.calculateArea3D(digits))
				.orElseThrow(()-> new RuntimeException(String
						.format("Calculation error!")));
	}
// public Double calculateA2D(String shapeType , Double...digits){ 
//  Double result = null;
//	 for(Shape3D shp : shape3D){
//    if(shp.isShapeTypeSupported(shapeType){
//	    result = sh.calculateArea2D(digits);
//     }
//	}
//	if(result == null){
//    throw new RunTimeException("Calculation error!");
//   }
// }
	
	
	public Double calculateV3D(String shapeType,Double...digits) {
		return shape3D.stream()
				.filter(s -> s.isShapeTypeSupported(shapeType))
				.findFirst()
				.map(s -> s.calculateVolume3D(digits))
				.orElseThrow(()-> new RuntimeException(String
						.format("Calculation error!")));
	}
	// public Double calculateA2D(String shapeType , Double...digits){ 
//  Double result = null;
//	 for(Shape3D shp : shape3D){
//    if(shp.isShapeTypeSupported(shapeType){
//	    result = sh.calculateArea2D(digits);
//     }
//	}
//	if(result == null){
//    throw new RunTimeException("Calculation error!");
//   }
// }	
}
