package com.strukturagjeometrike.service.Implementation;

import org.springframework.stereotype.Service;

import com.strukturagjeometrike.model.Shape2Enum;
import com.strukturagjeometrike.service.Shape2D;

@Service
public class Trapez implements Shape2D {
	Shape2Enum shape2ddE = Shape2Enum.TRAPEZ;

	@Override
	public Double calculateArea2D(Double... d) {
		Double sip =(double) 0;
		if ((d[1]) < d[3]) {
			sip = (d[0] + d[1]) * d[4] / 2;
		}
		return sip;
	}

	@Override
	public Double calculatePerimeter2D(Double... d) {
		Double p = (double) 0;
		if ((d[1] ) < d[3]) {
			p = d[0] + d[1] + d[2] + d[3];
		}
		return p;
	}

	@Override
	public boolean isShapeTypeSupported(String value) {

		return shape2ddE == Shape2Enum.fromValue(value);
	}

}
