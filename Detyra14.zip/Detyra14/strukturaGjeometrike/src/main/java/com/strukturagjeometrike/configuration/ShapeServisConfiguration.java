package com.strukturagjeometrike.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.strukturagjeometrike.service.Implementation.ShapeService2D;
import com.strukturagjeometrike.service.Implementation.ShapeService3D;
import com.strukturagjeometrike.service.Implementation.Cilinder;
import com.strukturagjeometrike.service.Implementation.Drejkendesh;
import com.strukturagjeometrike.service.Implementation.Katror;
import com.strukturagjeometrike.service.Implementation.Kubi;
import com.strukturagjeometrike.service.Implementation.Kuboid;
import com.strukturagjeometrike.service.Implementation.Romb;
import com.strukturagjeometrike.service.Implementation.Trapez;
import com.strukturagjeometrike.service.Implementation.Trekendesh;

@Configuration
public class ShapeServisConfiguration {
//Loose coupling
	@Bean
	ShapeService2D calculateService2D(Trekendesh trek, Katror k, Drejkendesh dr, Trapez trp, Romb r) {
		return new ShapeService2D(trek, k, dr, trp, r);
	}
//Loose coupling
	@Bean
	ShapeService3D calculateService3D(Cilinder cil, Kubi k, Kuboid kb) {
		return new ShapeService3D(cil, k, kb);
	}

}
