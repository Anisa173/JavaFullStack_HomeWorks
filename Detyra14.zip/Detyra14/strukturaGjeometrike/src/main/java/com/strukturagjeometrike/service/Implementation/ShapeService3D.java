package com.strukturagjeometrike.service.Implementation;

import com.strukturagjeometrike.model.Shape3Enum;
//Lidhje e ngushtë

@Autowired
public class ShapeService3D {
	private final Cilinder cil;
	private final Kubi k;
	private final Kuboid kb;

	public ShapeService3D(Cilinder cil, Kubi k, Kuboid kb) {
		this.cil = cil;
		this.k = k;
		this.kb = kb;
	}

	public Double calculateA3D(String shapeType, Double... digits) {
		return switch (Shape3Enum.fromValue(shapeType)) {
		case CILINDER -> cil.calculateArea3D(digits);
		case KUBI -> k.calculateArea3D(digits);
		case KUBOID -> kb.calculateArea3D(digits);
		default -> throw new RuntimeException();
		};
	}

	public Double calculateV3D(String shapeType, Double... digits) {
		return switch (Shape3Enum.fromValue(shapeType)) {
		case CILINDER -> cil.calculateVolume3D(digits);
		case KUBI -> k.calculateVolume3D(digits);
		case KUBOID -> kb.calculateVolume3D(digits);
		default -> throw new RuntimeException();
		};
	}
}
