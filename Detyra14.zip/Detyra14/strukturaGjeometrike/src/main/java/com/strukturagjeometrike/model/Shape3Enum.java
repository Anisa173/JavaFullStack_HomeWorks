package com.strukturagjeometrike.model;

import java.util.Arrays;

public enum Shape3Enum {
	KUBOID("Kuboid"), KUBI("Kubi"), CILINDER("Cilinder");

	private String value;

	Shape3Enum() {
		value = "Kubi";
	}

	Shape3Enum(String value) {
		this.value = value;
	}

	public static Shape3Enum fromValue(String value) {
		return Arrays.asList(Shape3Enum.values()).stream().filter(e -> e.getValue().equals(value)).findFirst()
	
				.orElseThrow(() -> new RuntimeException(String.format("Geometric's shape3d %s not found", value)));

	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	
}
//public static Shape3Enum fromValue(String shape) throws RunTimeException{
//  ArrayList<Shape3Enum> shape3d = Array.asList(Shape3Enum.values());
//      Shape3Enum toReturnvalue = null;
//          for(Shape3Enum sh : shape3d){
//            if(sh.value.equals(shape){
//                 toReturnValue = sh;
//                      break;
//         }
//      }
//    if(toReturnvalue == null){
//      throw new RunTimeException("Geometric's shape3d is not found");
