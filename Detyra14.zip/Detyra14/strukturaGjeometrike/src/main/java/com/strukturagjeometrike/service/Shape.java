package com.strukturagjeometrike.service;

public interface Shape {
	boolean isShapeTypeSupported(String shapeType);
	
}
