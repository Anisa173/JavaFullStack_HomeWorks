package com.strukturagjeometrike.service.Implementation;

import org.springframework.stereotype.Service;
import com.strukturagjeometrike.model.Shape2Enum;
import com.strukturagjeometrike.service.Shape2D;
@Service
public class Katror implements Shape2D {
	Shape2Enum shape2d = Shape2Enum.KATROR;

	@Override
	public Double calculateArea2D(Double...d) {

		return Math.pow(d[1], 2);
	}

	@Override
	public Double calculatePerimeter2D(Double...d) {

		return 4 * d[1];
	}

	@Override
	public boolean isShapeTypeSupported(String value) {

		return shape2d == Shape2Enum.fromValue(value);
	}

	

	

}
