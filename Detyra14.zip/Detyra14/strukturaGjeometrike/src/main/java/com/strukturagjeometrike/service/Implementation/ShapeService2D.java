package com.strukturagjeometrike.service.Implementation;

import org.springframework.beans.factory.annotation.Autowired;
import com.strukturagjeometrike.model.Shape2Enum;

public class ShapeService2D {
//Lidhje e ngushtë

	@Autowired
	private final Trekendesh trek;
	private final Katror k;
	private final Drejkendesh dr;
	private final Trapez trp;
	private final Romb r;

	public ShapeService2D(Trekendesh trek, Katror k, Drejkendesh dr, Trapez trp, Romb r) {
		this.trek = trek;
		this.k = k;
		this.dr = dr;
		this.trp = trp;
		this.r = r;
	}

	public Double calculateA2D(String shapeType, Double... d) {
		return switch (Shape2Enum.fromValue(shapeType)) {
		case TREKENDESH -> trek.calculateArea2D(d);
		case KATROR -> k.calculateArea2D(d);
		case DREJTKENDESH -> dr.calculateArea2D(d);
		case TRAPEZ -> trp.calculateArea2D(d);
		case ROMB -> r.calculateArea2D(d);
		default -> throw new RuntimeException();
		};
	}

	public Double calculateP2D(String shapeType, Double... d) {
		return switch (Shape2Enum.fromValue(shapeType)) {
		case TREKENDESH -> trek.calculatePerimeter2D(d);
		case KATROR -> k.calculatePerimeter2D(d);
		case DREJTKENDESH -> dr.calculatePerimeter2D(d);
		case TRAPEZ -> trp.calculatePerimeter2D(d);
		case ROMB -> r.calculatePerimeter2D(d);
		default -> throw new RuntimeException();
		};
	}

}
