package com.strukturagjeometrike.service;

public interface Shape2D extends Shape {

	Double calculateArea2D(Double... d);

	Double calculatePerimeter2D(Double... d);

	@Override
	boolean isShapeTypeSupported(String shapeType);

}
