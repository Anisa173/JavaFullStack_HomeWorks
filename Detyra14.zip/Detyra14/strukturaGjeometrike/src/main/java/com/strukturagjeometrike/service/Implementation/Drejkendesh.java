package com.strukturagjeometrike.service.Implementation;

import org.springframework.stereotype.Service;

import com.strukturagjeometrike.model.Shape2Enum;
import com.strukturagjeometrike.service.Shape2D;
@Service
public class Drejkendesh implements Shape2D {
	Shape2Enum shape = Shape2Enum.DREJTKENDESH;

	@Override
	public Double calculateArea2D(Double...d) {
		return d[0] * d[1];
	}

	@Override
	public Double calculatePerimeter2D(Double...d) {
		return (2 * (d[0] + d[1]));
	}

	@Override
	public boolean isShapeTypeSupported(String value) {

		return shape == Shape2Enum.fromValue(value);
	}

	

	

	

}
