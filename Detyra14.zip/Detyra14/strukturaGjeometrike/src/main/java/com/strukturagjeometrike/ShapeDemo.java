package com.strukturagjeometrike;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.strukturagjeometrike.model.Shape2Enum;
import com.strukturagjeometrike.model.Shape3Enum;
import com.strukturagjeometrike.service.Implementation.ShapeService2Implementation;
import com.strukturagjeometrike.service.Implementation.ShapeService3Implementation;

@SpringBootApplication
public class ShapeDemo implements CommandLineRunner {

	private static final Logger log = LoggerFactory.getLogger(ShapeDemo.class);

	private final ShapeService3Implementation calculateServiceV3I;

	private final ShapeService2Implementation calculateServiceV2I;

	public ShapeDemo(ShapeService2Implementation calculateServiceV2I, ShapeService3Implementation calculateServiceV3I) {

		this.calculateServiceV2I = calculateServiceV2I;
		this.calculateServiceV3I = calculateServiceV3I;

	}

	public static void main(String[] args) {
		SpringApplication.run(ShapeDemo.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		log.info("Siperfaqja - Trekendesh {}",
				calculateServiceV2I.calculateA2D(Shape2Enum.TREKENDESH.getValue(), 5.0, 6.0, 9.0));
		log.info("Siperfaqja - Katror {}", calculateServiceV2I.calculateA2D(Shape2Enum.KATROR.getValue(), 5.0));
		log.info("Siperfaqja - Drejtkendesh {}",
				calculateServiceV2I.calculateA2D(Shape2Enum.DREJTKENDESH.getValue(), 4.0, 7.0));
		log.info("Siperfaqja - Trapez {}",
				calculateServiceV2I.calculateA2D(Shape2Enum.TRAPEZ.getValue(), 5.0, 8.0, 4.0, 12.0));

		log.info("Perimetri - Trekendesh {}",
				calculateServiceV2I.calculatePerimeter2D(Shape2Enum.TREKENDESH.getValue(), 5.0, 6.0, 9.0));
		log.info("Perimetri - Katror {}", calculateServiceV2I.calculatePerimeter2D(Shape2Enum.KATROR.getValue(), 5.0));
		log.info("Perimetri - Drejtkendesh {}",
				calculateServiceV2I.calculatePerimeter2D(Shape2Enum.DREJTKENDESH.getValue(), 4.0, 7.0));
		log.info("Perimetri - Trapez {}",
				calculateServiceV2I.calculatePerimeter2D(Shape2Enum.TRAPEZ.getValue(), 5.0, 8.0, 4.0, 12.0));

		log.info("Siperfaqja - Kub {}", calculateServiceV3I.calculateA3D(Shape3Enum.KUBI.getValue(), 5.0));
		log.info("Siperfaqja - Kuboid {}",
				calculateServiceV3I.calculateA3D(Shape3Enum.KUBOID.getValue(), 5.0, 5.0, 9.0));
		log.info("Siperfaqja - Cilinder {}",
				calculateServiceV3I.calculateA3D(Shape3Enum.CILINDER.getValue(), 4.0, 7.0));

		log.info("Vellimi - Kub {}", calculateServiceV3I.calculateV3D(Shape3Enum.KUBI.getValue(), 5.0));
		log.info("Vellimi - Kuboid {}", calculateServiceV3I.calculateV3D(Shape3Enum.KUBOID.getValue(), 5.0, 5.0, 9.0));
		log.info("Vellimi - Cilinder {}", calculateServiceV3I.calculateV3D(Shape3Enum.CILINDER.getValue(), 4.0, 7.0));

	}

	public static Logger getLog() {
		return log;
	}

}
