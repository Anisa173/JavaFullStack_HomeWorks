package com.strukturagjeometrike.model;

import java.util.Arrays;

public enum Shape2Enum {
	TREKENDESH("Trekendesh"), KATROR("Katror"), DREJTKENDESH("drejtkendesh"), TRAPEZ("Trapez"), ROMB("Romb");

	private String value;

	Shape2Enum() {
		value = "trekendesh";
	}

	Shape2Enum(String value) {
		this.value = value;
	}

	public static Shape2Enum fromValue(String value) {
		return Arrays.asList(Shape2Enum.values()).stream().filter(e -> e.getValue().equals(value)).findFirst()
				.orElseThrow(() -> new RuntimeException(String.format("Geometric's shape2d %s not found", value)));

	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

//	public static Shape2Enum fromValue1(String shape) {
//		List<Shape2Enum> shape2d = Arrays.asList(Shape2Enum.values());
//		Shape2Enum toReturnEnum = null;
//		for(Shape2Enum e : shape2d) {
//			if(e.value.equals(shape)) {
//				toReturnEnum = e;
//				break;
//			}
//		}
//		if(toReturnEnum==null) {
//			new RuntimeException(String
//					.format("Geometric's shap2d %s not found",shape));
//		}
//		return null;
//	
//	}
}
