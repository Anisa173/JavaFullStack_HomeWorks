package com.strukturagjeometrike.service.Implementation;

import org.springframework.stereotype.Service;

import com.strukturagjeometrike.model.Shape2Enum;
import com.strukturagjeometrike.service.Shape2D;

@Service
public class Romb implements Shape2D {
	Shape2Enum shape2DD = Shape2Enum.ROMB;

	@Override
	public Double calculateArea2D(Double... d) {
		Double sip = (double) 0;
		if (((2 * d[1]) > d[2]) && ((2 * d[1]) > d[3])) {
			sip = (d[2] * d[3]) / 2;
		}
		return sip;
	}

	@Override
	public Double calculatePerimeter2D(Double... d) {
		Double p = (double) 0;
		if (((2 * d[1]) > d[2]) && ((2 * d[1]) > d[3])) {
			p = 4 * d[1];
		}
		return p;
	}

	@Override
	public boolean isShapeTypeSupported(String value) {

		return shape2DD == Shape2Enum.fromValue(value);
	}

}
