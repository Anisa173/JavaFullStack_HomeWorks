package com.strukturagjeometrike.service;

public interface Shape3D extends Shape {

	Double calculateArea3D(Double... digits);

	Double calculateVolume3D(Double... digits);

	@Override
	boolean isShapeTypeSupported(String shapeType);

}
