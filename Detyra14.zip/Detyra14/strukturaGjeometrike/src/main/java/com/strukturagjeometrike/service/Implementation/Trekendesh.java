package com.strukturagjeometrike.service.Implementation;

import org.springframework.stereotype.Service;
import com.strukturagjeometrike.model.Shape2Enum;
import com.strukturagjeometrike.service.Shape2D;

@Service
public class Trekendesh implements Shape2D {
	Shape2Enum shape2dE = Shape2Enum.TREKENDESH;

	@Override
	public Double calculateArea2D(Double... d) {
		Double sip = (double) 0;
		if ((d[0] + d[1]) > d[2]) {
			sip = (d[3] * d[2]) / 2;
		} else if ((d[2] + d[1]) > d[0]) {
			sip = (d[3] * d[0]) / 2;
		} else if ((d[0] + d[2]) > d[1]) {
			sip = (d[3] * d[1]) / 2;
		}
		return sip;
	}

	@Override
	public Double calculatePerimeter2D(Double... d) {
		Double p = (double) 0;
		if ((d[0] + d[1]) > d[2]) {
			p = (d[0] + d[1] + d[2]);
		} else if ((d[2] + d[1]) > d[0]) {
			p = (d[0] + d[1] + d[2]);
		} else if ((d[0] + d[2]) > d[1]) {
			p = (d[0] + d[1] + d[2]);
		}
		return p;
	}

	@Override
	public boolean isShapeTypeSupported(String value) {

		return shape2dE == Shape2Enum.fromValue(value);
	}

}
