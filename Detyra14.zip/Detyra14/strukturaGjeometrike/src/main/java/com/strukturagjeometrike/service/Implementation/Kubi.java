package com.strukturagjeometrike.service.Implementation;

import org.springframework.stereotype.Service;
import java.lang.Math;
import com.strukturagjeometrike.model.Shape3Enum;
import com.strukturagjeometrike.service.Shape3D;

@Service
public class Kubi implements Shape3D {
	Shape3Enum shape3d = Shape3Enum.KUBI;

	@Override
	public Double calculateArea3D(Double... digits) {

		return Math.pow(digits[1], 2) * 6;
	}

	@Override
	public Double calculateVolume3D(Double... digits) {

		return Math.pow(digits[1], 3);
	}

	@Override
	public boolean isShapeTypeSupported(String value) {

		return shape3d == Shape3Enum.fromValue(value);
	}

}
