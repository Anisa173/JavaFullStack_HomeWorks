package com.strukturagjeometrike.service.Implementation;

import java.util.List;

import org.springframework.stereotype.Component;

import com.strukturagjeometrike.service.Shape2D;

@Component
public class ShapeService2Implementation {

	private final List<Shape2D> shape2D;

	public ShapeService2Implementation(List<Shape2D> shape2D) {
		this.shape2D = shape2D;
	}

	public Double calculateA2D(String shapeType, Double... d) {
		return shape2D.stream().filter(s -> s.isShapeTypeSupported(shapeType)).findFirst()
				.map(s -> s.calculateArea2D(d))
				.orElseThrow(() -> new RuntimeException(String.format("Calculation error")));
	}

//	public Double calculateA2D(String shape,Double... digits){
//	Double result = null;
//		for(Shape2D a : shape2D) {
//			if(a.isShapeTypeSupported(shape) {
//				result = a.calculateArea2D(digits);
//				break;
//			}
//		}
//		if(result != null) {
//			return result;
//		}else {
//			throw new RuntimeException(String.format("Calculation error"));
//		}
//	}
	public Double calculatePerimeter2D(String shapeType, Double... d) {
		return shape2D.stream().filter(s -> s.isShapeTypeSupported(shapeType)).findFirst()
				.map(s -> s.calculatePerimeter2D(d))
				.orElseThrow(() -> new RuntimeException(String.format("Calculation error")));
	}

// public Double calculatePerimeter2D(String shapeType,Double...d){
// Double toReturnvalue = null;
// for(Shape2D shape :shape2D){
//  if(shape.isShapeTypeSupported(shapeType){
//   result = shape.calculatePerimeter2D(d);
//     break;
//  }}
//  if(toReturnvalue == null){
//   throw new RunTimeException("Calculation error!");
//       }
//   }
}
