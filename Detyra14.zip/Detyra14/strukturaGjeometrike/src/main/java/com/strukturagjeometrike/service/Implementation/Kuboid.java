package com.strukturagjeometrike.service.Implementation;

import org.springframework.stereotype.Service;
import com.strukturagjeometrike.model.Shape3Enum;
import com.strukturagjeometrike.service.Shape3D;

@Service
public class Kuboid implements Shape3D {
	Shape3Enum shape3d = Shape3Enum.KUBOID;

	@Override
	public Double calculateArea3D(Double... digits) {
		return 2 * ((digits[1] * digits[0]) + (digits[2] * digits[0]) + digits[1] * digits[2]);
	}

	@Override
	public Double calculateVolume3D(Double... digits) {

		return digits[0] * digits[1] * digits[2];
	}

	@Override
	public boolean isShapeTypeSupported(String value) {

		return shape3d == Shape3Enum.fromValue(value);
	}

}
