package ushtrime.scratchdy;
		import java.util.Scanner;
		/**
		 *
		 * @author ACSystem
		 */
		public class KostoD{
		    static double kmT, kostojaLiter,tarifaD, t,kostoD;
		    private static final double kmMesL = 6 ;
		    public static void main (String[] args){
		        Scanner input = new Scanner(System.in);

		        System.out.println("Tarifat e parkimit ne dite:");
		        tarifaD = input.nextDouble();
		        System.out.println("Taksa te tjera ditore:");
		        t = input.nextDouble();
		        System.out.println("Kilometrat Totale te drejtuara ne fund te dites :");
		        kmT = input.nextDouble();
		        System.out.println("Kostoja për liter benzinë:");
		        kostojaLiter = input.nextDouble();
		        kostoD = llogaritKosto();


		    }
		    public static double llogaritKosto(){
		        double KostoTotD, kmTotDitore ,kosL ,tkD , taD;
		        kmTotDitore = kmT;
		        kosL = kostojaLiter;
		        tkD= t;
		        taD = tarifaD;
		        double sasiaL = kmTotDitore/kmMesL ;
		        double kostoTkmTotD = kosL * sasiaL;
		        System.out.println("Sasia e litrave benzine qe harxhon punonjesi ne dite:" + " " + sasiaL + " liter .");
		        System.out.println("Kostoja ditore per km totale ditore te pershkuar dhe sasi litrash benzine qe nevojiten:" + " " + kostoTkmTotD + " "+ "Leke");
		        KostoTotD = kostoTkmTotD + tkD + taD;
		        return KostoTotD;
	}

}
