package ushtrime.scratchdy;
import java.util.Scanner;
public class Ushtrimi8 {
public static double kmMesL = 8.5;
public static double costL = 650;
static double kmTotditore;
static double takD, taP,result;
private static Scanner in;
public static void main(String[] args) {
 in = new Scanner(System.in);
System.out.println("Ju lutem vendosni totalin e kilometrave te drejtuara nga automjeti juaj gjate dites se sotme:");
kmTotditore = in.nextDouble();
System.out.println("Vendosni tarifen e parkimit per diten e sotme :");
taP =in.nextDouble();
System.out.println("Vendosni taksen ditore:");
takD =in.nextDouble();
result = afishoK();
}
public static double afishoK() {
double kmT=kmTotditore;
double sasianeLitra= (kmT/kmMesL);	
double costKmtotal = (sasianeLitra * costL);
double costTOT = costKmtotal + taP + takD;	
System.out.println("Kosto totale ditore per punonjesin eshte :" + " "+ costTOT+ " "+"Leke .");	
	return costTOT;	
}
}
