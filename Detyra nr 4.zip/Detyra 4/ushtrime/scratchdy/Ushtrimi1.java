package ushtrime.scratchdy;
import java.lang.Math;
public class Ushtrimi1 {

public static void main(String[] args) {
	/*Ky program kryen nje llogaritje te listes se pagave.*/
	System.out.println("Fut nje numer te plote:");
int a,b,c,x=100;
c= (int)(Math.random()*x);
b= (int)(Math.random()*x);
a= b*c;
System.out.println("Produkti i dy numrave "+" "+b+" "+"dhe"+" "+ c+" "+"eshte"+" "+ a);
	}

}
