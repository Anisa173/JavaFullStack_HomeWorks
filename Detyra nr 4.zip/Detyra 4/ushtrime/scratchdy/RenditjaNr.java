package ushtrime.scratchdy;
import java.lang.Math;
public class RenditjaNr {
static int a,b,c,d,e,temp,j,i;
public static int n=5;static int m[]= new int[n];
static int v[]=new int[n];
public static void main(String[] args) {
	RenditjaNr no = new RenditjaNr();
no.maximum();
	}
public void maximum() {
int r = 10;
a = (int)(Math.random()*r);
b = (int)(Math.random()*r);
c = (int)(Math.random()*r);
d = (int)(Math.random()*r);
e = (int)(Math.random()*r);
System.out.println("Aplikacioni lexon pese numra te plote si me poshte:");

for(int i=0;i<5;i++) {
m[0]=a;
m[1]=b;
m[2]=c;
m[3]=d;
m[4]=e;}
for(int i=0;i<n;i++) {
v[i]=m[i];
System.out.println(v[i]);
}
System.out.println("Rendisni elementet ne rendin rrites ose zbrites");
for(int k=n-1-j;k>=0;k--) {
for(j=0;j<k;j++) {
for(i=j;i<=j+1;i++) {if(v[j]>v[i+1]) {temp = v[i];
v[i]= v[i+1];
v[i+1] = temp;}
else {v[j]=v[i];}
}System.out.println(v[i]);
System.out.println(v[0]);
System.out.println(v[n-1]);}}
}}
