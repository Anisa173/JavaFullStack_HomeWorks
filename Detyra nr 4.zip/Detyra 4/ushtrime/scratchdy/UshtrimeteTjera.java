package ushtrime.scratchdy;
import java.util.Scanner;
import java.lang.Math;
public class UshtrimeteTjera {
private static Scanner x;
static int m,n,c=n%2,e=m%2;
public static void main(String[] args) {
x = new Scanner(System.in);
System.out.println("Ju lutem vendosni numrin e pare:");
if(x.hasNextInt()) {n=x.nextInt();}
else {System.out.println("E dhena e gjeneruar eshte gabuar!");x.next();}
System.out.println("Ju lutem vendosni numrin e dyte:");
if(x.hasNextInt()) {m=x.nextInt();}
else {System.out.println("E dhena e gjeneruar eshte gabuar!");x.next();}
int max=n;
if(max>m) {System.out.println("Numri i pare"+" "+ n+" "+"eshte me i madh se numri i dyte"+" " +m+" "+"!");}
else if(max<m) {System.out.println("Numri i dyte"+" "+ m+" "+"eshte me i madh se numri i pare"+" "+n+" "+"!");}
else {System.out.println("Numrat jane te barabarte");

int sh=n+m;
int p= n*m;
int d= n-m;
int dif= Math.abs(d);
int f=n/m;
int g=m/n;
System.out.println("Shuma e numrave eshte :"+" "+ sh+" .");
System.out.println("Prodhimi i numrave eshte :"+" "+p+" .");
System.out.println("Diferenca e numrave eshte :"+" "+dif+" .");
System.out.println("Pjestimi i numrit te pare me numrin e dyte eshte :"+" "+f+" .");
System.out.println("Pjestimi i numrit te dyte me numrin e pare eshte :"+" "+g+" .");
if(c==0) {System.out.println("Numri i pare"+" "+ n+" "+ "eshte numer cift .");}
else {System.out.println("Numri i pare"+" "+ n+" "+ "eshte numer tek .");}
if(e==0) {System.out.println("Numri i dyte"+" "+ n+" "+ "eshte numer cift .");}
else {System.out.println("Numri i dyte"+" "+ n+" "+ "eshte numer tek .");}
}

}}
