package ushtrime.scratchdy;
import java.util.Scanner;
import java.lang.Math;
public class Ushtrimi7 {
private static Scanner in;
static double result,viti;
public static void main(String[] args) {
in=new Scanner(System.in);	
System.out.println("Parashikoni sa do jete popullsia pas: nje dy ,tre apo n vite!");
if(in.hasNextDouble()) {viti=in.nextDouble();}
else {System.out.println("E dhena e vendosur nga useri nuk eshte nje numer!");in.next();}
result = prognozo();
}
public static double prognozo() {
double popullsia = 7*Math.pow(10,9);
double rritjaVjetore = 0.2 * popullsia;
double v= viti;
double popullsiaP = popullsia + Math.pow(rritjaVjetore,v);	
System.out.println("Popullsia pas"+" "+v+" "+"viti/vjetesh eshte :" +popullsiaP+ " .");
return popullsiaP;
}}

