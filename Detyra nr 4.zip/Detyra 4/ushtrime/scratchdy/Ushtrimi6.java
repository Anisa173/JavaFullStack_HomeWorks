package ushtrime.scratchdy;
import java.lang.Math;
import java.util.Scanner;
public class Ushtrimi6 {
private static Scanner input;
static double gjatesia,pesha,r;
public static void main(String[] args) {
input= new Scanner(System.in);
System.out.println("Ju lutem vendosni gjatesine tuaj ne metra:");
gjatesia =input.nextInt();
System.out.println("Vendosni peshen tuaj ne kg:");
pesha = input.nextInt();
r=afisho();
}
public static double afisho() {
double BMI,weightinKilogram,heightinMeters;
weightinKilogram = pesha;
heightinMeters = gjatesia;
BMI =(weightinKilogram/Math.pow(heightinMeters, 2));
if(BMI < 19) {System.out.println("Personi eshte nen_peshe!");}
else if((BMI>19)&&(BMI<25)) {System.out.println("Personi gezon peshe normale!");}
else {System.out.println("Personi eshte mbi peshe!");}

return BMI;
}}
