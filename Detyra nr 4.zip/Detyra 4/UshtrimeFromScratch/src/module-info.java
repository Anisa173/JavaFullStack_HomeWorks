/**
 * 
 */
/**
 * @author ACSystem
 *
 */
module UshtrimeFromScratch {
}