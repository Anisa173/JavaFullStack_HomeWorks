package departamenti;
import java.util.Scanner;
public class Store_dataStudent {
static boolean is = true, rregjistrim;
static boolean isN = false;
private static Scanner input;
static String greeting , em_mbie,nID , degaSt , result;
static int viti;
public static void main(String[] args) {
Store_dataStudent student = new Store_dataStudent();
student.grettings();
input = new Scanner(System.in);

System.out.println("Ju jeni:");
em_mbie = input.nextLine();
System.out.println("Numri juaj personal i identifikimit :");
nID= input.next();
System.out.println("Ju lutem vendosni vitin akademik :");
viti = input.nextInt();
System.out.println("Ju jeni te rregjistruar ne fushen e studimit :");
degaSt = input.next();

student.strukturaOrganizative();
greeting = greet1();

rregjistrim = vitiAkademik();

result = fushaStudimore();
}

public void grettings() {	
System.out.println("Mire se erdhet ne Fakultetin e Shkencave te Natyres !" + '\n');
}


public static  String greet1() {
String emri = em_mbie;
System.out.println("Mire se erdhet" + " " + emri + " "+ "ne Fakultetin e Shkencave te Natyres!");

return emri;
}
public int strukturaOrganizative() {
int nrTotDep =25;
System.out.println("Numri i departamenteve ne fakultetin tone eshte :" + " " + nrTotDep + " .");
return nrTotDep;
}
public static boolean vitiAkademik(){
int vit = viti; boolean pohimi;
if((vit == 2022)|| (vit == 2023)){pohimi = is; System.out.println("Ju studioni ne vitin akademik" + " " + vit+ " " +":"+ pohimi);}
else {
pohimi=isN; System.out.println("Ju jeni te regjistruar ne vitin akademik 2022 ose 2023" + " " +":"+ pohimi);
} return pohimi;}
public static String fushaStudimore() {
String dept,studime = degaSt;
switch(studime) {
case "Informatik": dept = "Departamenti i Informatikes";System.out.println("Studenti eshte pjese tek" +" " +dept);
break;
case "TIK": dept = "Departamenti i TIK" ;System.out.println("Studenti eshte pjese tek" +" " +dept);
break;
case "Matematik": dept = "Departamenti i Matematikes";System.out.println("Studenti eshte pjese tek" +" " +dept);
break;
default: dept = " - " ; System.out.println("Studenti eshte pjese tek" + " " + dept);}
return dept;
}
}
