package studenti;
import java.util.Scanner;
public class KursiJava {
private static Scanner in;
static boolean kurs = true;
static boolean b,result;
static boolean pushim = false;
static String dt;
public static void main(String[] args) {
in=new Scanner(System.in);
//E vertete vetem nese eshte dite e hene dhe realizohet seanca e bootcamp java
System.out.println("Cfare dite eshte sot?");
dt = in.nextLine();
System.out.println("A je ne kurs, true apo false?");
b = in.nextBoolean();
result = ndjekKursin();
}
public static boolean ndjekKursin() {
String d = dt;
boolean pohimi = b;
if((d== "e hene")&&(pohimi == kurs)) {pohimi = kurs; System.out.println(pohimi +" "+"-" +"Sot eshte dite" +" "+ d+ " "+ "DHE"+" "+"eshte dite kursi bootcamp java");}	
else if ((d=="e hene")&&(pohimi != kurs)) {pohimi = pushim;	System.out.println(pohimi +" "+"-" +"Sot eshte dite" +" "+ d+ " "+ "DHE"+" "+"eshte dite kursi bootcamp java");}
else if	((d!="e hene")&&(pohimi != pushim)) {pohimi = pushim;System.out.println(pohimi +" "+"-" +"Sot eshte dite" +" "+ d+ " "+ "DHE"+" "+"eshte dite pushimi");}
else if((d!= "e hene")&&(pohimi!=kurs)){pohimi = pushim;System.out.println(pohimi +" "+"-" +"Sot eshte dite" +" "+ d+ " "+ "DHE"+" "+"eshte dite pushimi");}
return pohimi;
}
}