package studenti;
public class Studenti {
static boolean po = true;
static boolean pop = false;
static boolean pohim;
public static void main(String[] args) {
Studenti st = new Studenti();
st.ndjekStudimet();
}
public static boolean ndjekStudimet() {
String dt = "e hene";
String str = "dite kursi";
String str1 = "dite pushimi";
if((dt== "e hene")&&(str=="dite kursi")) {pohim = po;System.out.println(pohim +" "+"-"+"Sot eshte dite" + " " +dt+" "+"dhe eshte" +" "+ str+ " "+"bootcamp java");}
if((dt== "e hene")&&(str!="dite pushimi")) {pohim = pop;System.out.println(pohim+" "+"-"+"Sot eshte dite" + " " +dt+" "+"dhe eshte"+" " + str1);}
return pohim;
}
}