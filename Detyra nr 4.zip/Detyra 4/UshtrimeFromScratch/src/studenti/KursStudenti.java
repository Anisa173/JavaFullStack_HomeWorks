package studenti;
import java.util.Scanner;

public class KursStudenti {
private static Scanner in;
		static boolean kurs = true;
		static boolean b,result;
		static boolean pushim = false;
		static String dt;
		public static void main(String[] args) {
		in=new Scanner(System.in);
		//E vertete vetem nese eshte dite e hene dhe realizohet seanca e bootcamp java
		System.out.println("Cfare dite eshte sot?");
		dt = in.nextLine();
		
		result = ndjekKursin();
		}
		public static boolean ndjekKursin() {
		String d = dt;
		boolean pohimi;
		switch(d) {
		case "e hene": pohimi = kurs; System.out.println(pohimi +" "+"-" +"Sot eshte dite" +" "+ d+ " "+ "DHE"+" "+"eshte dite kursi bootcamp java");	
		break;
		default:
		pohimi = pushim;System.out.println(pohimi +" "+"-" +"Sot nuk eshte dite e hene" + " "+ "DHE"+" "+"eshte pushim");}
		
		return pohimi;
		}
	}


