package seanca4.ushtrime;
//Ushtrimi 5 , vektoret -- me metode
import java.lang.Math;
import java.util.Scanner;

public class ElemDublikuar {
	private static Scanner scab = new Scanner(System.in);
	static int i, j, lengthi, range = 10;
	static int[] arrayDublikuar = new int[lengthi];
	static int[] result = new int[lengthi];

	public static void main(String[] args) {
		arrayDublikuar = afishoVek(lengthi);
		result = frequency(arrayDublikuar);
	}

	public static int[] afishoVek(int lengthi) {
		System.out.println("Percaktoni gjatesine e vektorit:");
		lengthi = scab.nextInt();
		int[] arr = new int[lengthi];
		System.out.println("Afishoni vektorin me elemente te dublikuara!");
		for (int i = 0; i < lengthi; i++) {
			arr[i] = (int) (Math.random() * range);
			System.out.println(arr[i]);
		}
		return arr;
	}

	public static int[] frequency(int[] array) {
		int f[] = new int[lengthi];
		int apaD[] = new int[lengthi];
		for (i = 0; i < lengthi - 1; i++) {
			System.out.println('\n' + "Per elementin ne pozicionin" + " " + i + " :" + '\n');
			f[i] = 0;
			for (j = (i + 1); j < lengthi; j++) {
				if (arrayDublikuar[i] == arrayDublikuar[j]) {
					f[i] += 1;
					System.out.println("Per elementin ne poz e" + " " + i + " " + "dublikata u gjet ne pozicionin e"
							+ " " + j + " .");
					System.out.println("Vektori me elementet e padublikuar eshte:");
					lengthi = lengthi - f[i];
					int k = j;
					while (k < lengthi) {
						apaD[k] = arrayDublikuar[k + 1];
						System.out.println(apaD[k]);
					}
					k++;
				}

				else {
					f[i] = 0;
					System.out.println("Vektori me elementet e padublikuar eshte:");
					for (int k = i; k <= j; k++) {
						apaD[k] = arrayDublikuar[k];
						System.out.println(apaD[k]);
					}
				}
			}
			System.out.println("Frekuenca eshte:");
			System.out.print(f[i]);
		}

		return apaD;
	}
}
