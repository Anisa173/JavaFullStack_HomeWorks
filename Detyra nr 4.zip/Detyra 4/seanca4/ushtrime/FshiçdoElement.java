package seanca4.ushtrime;

import java.util.Scanner;

public class FshiçdoElement {
	static int i,j, n;
	private static Scanner input = new Scanner(System.in);

	public static void main(String[] args) {

		System.out.println("Vendosni gjatesine e vektorit");
		n = input.nextInt();
		int v[] = new int[n];
		int v2[] = new int[n - 1];
		System.out.println("Populloni vektorin me te dhena");
		for (i = 0; i < n; i++) {
			v[i] = input.nextInt();
		}
		System.out.println("Vektori i afishuar:");
		for (i = 0; i < n; i++) {

			System.out.println(v[i]);
		}
		System.out.println('\n' + "Vendosni elementin qe do te fshihet" + '\n');
		int elementi = input.nextInt();
		System.out.println("Vektori i ri qe do te perftohet pas fshirjes eshte:");
		    
			for(i = 0; i < n ; i++) {
				if(elementi == v[i]) {System.out.println("Elementi u gjend ne pozicionin"+ " "+ i);
					v2[i] = v[i + 1];
					System.out.println(v2[i]);
				} else {
					v2[i] = v[i];
					System.out.println(v2[i]);
				}
			}
		    }
		

	}


