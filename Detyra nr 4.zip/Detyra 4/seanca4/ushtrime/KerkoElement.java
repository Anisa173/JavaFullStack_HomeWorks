package seanca4.ushtrime;

import java.util.Scanner;

public class KerkoElement {
	private static Scanner scan = new Scanner(System.in);
	static int lengthi, i;
	static char[] array = new char[lengthi];
	 
	static boolean poz = true;
    static boolean unpoz = false;
	static boolean pohimi;
    public static void main(String[] args) {
		// TODO Auto-generated method stub
	array = printArray();
	pohimi = search(array);
    }

	public static char[] printArray() {
		System.out.println("Gjatesia e vektorit eshte :");
		lengthi = scan.nextInt();
		char[] a= new char[lengthi];
		System.out.println("Vendosni elementet ne konsole:");
		for (i = 0; i < lengthi; i++) {
			a[i] = scan.next().charAt(0);	
		}
		System.out.println("Afisho elementet e vektorit:");
		for (i = 0; i < lengthi; i++) {
			System.out.print(a[i]);
		}
		return a;
	}

	public static boolean search(char[] arr) {
		boolean p = false;
		char elementi;
		System.out.println('\n'+"Elementi qe po kerkojme eshte:");
		elementi = scan.next().charAt(0);
		
		for(i=0;i<lengthi;i++){
			if (arr[i] == elementi) {p= poz;
				System.out.println(p+" - "+"Elementi u gjet ne pozicionin" + " " + i + " .");break;
			}

			else {
				if (arr[i] != elementi) {p= unpoz;
					System.out.println(p + " - " + "Elementi u gjet ne pozicionin" + " " + i + " .");
				}
			}

		}
		
		return p;
	}

}