package seanca4.ushtrime;

import java.lang.Math;

public class VekB {
	static int n, gjatB;
	static int y = 10;
	static int i, k;
	static boolean baraz = true;
	static boolean Nbaraz = false;
	static int[] m = new int[n];
	static int[] v = new int[n];
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		afishoArray(m);
		afishoArray(v);
		vlereso(m, v);
		afishoVRi(m, v);
	}

	public static int[] afishoArray(int array[]) {
		System.out.println("Percaktojme gjatesine e vektorit:");
		n = (int) (Math.random() * y);int array1[] = new int[n];
		System.out.println(n);
		System.out.println("Popullojme  me te dhena:");
		for (i = 0; i < n; i++) {
			array1[i] = (int) (Math.random() * y);
		}
		for (i = 0; i < n; i++) {
			System.out.println(array1[i]);
		}
		return array1;
	}

	public static boolean vlereso(int[] arr1, int[] arr2) {
		boolean p = false;
		if (arr1.length != arr2.length) {
			p = baraz;
			System.out.println(p + " - " + "Gjatesi jo te barabarte ~ vektore jo te barabarte!");
		} else if (arr1.length == arr2.length) {
			for (i = 0; i < n; i++) {
				if (arr2[i] != arr1[i]) {
					p = Nbaraz;
					System.out.println(p + ": " + "Elementet e te dy vektoreve jane te barabarte!");
					break;
				} else {
					p = baraz;
					System.out.println("Elementet e te dy vektoreve  jane te barabarte!");
				}
			}
		}
		return p;
	}

	public static int[] afishoVRi(int[] arr1, int[] arr2) {
		System.out.println("Afishoni vektorin e ri:");
		int vektRi[] = new int[gjatB];
		if (arr1.length == arr2.length) {
			gjatB = (2*n);
				for (i = 0; i < arr1.length; i++) {
					vektRi[i] = arr1[i];
					System.out.println(vektRi[i]);
				}
				for (k = arr1.length; k < gjatB; k++) {
					vektRi[k] = arr2[k];
					System.out.println(vektRi[k]);
				}
			}
		

		else if (arr1.length != arr2.length) {
			gjatB = arr1.length+arr2.length;
			
				for (k = 0; k < arr1.length; k++) {
					vektRi[k] = arr1[k] ;
					System.out.println(vektRi[k]);
				}
				for (i = arr1.length; i < gjatB; i++) {
					vektRi[i] = arr2[i];
					System.out.println(vektRi[i]);
				}
			}
		
		return vektRi;
	}
}
