package seanca4.ushtrime;

import java.util.Scanner;

public class BashkimVek2 {
	static int lengthi, gjatesieRe;
	static int i, k;
	static boolean vlera;
	static boolean baraz = true;
	static boolean Nbaraz = false;
	static int[] a = new int[lengthi];
	static int[] b = new int[lengthi];
    static int[] vekB = new int[gjatesieRe];
	private static Scanner in = new Scanner(System.in);

	public static void main(String[] args) {
		a = afishoArray(lengthi);
		b = afishoArray(lengthi);
		vlera = vlereso(a, b);
        vekB = afishoV(a,b);
	}

	public static int[] afishoArray(int lengthi) {
		int array[] = new int[lengthi];
		System.out.println("Percaktoni gjatesine  e vektorit");
		lengthi = in.nextInt();
		System.out.println("Popullojme  me te dhena:");
		for (i = 0; i < lengthi; i++) {System.out.println("Elementi"+ " "+ (i+1)+" "+" eshte :");
			array[i] = in.nextInt();
		
		}
		System.out.println("Vektori i afishuar eshte :");
		for (i = 0; i < lengthi; i++) {
			System.out.println(array[i]);
		}
		return array;
	}

	public static boolean vlereso(int[] a, int[] b) {
		boolean p = false;
		if (a.length != b.length) {
			System.out.println("Per aq kohe sa gjatesite e te dy vektoreve nuk jane te barabarta ,nuk kontrollojme barazine e elementeve");
		} else if (a.length == b.length) {
			lengthi = a.length;
			for (i = 0; i < lengthi; i++) {
				if (b[i] != a[i]) {
					p = Nbaraz;
					System.out.println(p + ": " + "Elementet e te dy vektoreve jane te barabarte!");
					break;
				} else {
					p = baraz;
					System.out.println("Elementet e te dy vektoreve  jane te barabarte!");
				}
			}
		}

		return p;
	}

	public static int[] afishoV(int[] a, int[] b) {
		int t[] = new int[gjatesieRe];
		System.out.println("Afishoni vektorin e ri:");
		if (a.length == b.length) {
			gjatesieRe = 2 * lengthi;
			
				for (i = 0; i < a.length; i++) {
					t[i] = a[i];
					System.out.println(t[i]);
				}
				for (k = a.length; k < (2 * lengthi); k++) {
					t[k] = b[k];
					System.out.println(t[k]);
				}
			
		} else if (a.length != b.length) {
			if (a.length > b.length) {
				gjatesieRe = a.length+b.length;
				
					for (i = 0; i < b.length; i++) {
						t[i] = b[i];
						System.out.println(t[i]);
					}
					for (k = b.length; k < gjatesieRe; k++) {
						t[k] = a[k];
						System.out.println(t[k]);
					}
				}
			 else {
				gjatesieRe = b.length + a.length;
				
					for (i = 0; i < a.length; i++) {
						t[i] = a[i];
						System.out.println(t[i]);
					}
					for (k = a.length; k < gjatesieRe; k++) {
						t[k] = b[k];
						System.out.println(t[k]);
					}
				}}
			
		 else {
			if ((a.length == 0) && (b.length > 0)) {
				gjatesieRe = b.length;
				for (i = 0; i < gjatesieRe; i++) {
					t[i] = b[i];
					System.out.println(t[i]);
				}
			} else {
				gjatesieRe = a.length;
				for (i = 0; i < gjatesieRe; i++) {
					t[i] = a[i];
					System.out.println(t[i]);
				}
			}
		}
		return t;
	}

}