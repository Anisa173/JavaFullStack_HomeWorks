package seanca4.ushtrime;

import java.util.Scanner;
import java.lang.Math;
public class ShumaVek {
	static int lengthi, gjatesieRe;
	static int i, k;
	static boolean vlera;
	static boolean baraz = true;
	static boolean Nbaraz = false;
	static int[] a = new int[lengthi];
	static int[] b = new int[lengthi];
    static int[] vekB = new int[gjatesieRe];
	private static Scanner in = new Scanner(System.in);

	public static void main(String[] args) {
		a = afishoArray(lengthi);
		b = afishoArray(lengthi);
		vlera = vlereso(a, b);
        vekB = afishoShuma(a, b);
	}

	public static int[] afishoArray(int lengthi) {
		int rangu = 10;
		System.out.println("Percaktoni gjatesine  e vektorit");
		lengthi = in.nextInt();int array[] = new int[lengthi];
		System.out.println("Popullojme  me te dhena:");
		for (i = 0; i < lengthi; i++) {System.out.println("Elementi"+ " "+ (i+1)+" "+" eshte :");
			array[i] = (int)(Math.random()*rangu);
		System.out.println(array[i]);
		}
		System.out.println("Vektori i afishuar eshte :");
		for (i = 0; i < lengthi; i++) {
			System.out.println(array[i]);
		}
		return array;
	}

	public static boolean vlereso(int[] arr1, int[] arr2) {
		boolean p = false;
		if (arr1.length != arr2.length) {
			System.out.println("Per aq kohe sa gjatesite e te dy vektoreve nuk jane te barabarta ,nuk kontrollojme barazine e elementeve");
		} else if (arr1.length == arr2.length) {
			lengthi = a.length;
			for (i = 0; i < lengthi; i++) {
				if (arr2[i] != arr1[i]) {
					p = Nbaraz;
					System.out.println(p + ": " + "Elementet e te dy vektoreve jane te barabarte!");
					break;
				} else {
					p = baraz;
					System.out.println("Elementet e te dy vektoreve  jane te barabarte!");
				}
			}
		}

		return p;
	}

	public static int[] afishoShuma(int[] arr1, int[] arr2) {
		int t[] = new int[gjatesieRe];
		 i = 0;
		System.out.println("Afishoni vektorin e ri:");
		if((i<arr1.length)&&(i<arr2.length)) {
		if (arr1.length == arr2.length) {
			gjatesieRe = lengthi;
				for (i = 0; i <gjatesieRe; i++) {
					t[i] = arr1[i]+arr2[i];
					System.out.println(t[i]);
				}
				
			
		} else if (arr1.length != arr2.length) { 		
			if(arr1.length > arr2.length){gjatesieRe = arr1.length;
					for (i = 0; i < arr2.length; i++) {
						t[i] = arr2[i] + arr1[i];
						System.out.println(t[i]);
					}
					for (k = arr2.length; k < gjatesieRe; k++) {
						t[k] = arr1[k];
						System.out.println(t[k]);
					}
				}
			else {
				gjatesieRe = arr2.length;
					for (i = 0; i < arr1.length; i++) {
						t[i] = arr2[i] + arr1[i];
						System.out.println(t[i]);
					}
					for (k = arr1.length; k < gjatesieRe; k++) {
						t[k] = arr2[k];
						System.out.println(t[k]);
					}
				}}}
		
		return t;
	}

}