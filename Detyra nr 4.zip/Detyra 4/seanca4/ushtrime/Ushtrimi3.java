package seanca4.ushtrime;

import java.util.Scanner;

public class Ushtrimi3 {
	static int i, n;
	private static Scanner input = new Scanner(System.in);

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("Vendosni gjatesine e vektorit");
		n = input.nextInt();
		int v[] = new int[n];
		int v2[] = new int[n - 1];
		System.out.println("Populloni vektorin me te dhena");
		for (i = 0; i < n; i++) {
			v[i] = input.nextInt();
		}
		System.out.println("Vektori i afishuar:");
		for (i = 0; i < n; i++) {

			System.out.println(v[i]);
		}
		System.out.println('\n' + "Vendosni elementin qe do te fshihet");
		int elementi = input.nextInt();
		System.out.println("Vektori i ri qe do te perftohet pas fshirjes eshte:");
		for (int j = 0;j<n; j++) {
			for (i = j+1; i<=n-1; i++) {
				if (elementi == v[i-1]) {
					v2[i] = v[i];
					
					System.out.print(v2[i]);
				} else {
					
					v2[i] = v[i-1];
					
					System.out.print(v2[i]);
				}
			}

		}
	}}

