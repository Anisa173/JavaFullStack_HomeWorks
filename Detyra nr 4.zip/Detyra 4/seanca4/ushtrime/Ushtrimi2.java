package seanca4.ushtrime;

import java.util.Scanner;
import java.lang.Math;

public class Ushtrimi2 {
	static boolean uGjet = true;
	static boolean Nugjet = false;
	private static Scanner input;
	static int i, elementi, n;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		input = new Scanner(System.in);
		boolean p;
		System.out.println("Ju lutem vendosni gjatesine e vektorit");
		n = input.nextInt();
		int v[] = new int[n];
		int a[] = new int[n];
		System.out.println("Mbushni vektorin me elemente :");
		int z = 100;
		for (i = 0; i < n; i++) {
			a[i] = (int) (Math.random() * z);
		System.out.println(a[i]);
		}
		System.out.println("Vektori eshte me keto elemente:");
		for (i = 0; i < n; i++) {
			v[i] = a[i];
			System.out.println(v[i]);
		}
		System.out.println("Kontrolloni nese elementi qe ju kerkoni gjendet apo jo ne vektor!");
		System.out.print('\n' + "Elementi qe kerkojme eshte:");
		elementi = input.nextInt();
              System.out.println(elementi);
		for (i = 0; i < n; i++) {
			if (elementi == v[i]) {
				p = uGjet;
				System.out.println(p + " - " + "Elementi ndodhet ne pozicionin" + " " + i + " " + "te vektorit");
				break;
			}

			else {
				p = Nugjet;
				System.out.println(p + " - " + "Elementi gjendet ne vektor ne pozicionin" + " " + i + " !");
			}
		}
	}

}
