package seanca4.ushtrime;

import java.util.Scanner;

public class UshtrimiKater {
	static int i, t, n;
	private static Scanner input = new Scanner(System.in);
    static int vek[] = new int[n];
	public static void main(String[] args) {
		vek = shfaqVektor();
	}
	public static int[] shfaqVektor() {
	System.out.println("Numri i elementeve te vektorit eshte:");
		n = input.nextInt();
		int v[] = new int[n];

		System.out.println("Ne konsole te jepet inputi nga useri");
		for (i = 0; i < n; i++) {
			v[i] = input.nextInt();
		}
		System.out.println("Elementet e vektorit jane:");
		for (i = 0; i < n; i++) {
			System.out.println(v[i]);}
		
		System.out.println('\n' + "Vektori pas fshirjes se elementit te pare :");
		for (i = 0; i <= n-1; i++) {
			v[i] = v[1 + 1];System.out.println(v[i]);
			t = v[n - 2];
			i= n-1;
		    v[i] = t;
			System.out.println(v[i]);}
		
		return v;

	}
	}
