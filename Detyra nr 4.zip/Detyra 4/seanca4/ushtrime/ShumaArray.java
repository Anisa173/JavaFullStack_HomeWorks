package seanca4.ushtrime;

import java.util.Scanner;

public class ShumaArray {
	static int gjatesiarray, max;
	static int[] shumeElementesh = new int[max];
	static int[] array1 = new int[gjatesiarray];
	static int[] array2 = new int[gjatesiarray];

	static Scanner input = new Scanner(System.in);

	static int[] populloArray() {
		System.out.print("Me jep numrin e elementeve per kete array:");
		int gjatesiArray = input.nextInt();
		int[] array = new int[gjatesiArray];
		for (int i = 0; i < gjatesiArray; i++) {
			System.out.print("Jep elementin " + (i + 1) + ":");
			array[i] = input.nextInt();
		}
		System.out.println("Afisho elementet per kete array:");
		for (int i = 0; i < gjatesiArray; i++) {
			System.out.println("Elementi " + (i + 1) + ": " + array[i]);
		}

		return array;
	}

	static int[] riktheShumatCdoElementi(int[] arr1, int[] arr2) {
		System.out.println("Afisho vektorin shume:");
		max = arr1.length;
		int i = 0;
		int j;
		int[] perRikthim = new int[max];
		if ((i < arr1.length) && (i < arr2.length)) {
			if (arr2.length > max) {
				max = arr2.length;
				for (j = 0; j < max; j++) {
					for (i = j; i < arr1.length; i++)
						perRikthim[i] = arr1[i] + arr2[i];
					System.out.println(perRikthim[i]);
				}
				for (int k = arr1.length; k < max; k++) {
					perRikthim[k] = arr2[k];
					System.out.println(perRikthim[k]);
				}
			} else if (arr2.length == max) {
				for (i = 0; i < max; i++) {
					perRikthim[i] = arr1[i] + arr2[i];
					System.out.println(perRikthim[i]);
				}
			} else {
				for (j = 0; j < max; j++) {
					for (i = j; i < arr2.length; i++)
						perRikthim[i] = arr1[i] + arr2[i];
					System.out.println(perRikthim[i]);
				}
				for (int k = arr2.length; k < max; k++) {
					perRikthim[k] = arr1[k];
					System.out.println(perRikthim[k]);
				}
			}
		}
		return perRikthim;
	}

	public static void main(String[] args) {
		// popullimi i array-ve

		array1 = populloArray();
		array2 = populloArray();

		// inicializimi i vektorit shuma

		shumeElementesh = riktheShumatCdoElementi(array1, array2);

	}

}