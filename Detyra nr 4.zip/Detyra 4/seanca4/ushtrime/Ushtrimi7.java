package seanca4.ushtrime;

import java.lang.Math;

public class Ushtrimi7 {
	static int n = 5;
	static int i, k;
	static boolean baraz = true;
	static boolean Nbaraz = false;
	static int[] a = new int[n];
	static int[] b = new int[n];
	int array[] = new int[n];

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		afishoArray(a);
		afishoArray(b);
		vlereso(a, b);
		afishoVRi(a, b);
	}

	public static int[] afishoArray(int[] array) {
		System.out.println("Popullojme  me te dhena:");

		int y = 100;
		for (i = 0; i < n; i++) {
			array[i] = (int) (Math.random() * y);
		}
		System.out.println("Vektori permban keto elemente:");
		for (i = 0; i < n; i++) {
			System.out.println(array[i]);
		}
		return array;
	}

	public static boolean vlereso(int[] a1, int[] b1) {
		boolean p = false;
		for (i = 0; i < n; i++) {
			if (b1[i] != a1[i]) {
				p = Nbaraz;
				System.out.println(p + ": " + "Elementet e te dy vektoreve jane te barabarte!");
				break;
			} else {
				p = baraz;
				System.out.println("Elementet e te dy vektoreve  jane te barabarte!");
			}
		}
		return p;
	}

	public static int[] afishoVRi(int[] a1, int[] b1) {

		int array3 = (2 * n);
		int t[] = new int[array3];

			for (i = 0; i < a1.length; i++) {
				System.out.println("Elementi i " + " " + i + " " + "eshte :");
				t[i] = a1[i];
				System.out.println(t[i]);
			}
			for (k = a1.length; k < array3; k++) {
				System.out.println("Elementi i " + " " + k + " " + "eshte :");
				t[k] = b1[k];
				System.out.println(t[k]);
			}
		return t;
	}

}
