package seanca4.ushtrime;

import java.util.Scanner;

public class FshiElementpare {
	static int i, t, n;

	static int m[] = new int[n];
	private static Scanner input = new Scanner(System.in);

	public static void main(String[] args) {
		m = afishoVektor(n);
	}

	public static int[] afishoVektor(int n) {
		System.out.println("Gjatesia e vektorit  ");
		n = input.nextInt();
		int b[] = new int[n];
		System.out.println("eshte" + " " + n + " .");
		System.out.println("Ne konsole te jepet inputi nga useri");
		for (i = 0; i < n; i++) {
			b[i] = input.nextInt();
		}
		System.out.println("Vektori eshte i plotesuar nga elementet :");
		for (i = 0; i < n; i++) {
			System.out.println(b[i]);
		}
		System.out.println('\n' + "Vektori pas fshirjes se elementit eshte :");
		for (i = 0; i < n; i++) {
		for(i=0;i<n-1;i++) {
			b[i] = b[1 + i];
			System.out.println(b[i]);}
		for(i=n-1;i<n;i++) {
			b[i] = b[n-2];
			System.out.println(b[i]);}}
		

		return b;

	}

}
