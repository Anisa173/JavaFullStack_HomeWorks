package seanca4.ushtrime;
import java.util.Scanner;
import java.lang.Math;
public class ZbritesIImadhi {
	static int gjat, temp;
	static int rangu = 100;
	static int[] array = new int[gjat];
	static int[] result = new int[gjat];
	private static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {
		array = afishoVektor(gjat);
		result = renditElem(array);
	}

	public static int[] afishoVektor(int gjat) {
		System.out.println("Gjatesia e vektorit");
		gjat = sc.nextInt();
		int[] a = new int[gjat];
		System.out.println("eshte :" + " " + gjat);
		System.out.println("Shfaq vektor me numra!");
		for (int i = 0; i < gjat; i++) {
			a[i] = (int) (Math.random() * rangu);
			System.out.println(a[i]);
		}
		return a;
	}

	public static int[] renditElem(int[] arr) {
		// Renditim elementet e vektorit sipas rendit zbrites
		System.out.println("Afisho elementin e dyte me te madh:");
		for (int j = 0; j < 2; j++) {
			for (int i = j; i < gjat; i++) {
				if (array[j] < array[i + 1]) {
					temp = array[j];
					array[j] = array[i + 1];
					array[i + 1] = temp;
					System.out.println(array[j]);System.out.println(array[i+1]);
					
				} else {
					
					System.out.println(array[i+1]);System.out.println(array[j]);
					
				}
			}System.out.println(array[1]);
		}
		return arr;
	}
}
