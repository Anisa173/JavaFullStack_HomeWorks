package seanca4.ushtrime;

import java.util.Scanner;

public class Ushtrimi3meMetode {
	static int height, i, j,l=height-1;
	static char arr[] = new char[height];
	static char arr1[] = new char[l];
	static char array[] = new char[l];
	static char elementi;
	private static Scanner input = new Scanner(System.in);

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	arr = populloVekt(height);
	array = gjejFshielement(arr);
	}

	public static char[] populloVekt(int height) {
		System.out.println("Gjatesia e vektorit qe do te popullojme me elemente");
		height = input.nextInt();
		System.out.println(" " + "eshte :" + height + " .");

		char a[] = new char[height];
		System.out.println("Vendosni elementet ne konsole:");
		if (input.hasNext()) {
			for (i = 0; i < height; i++) {
				a[i] = input.next().charAt(0);
				System.out.println("Afishojme vektorin");
				System.out.print(a[i]);
			}
		} else {
			System.out.println("Elementi duhet te ishte karakter!");
			input.next();
		}

		return a;
	}

	public static char[] gjejFshielement(char[] arrays) {
	//"Per nje 'm' qe t'i se ve ,fjala 'mik' behet 'ik'... Ç'behet keshtu a i thuhet mikut ,ik?! ------ per pak humor
		System.out.println("Elementi qe perben 'redundance' ,pra qe kerkojme te fshijme eshte :");
		if (input.hasNext()) {
			elementi = input.next().charAt(0);
		} else {
			System.out.println("Elementi duhet te jete karakter!");
			input.next();}
		System.out.println("Kontrolloni nese ka redundance ne stringun ne fjale!");
		for(j=0;j<height;j++) {
		for (i = j+1; i < height; i++) {
			if (elementi == arrays[i-1]) {
				System.out.println("Elementi u gjet ne indeksin:" + " " + i + " .");
				arr1[i] = arrays[i];
			} else { 
				arr1[i] = arrays[i-1];
			}
			System.out.println(arr1[i]);
		}
	}
return arr1;
	}}
