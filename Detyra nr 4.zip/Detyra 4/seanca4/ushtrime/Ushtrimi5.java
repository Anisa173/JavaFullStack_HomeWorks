package seanca4.ushtrime;
import java.util.Scanner;
import java.lang.Math;
public class Ushtrimi5 {
	private static Scanner input= new Scanner(System.in);
	static boolean uGjet = true;
	static boolean uGjetN = false;
	static boolean p, l;
	static int n, i, j;
    static int x = 10;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("Percaktoni gjatesine e vektorit");
		n = input.nextInt();
		int[] v = new int[n];
		int freq[] = new int[n];
		
		System.out.println("Le te gjenerojme elementet e vektorit :");
		for (i = 0; i < n; i++) {
			v[i] = (int)(Math.random()*x);
		}
		System.out.println("Afisho elementet e vektorit :");
		for (i = 0; i < n; i++) {
			System.out.println(v[i]);
		}

		for (i = 0; i < n - 1; i++) {System.out.println('\n'+"Per elementin ne pozicionin"+" "+ i+ '\n');
			freq[i] = 0;
			for (j = i + 1; j < n; j++) {
				if (v[i] == v[j]) {
					p = uGjet;
					System.out.println(p + " - " + "Per elementin ne poz e" + " " + i + " "
							+ "dublikata u gjet ne pozicionin e" + " " + j + " .");
					freq[i] += 1;
					
				}

				else {
					p = uGjetN;
					freq[j] = 0;
				}
			}
			System.out.println(
					"Elementi ne poz " + " " + i + " " + " gjendet" + " " + freq[i] + " " + "here i dublikuar");
		}
	}

}
