package seanca4.ushtrime;

import java.util.Scanner;
import java.lang.Math;

public class ZbritesRenditjenr {
	private static Scanner input;
	static int n, y, i, temp, j, k;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		input = new Scanner(System.in);
		System.out.println("Vendosni gjatesine e vektorit:");
		n = input.nextInt();
		int n1[] = new int[n];
		int n2[] = new int[n];
		System.out.println("Gjenerojme elementet e vektorit :");
		y = 100;
		for (i = 0; i < n; i++) {
			n1[i] = (int) (Math.random() * y);
		}
		for (i = 0; i < n; i++) {
			n2[i] = n1[i];
			System.out.println(n2[i]);
		}
		System.out.println('\n');
		System.out.println("Renditja  e elementeve sipas rendit Zbrites");

		for (j = 0; j<n-1; j++) {
			for (i = j; i < n; i++) {
				if (n2[j] < n2[i + 1]) {
					temp = n2[i + 1];
					n2[i + 1] = n2[j];
					n2[j] = temp;
					break;
				} else {
					n2[j] = n2[i];
				}
			}
			System.out.println(n2[j]);
			System.out.println(n2[n-2]);
		}
	}

}
