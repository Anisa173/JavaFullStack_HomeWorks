package seanca4.ushtrime;

import java.util.Scanner;

public class FibonaciVarg {
	static int i, j, n;
	
	static int[] array;
	static int[] a;
	private static Scanner input = new Scanner(System.in);

	public static void main(String[] args) {
		array = afisho();
	}

	public static int[] afisho() {
		System.out.println("Ju lutem vendosni nr elementeve ne vargun Fibonaçi:");
		int gjatesia = input.nextInt();

		a = new int[gjatesia];
		System.out.println("Afisho elementet e vargut:");
		for (j = 0; j < gjatesia; j++) {
		for (i = 0; i < 2; i++) {
			a[i] = input.nextInt();
		}
		for (i = j; i < 2; i++) {System.out.println("Elementi" +" " + (i+1)+ " "+"eshte :"+ a[i]);
			
		}
		
		for(i=2;i<gjatesia;i++) {
			a[i] = a[i-2] + a[i-1];
		System.out.println("Elementi" +" " + (i+1)+ " "+"eshte :"+ a[i]);
        
		}}

		return a;
	}	
}