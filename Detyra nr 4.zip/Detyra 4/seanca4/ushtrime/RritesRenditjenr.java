package seanca4.ushtrime;
import java.util.Scanner;
		import java.lang.Math;
public class RritesRenditjenr {
private static Scanner sc;
			static int n, i, k, j, temp;

	public static void main(String[] args) {
		
				sc = new Scanner(System.in);
				System.out.println("Percaktoni gjatesine  e vektorit");
				n = sc.nextInt();
				int[] a = new int[n];
				int[] b = new int[n];
				System.out.println("Populloni vektorin me te dhena:");
				int x = 100;
				for (i = 0; i < n; i++) {
					a[i] = (int) (Math.random() * x);
				}
				for (i = 0; i < n; i++) {
					b[i] = a[i];
					System.out.println(b[i]);
				}
				System.out.println('\n');
				System.out.println("Afishoni elementet e vektorit ne rendin rrites");
				for (k = n - 1; k > 0;k--) {
					for (j = 0; j <= k; j++) {
							if (b[j] > b[j + 1]) {
								temp = b[j];
								b[j] = b[j + 1];
								b[j + 1] = temp;
							}
							
						System.out.println(b[j]);
						
					}
				}
			}
	}


