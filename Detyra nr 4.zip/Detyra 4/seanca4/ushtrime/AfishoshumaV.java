package seanca4.ushtrime;

import java.util.Scanner;

public class AfishoshumaV {
	static int array3, i, j, g;
	static int[] a1 = new int[g];

	static int[] b1 = new int[g];

	static int[] vekFinal = new int[array3];
	
	private static Scanner in = new Scanner(System.in);

	public static void main(String[] args) {

		a1 = afisho();
		b1 = afisho();
		vekFinal = shumaVek(a1,b1);
	}

	public static int[] afisho() {
		System.out.println('\n' + "Gjatesia e vektorit");
		 g = in.nextInt(); 
		int[] a = new int[g];
		System.out.println("eshte :" + g);
		System.out.println("Vendos elementet:");
		for (i = 0; i < g; i++) {
			a[i] = in.nextInt(); 
		}
		for (i = 0; i < g; i++) {System.out.println("Elementi" +" "+(i+1)+ " "+"eshte :" + a[i]);

		}
		return a;
	}

	public static int[] shumaVek(int[] a, int[] b) {
		
		int vek[] = new int[array3];
		if (a.length == b.length) {System.out.println("Vektori shume eshte:");
			array3 = b.length;
			for (i = 0; i < array3; i++) {
				vek[i] = a[i] + b[i];
				System.out.println(vek[i]);
			}
		} else if (a.length !=  b.length) {

			if (a.length > b.length) {System.out.println("Vektori shume eshte:");
				array3 = a.length;
					for(j = 0;j < b.length; j++) {
						vek[j] = a[j] + b[j];
						System.out.println(vek[j]);
					}
					for(i = b.length; i < array3; i++) {
						vek[i] = a[i];
						System.out.println(vek[i]);
					}
				}
			} else if(b.length>a.length) {System.out.println("Vektori shume eshte:");
				array3 = b.length;
				
					for (j = 0; j < a.length; j++) {
						vek[j] = a[j] + b[j];
						System.out.println(vek[j]);
					}
					for (i = a.length; i < array3; i++) {
						vek[i] = b[i];
						System.out.println(vek[i]);
					}
				}
		return vek;
	}

}
