package seanca4.ushtrime;
import java.util.Scanner;
public class Ushtrimi1 {
private static Scanner in;
		static int n,sh=0;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		in = new Scanner(System.in);
		System.out.println("Vendosni gjatesine e vektorit ne konsole:");
		if(in.hasNextInt()) {
		n = in.nextInt(); }
		else {System.out.println("Hedhje e gabuar e inputit!");in.next();}
		System.out.println("Vendosni inputin e vektorit :");
		for(int i=0;i<n;i++) { int v[]= new int[n];
		if(in.hasNextInt()){
		v[i] = in.nextInt();
		sh= sh + v[i];}                          
		else {System.out.println("Kemi vendosur inputin e gabuar!");in.next();}
		double mes =(sh/(i+1));
		System.out.println("Shuma e elementeve te vektorit eshte:" + sh);
		System.out.println("Mesatarja e elementeve te vektorit eshte:" + mes);}
		}
	}


