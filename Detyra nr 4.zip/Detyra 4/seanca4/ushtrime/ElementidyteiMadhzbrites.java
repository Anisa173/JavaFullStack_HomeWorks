package seanca4.ushtrime;
import java.util.Scanner;
import java.lang.Math;

public class ElementidyteiMadhzbrites {
	static int l, temp;
	static int rangu = 100;
	static int[] array = new int[l];
	static int[] renditElement = new int[l];
	private static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {
		array = afishoVektor(l);
		renditElement = renditElem(array);
	}

	public static int[] afishoVektor(int l) {
		System.out.println("Gjatesia e vektorit");
		l = sc.nextInt();
		sc.nextLine();
		int[] a = new int[l];
		System.out.println("eshte :" + " " + l);
		System.out.println("Shfaq vektor me numra!");
		for (int i = 0; i < l; i++) {
			a[i] = (int) (Math.random() * rangu);
			System.out.println(a[i]);
		}
		return a;
	}

	public static int[] renditElem(int[] arr) {
//Renditim elementet e vektorit sipas rendit zbrites
		System.out.println("Afisho elementin e dyte me te madh:");
		for (int k = l - 1; k > 0; k--) {
			for (int j = 0; j <= k; j++) {
				if (arr[j] < arr[j + 1]) {
					temp = arr[j + 1];
					arr[j + 1] = arr[j];
					arr[j] = temp;
					System.out.println(arr[j]);System.out.println(arr[j+1]);
					
				} else {
					System.out.println(arr[j]);
					
				}System.out.println(arr[1]);
			}
		}
		return arr;
	}
}