insert into department(departamentId,deptName,employeeNo,mgId)
values(1,'Dartamenti i IT',5,102),
(2,'Departamenti i Financës',6,205),
(3,'Departamenti i Marketingut',6,305);