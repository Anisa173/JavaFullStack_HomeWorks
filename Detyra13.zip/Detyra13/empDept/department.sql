CREATE TABLE department (
    departamentId INTEGER,
    deptName VARCHAR(255),
    employeeNo INTEGER,
    mgId INTEGER,
    PRIMARY KEY (departamentId),
    FOREIGN KEY (mgId)
        REFERENCES employee (employeeId)
        ON DELETE SET NULL ON UPDATE CASCADE
);