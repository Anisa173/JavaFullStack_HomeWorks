CREATE TABLE IF NOT EXISTS employee (
    employeeId INTEGER NOT NULL,
    employeeName VARCHAR(255) NOT NULL,
    employeeSalary INTEGER(255) NOT NULL,
    departamentId INTEGER NOT NULL,
    PRIMARY KEY (employeeId),
    FOREIGN KEY (departamentId)
        REFERENCES dep (departamentId)
        ON DELETE SET NULL ON UPDATE CASCADE
);