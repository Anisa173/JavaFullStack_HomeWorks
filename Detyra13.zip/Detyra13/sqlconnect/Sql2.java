package sqlconnect;

import java.sql.Connection;

import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.util.*;

public class Sql2 {
	/**
	 * 2- Insert a new employee into the "employees" table. Prompt the user to enter
	 * the employee's name, salary, and department ID.
	 */
	static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {
		try {
			Connection cn = ConnectionManager.getConnection();
			System.out.println("Vendos ID te punonjesit!");
			int id = sc.nextInt();
			System.out.println("Vendos emrin e punonjësit të ri!");
			String empName = sc.nextLine();
			System.out.println("Vendos pagën e punonjësit të ri!");
			int empSalary = sc.nextInt();
			System.out.println("Vendos se në cilin departament do te marrë funksionalitetet punonjësi i ri!");
			int deptId = sc.nextInt();

			PreparedStatement st = cn.prepareStatement(
					"insert into employee(employeeId,employeeName,employeeSalary,departamentId) Values(?,?,?,?)");
			int i = st.executeUpdate();

			st.setInt(1, id);
			st.setString(2, empName);
			st.setInt(3, empSalary);
			st.setInt(4, deptId);
			if (i != 0) {
				System.out.println("Punonjesi u shtua!");
			} else {
				System.out.println("Punonjesi nuk shtohet!");

			}
			cn.close();
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}

	}

}
