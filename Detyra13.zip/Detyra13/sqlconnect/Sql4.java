package sqlconnect;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class Sql4 {
	/**
	 * 4- Delete an employee from the "employees" table based on their ID. Prompt
	 * the user to enter the employee's ID.
	 */
	static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {
		try {
			Connection connect = ConnectionManager.getConnection();
			System.out.println("Vendosni id e punonjësit i cili do të ndërpresë marrëdhënit e punës");// eshte 'on
																										// delete set
																										// null' dhe jo
																										// 'on delete
																										// set cascade'
																										// qe te fshihen
																										// të gjitha
																										// relacionet e
																										// tjera te
																										// punonjesit
			int id = sc.nextInt();
			PreparedStatement st = connect.prepareStatement("Delete From employee as e Where employeeId = ?");
			st.setInt(1, id);
			int i = st.executeUpdate();
			if (i != 0) {
				System.out.println("Id e punonjësit u fshi!");
			} else {
				System.out.println("Ib e punonjësit nuk 'u bë'--'null' ");
			}
			connect.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
