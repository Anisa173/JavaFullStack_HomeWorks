package sqlconnect;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * 1- Retrieve all employees from an "employees" table, including their names,
 * salaries, and department names. Display the information in the console.
 */
public class Sql1 {

	public static void main(String[] args) {
		try {
			Connection connection = ConnectionManager.getConnection();
			PreparedStatement pst = connection.prepareStatement(
					"Select e.employeeName as empName,e.employeeSalary as empSalary,d.deptName as departmentName From employee as e INNER JOIN department as d ON e.departmentId = d.departmentId order by e.departmentName");

			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				String name = rs.getString("empName");
				int empSalary = rs.getInt("empSalary");
				String deptName = rs.getString("departmentName");
				System.out.println("empName" + " " + name + " " + "empSalary" + " " + empSalary + " " + "departmentName"
						+ " " + deptName);
			}
			connection.close();
		} catch (SQLException e) {

			e.printStackTrace();
		}

	}

}
