package sqlconnect;

import java.util.*;
import java.sql.*;

public class Sql3 {
	static Scanner sc = new Scanner(System.in);

	/**
	 * 3- Update the salary of an employee based on their ID. Prompt the user to
	 * enter the employee's ID and the new salary.
	 */

	public static void main(String[] args) {

		try {
			Connection con = ConnectionManager.getConnection();
			System.out.println("Vendos 'Id' të punonjësit!");
			int id = sc.nextInt();
			System.out.println("Vlera e përditësuar e pagës është:");
			int salary = sc.nextInt();
			PreparedStatement pt = con.prepareStatement("Update employee Set employeeSalary = ? Where employeeId =?");

			pt.setInt(1, salary);
			pt.setInt(2, id);
			int i = pt.executeUpdate();
			if (i != 0) {
				System.out.println("Paga u përditësua!");
			} else {
				System.out.println("Paga nuk u përditësua!");
			}
			con.close();
		} catch (SQLException e) {

			System.out.println(e.getMessage());
		}
	}
}
