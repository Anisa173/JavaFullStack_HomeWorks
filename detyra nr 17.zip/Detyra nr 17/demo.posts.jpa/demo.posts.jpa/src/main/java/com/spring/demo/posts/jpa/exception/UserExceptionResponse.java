package com.spring.demo.posts.jpa.exception;

import java.time.LocalDateTime;

public class UserExceptionResponse {
	private LocalDateTime dateTime = LocalDateTime.now();
	private String message;
	private Integer statusCode;
	private String path;

	 public UserExceptionResponse() {

	}

	 public UserExceptionResponse(String message, Integer statusCode, String path) {
		super();
		this.message = message;
		this.statusCode = statusCode;
		this.path = path;
	}

	public LocalDateTime getDateTime() {
		return dateTime;
	}

	public void setDateTime(LocalDateTime dateTime) {
		this.dateTime = dateTime;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Integer getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(Integer statusCode) {
		this.statusCode = statusCode;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}
}
