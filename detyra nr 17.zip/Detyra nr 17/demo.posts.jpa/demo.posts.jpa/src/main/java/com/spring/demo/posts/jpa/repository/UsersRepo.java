package com.spring.demo.posts.jpa.repository;

import java.util.List;

import com.spring.demo.posts.jpa.entity.Posts;
import com.spring.demo.posts.jpa.entity.Users;

public interface UsersRepo {

	List<Users> getAllUsers() throws Exception;

	Users getUsersById(Users user, Integer id) throws Exception;

	Users createUsers(Users dtoToEntity) throws Exception;

	List<Users> getUsersPost() throws Exception;
    
	List<Users> getUserPostsByUsersId(Integer userId) throws Exception;
	
	Users updateUsersByUsername(Integer id, Users users) throws Exception;

	Users updateUsersByEmail(Users users, Integer id) throws Exception;

	Users updateUsersByPassword(Users users, Integer id) throws Exception;

	Users updateUsersByDateModified(Users users, Integer id) throws Exception;

	void deleteUsersById(Integer id) throws Exception ;

	void deleteUserPosts(Integer user_postId, Integer postId) throws Exception;

	Posts getUserPostsByPostsId(Integer userId, Integer postId) throws Exception;

	Posts updateUserPosts(Posts posts, Users user_post,Integer id) throws Exception;

	/*Users createUsersPostsByUserId(Users users, Integer userId);**/

	

	

	

	

}
