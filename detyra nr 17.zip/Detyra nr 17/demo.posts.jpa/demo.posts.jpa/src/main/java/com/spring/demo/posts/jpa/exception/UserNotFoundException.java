package com.spring.demo.posts.jpa.exception;

public class UserNotFoundException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2425185225212647283L;

	public UserNotFoundException(String message) {
	super(message);	
	}
	
	

}
