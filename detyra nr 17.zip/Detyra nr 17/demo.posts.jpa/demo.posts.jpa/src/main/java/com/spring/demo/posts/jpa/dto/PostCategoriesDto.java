package com.spring.demo.posts.jpa.dto;

import java.time.LocalDateTime;

import com.spring.demo.posts.jpa.entity.Categories;
import com.spring.demo.posts.jpa.entity.PostCategoriesId;
import com.spring.demo.posts.jpa.entity.Posts;

public class PostCategoriesDto {
	private PostCategoriesId id;
	private Categories category;
	private Posts posts;
	private LocalDateTime date_created;
	private LocalDateTime date_modified;

	public PostCategoriesDto() {
		super();
	}

	public PostCategoriesDto(PostCategoriesId id,Categories category, Posts posts, LocalDateTime date_created, LocalDateTime date_modified) {
		super();
		this.id = id;
		this.category = category;
		this.posts = posts;
		this.setDate_created(date_created);
		this.setDate_modified(date_modified);
	}

	public PostCategoriesId getId() {

		return id;
	}

	public void setId(PostCategoriesId id) {
		this.id = id;
	}

	public Posts getPosts() {
		return posts;
	}

	public void setPosts(Posts posts) {
		this.posts = posts;
	}

	public Categories getCategory() {
		return category;
	}

	public void setCategory(Categories category) {
		this.category = category;
	}

	public LocalDateTime getDate_created() {

		return date_created;
	}

	public void setDate_created(LocalDateTime date_created) {
		this.date_created = date_created;
	}

	public LocalDateTime getDate_modified() {
		return date_modified;
	}

	public void setDate_modified(LocalDateTime date_modified) {
		this.date_modified = date_modified;
	}

	public String toString() {
		return "PostsCategoriesDto [id = " + id + ",date_created = "
				+ date_created + ",date_modified =" + date_modified + "]";

	}
}