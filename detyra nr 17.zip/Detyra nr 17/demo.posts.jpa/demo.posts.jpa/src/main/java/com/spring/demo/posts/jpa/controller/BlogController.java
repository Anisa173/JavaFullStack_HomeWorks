package com.spring.demo.posts.jpa.controller;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spring.demo.posts.jpa.dto.CategoriesDto;
import com.spring.demo.posts.jpa.dto.PostsDto;
import com.spring.demo.posts.jpa.entity.Categories;
import com.spring.demo.posts.jpa.entity.Posts;
import com.spring.demo.posts.jpa.entity.Users;
import com.spring.demo.posts.jpa.service.BlogService;

@RestController
@RequestMapping("Categories")
public class BlogController {
	private final BlogService blogService;

	public BlogController(BlogService blogService) {
		this.blogService = blogService;
	}

	@PostMapping
	public ResponseEntity<CategoriesDto> createCategory(@RequestBody CategoriesDto c) throws Exception {
		return ResponseEntity.ok(blogService.createCategory(c));
	}

	@DeleteMapping("{id}")
	public ResponseEntity<Void> deleteCategory(@RequestBody Categories c, @PathVariable Integer id) throws Exception {
		blogService.deleteCategory(c, id);
		return new ResponseEntity<Void>(HttpStatus.OK);
	}

	@GetMapping("/{id}")
	public ResponseEntity<CategoriesDto> findById(@PathVariable Integer id) throws Exception {
		return ResponseEntity.ok(blogService.findById(id));
	}

	@PutMapping("/{id}")
	public ResponseEntity<CategoriesDto> updateCategoryByName(@RequestBody CategoriesDto c, @PathVariable Integer id)
			throws Exception {
		return ResponseEntity.ok(blogService.updateCategoryByName(c, id));
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deleteUserPosts(@PathVariable Integer user_postId, @PathVariable Integer postId)
			throws Exception {
		blogService.deleteUserPosts(user_postId, postId);
		return new ResponseEntity<Void>(HttpStatus.OK);
	}

	@PutMapping("/{id}")
	public ResponseEntity<PostsDto> updateUserPosts(@RequestBody Users user_post, @PathVariable Integer postId,
			@PathVariable Integer userId) throws Exception {
		return ResponseEntity.ok(blogService.updateUserPosts(user_post, postId, userId));
	}

	@GetMapping
	public ResponseEntity<List<PostsDto>> getAllPosts() throws Exception {
		return ResponseEntity.ok(blogService.getAllPosts());
	}

	@GetMapping("/{title}")
	public ResponseEntity<List<PostsDto>> getAllPostsByTitle(@RequestBody Posts p, @PathVariable String title)
			throws Exception {
		return ResponseEntity.ok(blogService.getAllPostsByTitle(p, title));
	}

	@GetMapping("/{date_created}")
	public ResponseEntity<List<PostsDto>> getAllPostsByDate_created(@RequestBody Posts p,
			@PathVariable LocalDateTime date_created) throws Exception {
		return ResponseEntity.ok(blogService.getAllPostsByDate_created(p, date_created));
	}

	@GetMapping
	public ResponseEntity<List<PostsDto>> getAllPostsByCategories(@RequestBody Categories categories) throws Exception {
		return ResponseEntity.ok(blogService.getAllPostsByCategories(categories));
	}

	@GetMapping("/{id}")
	public ResponseEntity<PostsDto> getPostsCategoryById(@RequestBody Categories categories, @PathVariable Integer id)
			throws Exception {
		return ResponseEntity.ok(blogService.getPostsCategoryById(categories, id));
	}

	@GetMapping
	public ResponseEntity<List<PostsDto>> getPostsByCategoryName(Categories categ, String name) throws Exception {
		return ResponseEntity.ok(blogService.getPostsByCategoryName(categ, name));
	}

	@GetMapping("/{id}")
	public ResponseEntity<PostsDto> getUserPostsByPostsId(@PathVariable Integer userId, @PathVariable Integer postId)
			throws Exception {
		return ResponseEntity.ok(blogService.getUserPostsByPostsId(userId, postId));
	}

}