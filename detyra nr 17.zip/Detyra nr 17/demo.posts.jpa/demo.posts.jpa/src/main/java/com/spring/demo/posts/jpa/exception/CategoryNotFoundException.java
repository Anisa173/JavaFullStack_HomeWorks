package com.spring.demo.posts.jpa.exception;

public class CategoryNotFoundException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3023847530591336452L;

	public CategoryNotFoundException(String message) {
	super(message);
	}

}
