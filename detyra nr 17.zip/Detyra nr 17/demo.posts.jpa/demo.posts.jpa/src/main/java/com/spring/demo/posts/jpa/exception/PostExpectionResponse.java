package com.spring.demo.posts.jpa.exception;

import java.time.LocalDateTime;

public class PostExpectionResponse {
	private LocalDateTime dateTime = LocalDateTime.now();
	private String message;
	private Integer statusCode;
	private String path;

	 public PostExpectionResponse() {

	}

	 public PostExpectionResponse(String message, Integer statusCode, String path) {
		super();
		this.setMessage(message);
		this.setStatusCode(statusCode);
		this.setPath(path);
	}

	public LocalDateTime getDateTime() {
		return dateTime;
	}

	public void setDateTime(LocalDateTime dateTime) {
		this.dateTime = dateTime;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Integer getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(Integer statusCode) {
		this.statusCode = statusCode;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}
	
}
