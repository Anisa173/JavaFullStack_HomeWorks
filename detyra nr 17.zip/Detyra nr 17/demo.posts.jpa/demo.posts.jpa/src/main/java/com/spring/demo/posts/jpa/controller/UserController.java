package com.spring.demo.posts.jpa.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spring.demo.posts.jpa.dto.UsersDto;
import com.spring.demo.posts.jpa.entity.Users;
import com.spring.demo.posts.jpa.service.UserService;

@RestController
@RequestMapping("/users")
public class UserController {

	private final UserService userService;

	public UserController(UserService userService) {
		super();
		this.userService = userService;
	}

	@GetMapping
	public ResponseEntity<List<UsersDto>> getAllUsers() throws Exception {
		return ResponseEntity.ok(userService.getAllUsers());
	}

	@GetMapping("/{id}")
	public ResponseEntity<UsersDto> getUsersById(Users user, Integer id) throws Exception {
		return ResponseEntity.ok(userService.getUsersById(user, id));
	}

	@PostMapping
	public ResponseEntity<UsersDto> createUsers(@RequestBody UsersDto user_post) throws Exception {
		return ResponseEntity.ok(userService.createUsers(user_post));
	}

	@PutMapping("/{id")
	public ResponseEntity<UsersDto> updateUsersByUsername(@PathVariable Integer id, @RequestBody Users user)
			throws Exception {
		return ResponseEntity.ok(userService.updateUsersByUsername(user, id));
	}

	@PutMapping("/{id")
	public ResponseEntity<UsersDto> updateUsersByDateModified(@PathVariable Integer id, @RequestBody Users user)
			throws Exception {
		return ResponseEntity.ok(userService.updateUsersByDateModified(user, id));
	}

	@PutMapping("/{id")
	public ResponseEntity<UsersDto> updateUsersByEmail(@PathVariable Integer id, @RequestBody Users user)
			throws Exception {
		return ResponseEntity.ok(userService.updateUsersByDateModified(user, id));
	}

	@PutMapping("/{id")
	public ResponseEntity<UsersDto> updateUsersByPassword(@PathVariable Integer id, @RequestBody Users user)
			throws Exception {
		return ResponseEntity.ok(userService.updateUsersByPassword(user, id));
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deleteUsersById(@PathVariable Integer id) throws Exception {
		userService.deleteUsersById(id);
		return new ResponseEntity<Void>(HttpStatus.OK);
	}

	@GetMapping
	public ResponseEntity<List<UsersDto>> getUsersPosts() throws Exception {
		return ResponseEntity.ok(userService.getUsersPosts());
	}

	@GetMapping("/{id}")
	public ResponseEntity<List<UsersDto>> getUserPostsByUsersId(@PathVariable Integer id) throws Exception {
		return ResponseEntity.ok(userService.getUserPostsByUsersId(id));
	}
	
}
