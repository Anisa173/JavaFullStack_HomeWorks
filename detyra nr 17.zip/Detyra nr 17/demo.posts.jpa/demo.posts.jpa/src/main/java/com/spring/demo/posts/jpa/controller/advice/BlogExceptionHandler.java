package com.spring.demo.posts.jpa.controller.advice;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.spring.demo.posts.jpa.exception.CategoryExceptionResponse;
import com.spring.demo.posts.jpa.exception.CategoryNotFoundException;
import com.spring.demo.posts.jpa.exception.PostExpectionResponse;
import com.spring.demo.posts.jpa.exception.PostNotFoundException;

import jakarta.servlet.http.HttpServletRequest;

public class BlogExceptionHandler {
	@ExceptionHandler
	public ResponseEntity<CategoryExceptionResponse> blogNotFoundhandler(CategoryNotFoundException categoryException,
			HttpServletRequest httpReq) {
		var response = new CategoryExceptionResponse(categoryException.getMessage(), HttpStatus.NOT_FOUND.value(),
				httpReq.getRequestURI());
		return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler

	public ResponseEntity<PostExpectionResponse> blogNotFoundHandler(PostNotFoundException postException,
			HttpServletRequest httpReq) {
		var response = new PostExpectionResponse(postException.getMessage(), HttpStatus.NOT_FOUND.value(),
				httpReq.getRequestURI());
		return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);

	}

}
