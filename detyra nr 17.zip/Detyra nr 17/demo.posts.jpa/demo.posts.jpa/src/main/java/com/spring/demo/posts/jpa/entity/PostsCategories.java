package com.spring.demo.posts.jpa.entity;

import java.time.LocalDateTime;

import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.MapsId;

@Entity
public class PostsCategories extends BaseEntity<PostCategoriesId> {
	
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@EmbeddedId
	private PostCategoriesId id;
	@ManyToOne
	@MapsId("categoryId")
	@JoinColumn(name = "categoryId")
	private Categories category;

	@ManyToOne
	@MapsId("postId")
	@JoinColumn(name = "postId")
	private Posts posts;
	private LocalDateTime date_created;
	private LocalDateTime date_modified;

	public PostsCategories() {
		super();
	}

	public PostsCategories(Categories category, Posts posts, LocalDateTime date_created, LocalDateTime date_modified) {
		super();
		this.category = category;
		this.posts = posts;
		this.setDate_created(date_created);
		this.setDate_modified(date_modified);
	}

	@Override
	public PostCategoriesId getId() {

		return id;
	}

	public void setId(PostCategoriesId id) {
		this.id = id;
	}

	public Posts getPosts() {
		return posts;
	}

	public void setPosts(Posts posts) {
		this.posts = posts;
	}

	public Categories getCategory() {
		return category;
	}

	public void setCategory(Categories category) {
		this.category = category;
	}

	public LocalDateTime getDate_created() {

		return date_created;
	}

	public void setDate_created(LocalDateTime date_created) {
		this.date_created = date_created;
	}

	public LocalDateTime getDate_modified() {
		return date_modified;
	}

	public void setDate_modified(LocalDateTime date_modified) {
		this.date_modified = date_modified;
	}

	public String toString() {
		return "Postscategories[id = " + id + ",date_created = "+ date_created + ",date_modified =" + date_modified + "]";
				

	}
}
