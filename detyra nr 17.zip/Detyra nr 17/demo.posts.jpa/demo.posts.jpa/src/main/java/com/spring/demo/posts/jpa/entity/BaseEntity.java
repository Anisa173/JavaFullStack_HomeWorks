package com.spring.demo.posts.jpa.entity;

import java.io.Serializable;

public abstract class BaseEntity<T extends Serializable> {
	public abstract T getId();

	
}
