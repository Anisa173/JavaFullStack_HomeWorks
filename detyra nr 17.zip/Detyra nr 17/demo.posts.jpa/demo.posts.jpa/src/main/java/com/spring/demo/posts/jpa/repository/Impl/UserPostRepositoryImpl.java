package com.spring.demo.posts.jpa.repository.Impl;

import java.time.LocalDateTime;
import java.util.List;

import com.spring.demo.posts.jpa.entity.Categories;
import com.spring.demo.posts.jpa.entity.Posts;
import com.spring.demo.posts.jpa.entity.Users;
import com.spring.demo.posts.jpa.repository.CategoriesRepo;
import com.spring.demo.posts.jpa.repository.PostsRepo;
import com.spring.demo.posts.jpa.repository.UsersRepo;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

public class UserPostRepositoryImpl implements UsersRepo, PostsRepo, CategoriesRepo {
	@PersistenceContext
	EntityManager entityManager;

	@Override
	public Categories createCategory(Categories dtoToEntity) {
		return entityManager.merge(dtoToEntity);
	}

	@Override
	public void deleteCategory(Categories c, Integer id) {
		c = entityManager.find(Categories.class, id);
		entityManager.remove(c);
	}

	@Override
	public Categories findById(Integer id) {

		return entityManager.find(Categories.class, id);
	}

	public Categories updateCategoryByName(Integer id, Categories uptodate) {
		uptodate.setId(id);
		return entityManager.merge(uptodate);
	}

	@Override
	public List<Posts> getPostsByCategoryName(Categories categories, String name) {
		var tquery = entityManager.createNamedQuery("GET_POSTS_BY_CATEGORY_NAME", Posts.class).setParameter("name",
				name);
		return tquery.getResultList();
	}

	@Override
	public Posts getPostsCategoryById(Categories categories, Integer id) {

		return entityManager.find(Posts.class, id);
	}

	@Override
	public List<Posts> getAllPostsByCategories(Categories categories) {
		var<Posts> postC = entityManager.createNamedQuery("GET_POST_CATEGORIES", Posts.class);
		return postC.getResultList();
	}

	@Override
	public Posts createUserPostsDto(Posts posts, Integer id) throws Exception {

		return entityManager.merge(posts);
	}

	@Override
	public void deletePosts(Posts posts, Integer id) throws Exception {
		Posts ptPosts = entityManager.find(Posts.class, id);
		entityManager.remove(ptPosts);
	}

	@Override
	public Posts getUserPostsByPostsId(Integer userId, Integer postId)  {

		return entityManager.find(Posts.class, postId);
	}

	@Override
	public List<Posts> getAllPostsByTitle(Posts p, String title) throws Exception {
		var<Posts> postQuery = entityManager.createNamedQuery("GET_ALL_POSTS_BY_TITLE", Posts.class)
				.setParameter("title", title);
		return postQuery.getResultList();
	}

	@Override
	public List<Posts> getAllPostsByDate_created(Posts p, LocalDateTime date_created) throws Exception {
		var<Posts> postQuery = entityManager.createNamedQuery("GET_ALL_POSTS_BY_DATE_CREATED", Posts.class)
				.setParameter("date_created", date_created);
		return postQuery.getResultList();
	}

	@Override
	public Posts updatePosts(Posts posts, Integer id) throws Exception {
		posts.setId(id);
		return entityManager.merge(posts);
	}

	@Override
	public List<Posts> getAllPosts() {
		var<Posts> postQuery = entityManager.createNamedQuery("GET_ALL_POSTS", Posts.class);
		return postQuery.getResultList();
	}

	@Override
	public List<Users> getAllUsers() throws Exception {
		var<Users> u = entityManager.createNamedQuery("GET_ALL_USERS", Users.class);
		return u.getResultList();
	}

	@Override
	public Users getUsersById(Users user, Integer id) throws Exception {

		return entityManager.find(Users.class, id);
	}

	@Override
	public Users createUsers(Users dtoToEntity) throws Exception {

		return entityManager.merge(dtoToEntity);
	}

	@Override
	public List<Users> getUsersPost() throws Exception {
		var<Users> user = entityManager.createNamedQuery("GET_USERS_POST", Users.class);
		return user.getResultList();
	}

	@Override
	public Users updateUsersByUsername(Integer id, Users users) throws Exception {
		users.setId(id);
		return entityManager.merge(users);
	}

	@Override
	public Users updateUsersByEmail(Users users, Integer id) throws Exception {
		users.setId(id);
		return entityManager.merge(users);
	}

	@Override
	public Users updateUsersByPassword(Users users, Integer id) throws Exception {
		users.setId(id);
		return entityManager.merge(users);
	}

	@Override
	public Users updateUsersByDateModified(Users users, Integer id) throws Exception {
		users.setId(id);
		return entityManager.merge(users);
	}

	@Override
	public void deleteUsersById(Integer id) throws Exception {
		Users users = entityManager.find(Users.class, id);
		entityManager.remove(users);
	}

	@Override
	public List<Users> getUserPostsByUsersId(Integer userId) throws Exception {
		var<Users> up = entityManager.createNamedQuery("GET_USERS_POST_BY_USERSID", Users.class).setParameter("id", userId);
		return up.getResultList();
	}

	@Override
	public void deleteUserPosts(Integer user_postId, Integer postId) {
		var posts = entityManager.find(Posts.class, user_postId);
		entityManager.remove(posts);
	}

	@Override
	public Posts updateUserPosts(Posts post, Users user_post, Integer postId) {

		user_post.setPosts(getAllPosts());
  
		return (Posts) entityManager.merge(user_post.getPosts());
	}

/*	@Override
	public Users createUsersPostsByUserId(Users users,Integer userId) {
	users = entityManager.find(Users.class, userId);
		return entityManager.merge(users);
	}**/

}
