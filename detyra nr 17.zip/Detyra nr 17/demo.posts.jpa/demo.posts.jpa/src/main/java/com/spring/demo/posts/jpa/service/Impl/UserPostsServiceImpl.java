package com.spring.demo.posts.jpa.service.Impl;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.demo.posts.jpa.dto.CategoriesDto;
import com.spring.demo.posts.jpa.dto.PostsDto;
import com.spring.demo.posts.jpa.dto.UsersDto;
import com.spring.demo.posts.jpa.entity.Categories;
import com.spring.demo.posts.jpa.entity.Posts;
import com.spring.demo.posts.jpa.entity.Users;
import com.spring.demo.posts.jpa.mapper.CategoriesMapper;
import com.spring.demo.posts.jpa.mapper.PostsMapper;
import com.spring.demo.posts.jpa.mapper.UserMapper;
import com.spring.demo.posts.jpa.repository.CategoriesRepo;
import com.spring.demo.posts.jpa.repository.PostsCategoriesRepo;
import com.spring.demo.posts.jpa.repository.PostsRepo;
import com.spring.demo.posts.jpa.repository.UsersRepo;
import com.spring.demo.posts.jpa.service.BlogService;
import com.spring.demo.posts.jpa.service.UserService;

@Service
public class UserPostsServiceImpl implements BlogService, UserService {
	@Autowired
	private final CategoriesRepo categoriesRepo;
	private final PostsRepo postsRepo;
	private final UsersRepo usersRepo;
	@Autowired
	private final UserMapper userMapper;
	private final PostsMapper postsMapper;
	private final CategoriesMapper categoriesMapper;

	public UserPostsServiceImpl(CategoriesRepo categoriesRepo, PostsRepo postsRepo, UsersRepo usersRepo,
			PostsCategoriesRepo postsCategoriesRepo, UserMapper userMapper, PostsMapper postsMapper,
			CategoriesMapper categoriesMapper) {
		this.categoriesRepo = categoriesRepo;
		this.postsRepo = postsRepo;
		this.usersRepo = usersRepo;
		this.userMapper = userMapper;
		this.postsMapper = postsMapper;
		this.categoriesMapper = categoriesMapper;
	}

	@Override
	public List<UsersDto> getAllUsers() throws Exception {
		return usersRepo.getAllUsers().stream().map(u -> userMapper.entityToDto(u)).collect(Collectors.toList());
	}

	@Override
	public UsersDto getUsersById(Users user, Integer id) throws Exception {
		var entity = usersRepo.getUsersById(user, id);
		return userMapper.entityToDto((Users) entity);
	}

	public UsersDto createUsers(UsersDto user_post) throws Exception {
		var user = usersRepo.createUsers(userMapper.dtoToEntity(user_post));
		return userMapper.entityToDto((Users) user);
	}

	@Override
	public UsersDto updateUsersByUsername(Users user, Integer id) throws Exception {
		var userToUpdate = userMapper.dtoToEntity(getUsersById(user, id));
		userToUpdate.setUsername(user.getUsername());

		return userMapper.entityToDto(usersRepo.updateUsersByUsername(id, userToUpdate));
	}

	@Override
	public UsersDto updateUsersByEmail(Users user, Integer id) throws Exception {
		var userUpdate = userMapper.dtoToEntity(getUsersById(user, id));
		userUpdate.setEmail(user.getEmail());
		return userMapper.entityToDto(usersRepo.updateUsersByEmail(userUpdate, id));
	}

	@Override
	public UsersDto updateUsersByPassword(Users user, Integer id) throws Exception {
		var UpToDate = userMapper.dtoToEntity(getUsersById(user, id));
		UpToDate.setPassword(user.getPassword());
		return userMapper.entityToDto(usersRepo.updateUsersByPassword(UpToDate, id));
	}

	@Override
	public UsersDto updateUsersByDateModified(Users users, Integer id) throws Exception {
		var userUpTodate = userMapper.dtoToEntity(getUsersById(users, id));
		userUpTodate.setDate_modified(users.getDate_modified());
		return userMapper.entityToDto(usersRepo.updateUsersByDateModified(userUpTodate, id));
	}

	@Override
	public void deleteUsersById(Integer id) throws Exception {
		usersRepo.deleteUsersById(id);
	}

	public List<UsersDto> getUsersPosts() throws Exception {

		return usersRepo.getUsersPost().stream().map(h -> userMapper.entityToDto(h)).collect(Collectors.toList());
	}

	@Override
	public List<UsersDto> getUserPostsByUsersId(Integer userId) throws Exception {
		return usersRepo.getUserPostsByUsersId(userId).stream().map(u -> userMapper.entityToDto(u))
				.collect(Collectors.toList());
	}

	@Override
	public CategoriesDto createCategory(CategoriesDto c) throws Exception {
		var cat = categoriesRepo.createCategory(categoriesMapper.dtoToEntity(c));
		return categoriesMapper.entityToDto((Categories) cat);
	}

	@Override
	public void deleteCategory(Categories c, Integer id) throws Exception {

		categoriesRepo.deleteCategory(c, id);
	}

	@Override
	public CategoriesDto findById(Integer id) throws Exception {
		var Categ = categoriesRepo.findById(id);
		return categoriesMapper.entityToDto((Categories) Categ);
	}

	@Override
	public CategoriesDto updateCategoryByName(CategoriesDto c, Integer id) throws Exception {
		var uptodate = categoriesMapper.dtoToEntity(findById(id));
		uptodate.setName(c.getName());
		return categoriesMapper.entityToDto(categoriesRepo.updateCategoryByName(id, uptodate));
	}

	@Override
	public void deleteUserPosts(Integer user_postId, Integer postId) throws Exception {
		usersRepo.deleteUserPosts(user_postId, postId);

	}

	@Override
	public PostsDto getUserPostsByPostsId(Integer userId, Integer postId) throws Exception {
		var po = usersRepo.getUserPostsByPostsId(userId, postId);
		return postsMapper.entityToDto(po);

	}

	@Override
	public PostsDto updateUserPosts(Users user_post , Integer postId , Integer userId) throws Exception {
		var post = postsMapper.dtoToEntity(getUserPostsByPostsId(userId, postId));
		post.setTitle(((PostsDto) user_post.getPosts()).getTitle());
		post.setPostStatus(((PostsDto) user_post.getPosts()).getPostStatus());
		//user_post.setPosts(posts);
		return postsMapper.entityToDto(postsRepo.updateUserPosts(post,user_post, postId));
	}

	@Override
	public List<PostsDto> getAllPosts() throws Exception {

		return postsRepo.getAllPosts().stream().map(p -> postsMapper.entityToDto(p)).collect(Collectors.toList());
	}

	@Override
	public List<PostsDto> getAllPostsByTitle(Posts p, String title) throws Exception {

		return postsRepo.getAllPostsByTitle(p, title).stream().map(k -> postsMapper.entityToDto(k))
				.collect(Collectors.toList());
	}

	@Override
	public List<PostsDto> getAllPostsByDate_created(Posts p, LocalDateTime date_created) throws Exception {

		return postsRepo.getAllPostsByDate_created(p, date_created).stream().map(m -> postsMapper.entityToDto(m))
				.collect(Collectors.toList());
	}

	@Override
	public List<PostsDto> getPostsByCategoryName(Categories categories, String name) throws Exception {

		return categoriesRepo.getPostsByCategoryName(categories, name).stream().map(h -> postsMapper.entityToDto(h))
				.collect(Collectors.toList());
	}

	@Override
	public List<PostsDto> getAllPostsByCategories(Categories categories) throws Exception {
		return categoriesRepo.getAllPostsByCategories(categories).stream().map(n -> postsMapper.entityToDto(n))
				.collect(Collectors.toList());

	}

	@Override
	public PostsDto getPostsCategoryById(Categories categories, Integer id) throws Exception {
		var pstd = categoriesRepo.getPostsCategoryById(categories, id);
		return postsMapper.entityToDto(pstd);

	}

	/*@Override
	public UsersDto createUsersPostsByUserId(Integer userId,Integer postId,Posts postss) throws Exception {
		postss = usersRepo.getUserPostsByPostsId(userId,postId);
	var userPost = postsRepo.createUsersPostsByUserId(postss);
 	
	return userMapper.entityToDto((Users) userPost);
	}**/

}
