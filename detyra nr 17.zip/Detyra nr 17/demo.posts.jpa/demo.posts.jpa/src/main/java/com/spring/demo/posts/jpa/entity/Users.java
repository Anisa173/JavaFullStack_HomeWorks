package com.spring.demo.posts.jpa.entity;

import java.time.LocalDateTime;
import java.util.List;

import org.hibernate.annotations.NamedQueries;
import org.hibernate.annotations.NamedQuery;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@NamedQueries(value = { @NamedQuery(name = "GET_ALL_USERS", query = "Select u From Users u Order By u.id"),
		@NamedQuery(name = "GET_USERS_BY_ID", query = "Select u From Users u Where u.id =: id"),
		@NamedQuery(name = "ADD_USER", query = "Insert into Users (username,email,password,date_created) VALUES(?1,?2,?3,?4)"),
		@NamedQuery(name = "UPDATE_USERS_BY_USERNAME", query = "Update Users u Set u.username = :username Where u.id =:id"),
		@NamedQuery(name = "UPDATE_USERS_BY_EMAIL", query = "Update Users u Set u.email =:email ? Where u.id >: id"),
		@NamedQuery(name = "UPDATE_USERS_BY_PASSWORD", query = "Update Users u Set u.password =:password Where u.id =: id"),
		@NamedQuery(name = "UPDATE_USERS_BY_DATE_MODIFIED", query = "Update Users user Set user.date_modified = ? Where id =: id "),
		@NamedQuery(name = "DELETE_USERS_BY_ID", query = "Delete From Users u Where u.id = : id "),
		@NamedQuery(name = "GET_USERS_POST", query = "SELECT u,up FROM Users u INNER JOIN u.posts up ON u.id = up.user_id GROUP BY up.date_created Order By u.id"),
		@NamedQuery(name = "GET_USERS_POST_BY_USERID", query = "Select u.posts,u.id FROM Users u INNER JOIN posts  ON u.id = u.posts.user_id Where u.id >: id "),
		@NamedQuery(name = "ADD_USERS_POST", query = "Insert Into Posts (title,postStatus,date_created,date_modified,user_id) Values(?,?,?,?,(Select u,up From Users u INNER JOIN Users.posts up ON u.id = up.user_id Where u.id =:id )) ")})

@Entity
@Table(name = "Users")
public class Users extends BaseEntity<Integer> {
	@OneToMany(mappedBy = "user_post", cascade = CascadeType.ALL)
	private List<Posts> posts;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;
	@Column(name = "username")
	private String username;
	@Column(name = "email")
	private String email;
	@Column(name = "password")
	private String password;
	@Column(name = "date_created")
	private LocalDateTime date_created;
	@Column(name = "date_modified")
	private LocalDateTime date_modified;

	public Users() {
		super();
	}

	public Users(String username, String email, String password, LocalDateTime date_created,
			LocalDateTime date_modified, List<Posts> posts) {
		super();

		this.username = username;
		this.email = email;
		this.password = password;
		this.date_created = date_created;
		this.date_modified = date_modified;
		this.posts = posts;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public LocalDateTime getDate_created() {
		return date_created;
	}

	public void setDate_created(LocalDateTime date_created) {
		this.date_created = date_created;
	}

	public LocalDateTime getDate_modified() {
		return date_modified;
	}

	public void setDate_modified(LocalDateTime date_modified) {
		this.date_modified = date_modified;
	}

	public List<Posts> getPosts() {
		return posts;
	}

	public void setPosts(List<Posts> posts) {
		this.posts = posts;
	}

	public String toString() {
		return "Users[id =" + id + ",username = " + username + ",email = " + email + ",password = " + password
				+ ", date_created = " + date_created + ", date_modified = " + date_modified + ",posts =" + posts + "]";
	}

	@Override
	public Integer getId() {

		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

}