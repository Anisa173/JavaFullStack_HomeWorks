package com.spring.demo.posts.jpa.exception;

public class UserPostNotFoundException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2425185225212647283L;

	public UserPostNotFoundException(String message) {
	super(message);	
	}

}
