package com.spring.demo.posts.jpa.dto;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.spring.demo.posts.jpa.entity.Posts;

public class CategoriesDto {
	private Integer id;
	private String name;
	private LocalDateTime date_created;
	private LocalDateTime date_modified;
	private List<Posts> posts = new ArrayList<Posts>();

	public CategoriesDto() {
		super();
	}

	public CategoriesDto(String name, LocalDateTime date_created, LocalDateTime date_modified, List<Posts> posts) {
		super();
		this.setName(name);
		this.setDate_created(date_created);
		this.setDate_modified(date_created);
		this.setPosts(posts);
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public LocalDateTime getDate_created() {
		return date_created;
	}

	public void setDate_created(LocalDateTime date_created) {
		this.date_created = date_created;
	}

	public LocalDateTime getDate_modified() {
		return date_modified;
	}

	public void setDate_modified(LocalDateTime date_modified) {
		this.date_modified = date_modified;
	}

	public List<Posts> getPosts() {
		return posts;
	}

	public void setPosts(List<Posts> posts) {
		this.posts = posts;
	}

	public String toString() {
		return "CategoriesDto[id = " + id + ",name = " + name + ",date_created =" + date_created + ",date_modified ="
				+ date_modified + "]";
	}
}
