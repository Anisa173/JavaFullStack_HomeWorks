package com.spring.demo.posts.jpa.service;

import java.util.List;

import com.spring.demo.posts.jpa.dto.UsersDto;
import com.spring.demo.posts.jpa.entity.Posts;
import com.spring.demo.posts.jpa.entity.Users;

public interface UserService {
	List<UsersDto> getAllUsers() throws Exception;

	UsersDto getUsersById(Users user, Integer id) throws Exception;

	UsersDto createUsers(UsersDto user_post) throws Exception;

	UsersDto updateUsersByUsername(Users user, Integer id) throws Exception;

	UsersDto updateUsersByEmail(Users user, Integer id) throws Exception;

	UsersDto updateUsersByPassword(Users user, Integer id) throws Exception;

	UsersDto updateUsersByDateModified(Users user, Integer id) throws Exception;

	void deleteUsersById(Integer id) throws Exception;

	List<UsersDto> getUsersPosts() throws Exception;

	List<UsersDto> getUserPostsByUsersId(Integer userId) throws Exception;

	/*UsersDto createUsersPostsByUserId(Integer userId, Integer postId, Posts postss) throws Exception;*/
	
	
	
	
	
	
	
	
	
	
	
	
	
	



	

}
