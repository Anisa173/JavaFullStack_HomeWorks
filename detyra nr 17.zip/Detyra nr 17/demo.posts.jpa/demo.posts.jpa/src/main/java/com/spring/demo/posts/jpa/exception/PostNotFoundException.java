package com.spring.demo.posts.jpa.exception;

public class PostNotFoundException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2367065263059999725L;

	public PostNotFoundException(String msg) {
super(msg);
	}

}
