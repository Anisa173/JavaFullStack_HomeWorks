package com.spring.demo.posts.jpa.repository;

import java.util.List;

import com.spring.demo.posts.jpa.entity.Categories;
import com.spring.demo.posts.jpa.entity.Posts;

public interface CategoriesRepo {

	Categories createCategory(Categories dtoToEntity);

	void deleteCategory(Categories c, Integer id);

	Categories findById(Integer id);

	Categories updateCategoryByName(Integer id, Categories uptodate);

	List<Posts> getPostsByCategoryName(Categories categories, String name);

	Posts getPostsCategoryById(Categories categories, Integer id);

	List<Posts> getAllPostsByCategories(Categories categories);




}
