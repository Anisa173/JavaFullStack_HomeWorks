package com.spring.demo.posts.jpa.controller.advice;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.spring.demo.posts.jpa.exception.UserExceptionResponse;
import com.spring.demo.posts.jpa.exception.UserNotFoundException;
import com.spring.demo.posts.jpa.exception.UserPostExceptionResponse;
import com.spring.demo.posts.jpa.exception.UserPostNotFoundException;

import jakarta.servlet.http.HttpServletRequest;


	@ControllerAdvice
	public class UserExceptionHandler {
		
		@ExceptionHandler
		public ResponseEntity<UserExceptionResponse> userNotFoundhandler(UserNotFoundException userException,
				HttpServletRequest httpReq) {
			var response = new UserExceptionResponse(userException.getMessage(),HttpStatus.NOT_FOUND.value(), httpReq.getRequestURI()
					);
			return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
		}

		@ExceptionHandler
		public ResponseEntity<UserPostExceptionResponse> userNotFoundhandler(UserPostNotFoundException userpostExce,
				HttpServletRequest httpReq) {
			var response = new UserPostExceptionResponse(httpReq.getRequestURI(), HttpStatus.NOT_FOUND.value(),
					userpostExce.getMessage());
			return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
		}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	}

	