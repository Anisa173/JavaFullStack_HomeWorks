package com.spring.demo.posts.jpa.service;

import java.time.LocalDateTime;
import java.util.List;

import com.spring.demo.posts.jpa.dto.CategoriesDto;
import com.spring.demo.posts.jpa.dto.PostsDto;
import com.spring.demo.posts.jpa.dto.UsersDto;
import com.spring.demo.posts.jpa.entity.Categories;
import com.spring.demo.posts.jpa.entity.Posts;
import com.spring.demo.posts.jpa.entity.Users;

public interface BlogService {

	CategoriesDto createCategory(CategoriesDto c) throws Exception;

	void deleteCategory(Categories c, Integer id) throws Exception;

	CategoriesDto findById(Integer id) throws Exception;

	CategoriesDto updateCategoryByName(CategoriesDto c, Integer id) throws Exception;

	void deleteUserPosts(Integer user_postId , Integer postId) throws Exception;

	List<PostsDto> getAllPosts() throws Exception;

	List<PostsDto> getAllPostsByTitle(Posts p, String title) throws Exception;

	List<PostsDto> getAllPostsByDate_created(Posts p, LocalDateTime date_created) throws Exception;

	List<PostsDto> getAllPostsByCategories(Categories categories) throws Exception;

	PostsDto getPostsCategoryById(Categories categories, Integer id) throws Exception;

	List<PostsDto> getPostsByCategoryName(Categories categ, String name) throws Exception;

	PostsDto updateUserPosts(Users user_post, Integer postId, Integer userId) throws Exception;

	PostsDto getUserPostsByPostsId(Integer userId, Integer postId) throws Exception;

	//PostsDto updateUserPosts(List<Posts> post, Users user_post, Integer postId, Integer userId) throws Exception;

	



	

	

	



	

	

	


	

	

	

	



}
